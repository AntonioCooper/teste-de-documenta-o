---
title: "Access Token"
excerpt: ""
---
É possível gerenciar os cartões de um cliente utilizando o seu Access Token como Autenticação.

[block:callout]
{
  "type": "warning",
  "body": "Para utilizar os métodos de gerenciamento de cartão via `access_token` devemos incluir no cabeçalho `authentication` tendo como valor `Bearer {{access_token}}`."
}
[/block]