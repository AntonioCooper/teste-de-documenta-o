---
title: "Objeto token"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`type`",
    "2-0": "`created_at`",
    "3-0": "`expires_at`",
    "4-0": "`card`",
    "0-1": "**string**",
    "1-1": "**enum**",
    "2-1": "**datetime**",
    "3-1": "**datetime**",
    "4-1": "**objeto**",
    "4-2": "Dados do cartão, caso o token seja de um cartão. [Saiba mais sobre o objeto cartão](ref:objeto-cartao-token)",
    "3-2": "Data de expiração do token.",
    "2-2": "Data de criação do token.",
    "1-2": "Tipo do token. O valor possível é **card**.",
    "0-2": "Token do cartão."
  },
  "cols": 3,
  "rows": 5
}
[/block]