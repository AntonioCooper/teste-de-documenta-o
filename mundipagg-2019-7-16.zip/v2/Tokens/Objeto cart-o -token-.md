---
title: "Objeto cartão (token)"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Ttipo",
    "h-2": "Descrição",
    "0-0": "`holder_name`",
    "0-1": "**string**",
    "0-2": "Nome impresso no cartão.",
    "1-0": "`exp_month`",
    "1-1": "**datetime**",
    "2-1": "**datetime**",
    "1-2": "Mês de expiração.",
    "2-0": "`exp_year`",
    "2-2": "Ano de expiração.",
    "3-0": "`cvv`",
    "3-1": "**string**",
    "3-2": "Código de segurança do cartão.",
    "4-0": "`last_four_digits`",
    "4-1": "**string**",
    "4-2": "Últimos 4 dígitos do cartão."
  },
  "cols": 3,
  "rows": 5
}
[/block]