---
title: "Checkout transparente"
excerpt: ""
---
Um script da MundiPagg captura os dados de cartão e envia diretamente para o nosso sistema, que retorna um token para a página da loja. Dessa forma, a venda poderá ser efetuada sem trafegar os dados de cartão pelo seu servidor.
[block:api-header]
{
  "title": "Integração"
}
[/block]
Primeiramente, o script a seguir deverá ser inserido ao final do código de sua página de checkout:


[block:code]
{
  "codes": [
    {
      "code": "<script src=\"https://commerce.mundipagg.com/checkout.js\" data-mundicheckout-app-id=\"{{Sua chave pública da MundiPagg}}\"></script> \n",
      "language": "html"
    }
  ]
}
[/block]
Em seguida, devem ser adicionadas marcações data-mundicheckout em seu formulário de checkout, de acordo com o exemplo abaixo:
[block:code]
{
  "codes": [
    {
      "code": "<body>\n   <form action=\"{{url de sua action}}\" method=\"POST\" data-mundicheckout-form>\n      <input type=\"text\" name=\"holder-name\" data-mundicheckout-input=\"holder_name\">\n      <input type=\"text\" name=\"card-number\" data-mundicheckout-input=\"number\">\n      <span data-mundicheckout-brand data-mundicheckout-brand-image></span>\n      <input type=\"text\" name=\"card-exp-month\" data-mundicheckout-input=\"exp_month\">\n      <input type=\"text\" name=\"card-exp-year\" data-mundicheckout-input=\"exp_year\">\n      <input type=\"text\" name=\"cvv\" data-mundicheckout-input=\"cvv\">  \n      <input type=\"text\" name=\"buyer-name\">      \n      <button type=\"submit\">Enviar</button>\n   </form>\n   <script src=\"https://commerce.mundipagg.com/checkout.js\" data-mundicheckout-app-id=\"{{sua chave pública}}\"></script>\n   <script>\n      (function () {\n        MundiCheckout.init(function (data) {\n            // Opcionalmente, poderá ser definido um callback que recebe um objeto JSON \n            // contendo os valores do formulário que não foram marcados como dados de \n            // cartão (por exemplo, o nome e email do comprador e o CVV). Este callback\n            // pode ser utilizado para executar quaisquer lógicas customizadas de \n            // validação. Caso ele retorne o valor 'false', os dados não serão submetidos\n            // para o seu servidor.\n            // É importante que neste caso todos os campos não marcados \n            // possuam o atributo 'name', pois eles serão utilizados para definir o JSON.     \n            return true;\n        }, function(error) {\n          console.log(error);\n        });\n      })();\n   </script>\n</body>",
      "language": "html"
    }
  ]
}
[/block]
Ao submeter o formulário, o script irá inserir automaticamente um campo hidden no formulário, contendo o token de cartão. Após a submissão, seu servidor deverá criar um pedido utilizando este token.

Note que os campos buyer-name e CVV não estão marcados com nenhum atributo customizado. Isto significa que estes campos serão enviados normalmente para o seu servidor, sem a intervenção do script. Quaisquer outros campos desejados podem ser adicionados neste mesmo formulário.

O campo informando a expiração do cartão pode ser informado de duas formas: através de um único campo, marcado como exp_date ou em dois campos, exp_month e exp_year.

Não é obrigatório enviar a bandeira do cartão. Se ela não for enviada, o nosso sistema irá detectá-la automaticamente.

Por segurança, não podemos armazenar o valor do CVV em nosso sistema. Embora não seja obrigatório, recomendamos que ele seja enviado na criação do pedido, juntamente com o token do cartão.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0277199-fluxograma-checkout-transparente.jpg",
        "fluxograma-checkout-transparente.jpg",
        1000,
        1069,
        "#fbf3fb"
      ]
    }
  ]
}
[/block]