---
title: "Welcome!"
excerpt: ""
---
We want you to know a new world of online payments!

Our solutions allow you to proccess your payments faster, safer and easier.

We thought about every step so you can have an unique experience  and process with little code lines.
[block:callout]
{
  "type": "warning",
  "title": "Previous API",
  "body": "This is the documentation of the new Mundi api that was released april 5th, 2017. If you need to access previous version documentation, go to [docs-legacy.mundipagg.com](https://docs-legacy.mundipagg.com)."
}
[/block]

[block:api-header]
{
  "title": "Introduction"
}
[/block]
Mundi's API was developed was developed according to the best standards [REST](https://en.wikipedia.org/wiki/Representational_State_Transfer). Your *endpoints* have intuitive names that indicate available resources. Operations are done according to HTTP verbs, with message bodies in [JSON](http://www.json.org/). Responses can be interpreted through HTTP status code. This allows applications to connect simply and clearly, regardless of the language used. To further facilitate integration, it provides SDKs in all major programming languages.
We also offer a test API key, so integration can be done with tests at will, without worrying about charges on credit cards used.