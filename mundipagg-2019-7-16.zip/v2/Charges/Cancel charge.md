---
title: "Cancel charge"
excerpt: ""
---
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
[block:code]
{
  "codes": [
    {
      "code": "$.get('http://yoursite.com/test/' + id, function(data) {\n    console.log(data);\n});",
      "language": "javascript"
    }
  ]
}
[/block]