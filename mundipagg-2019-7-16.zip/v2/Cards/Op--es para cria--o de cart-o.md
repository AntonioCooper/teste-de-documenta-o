---
title: "Opções para criação de cartão"
excerpt: ""
---
[block:api-header]
{
  "title": "Objeto Options"
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "`verify_card`",
    "0-1": "**boolean**",
    "0-2": "Performs an authorization followed by a cancellation with the card to verify the authenticity of the information.",
    "h-0": ""
  },
  "cols": 3,
  "rows": 1
}
[/block]