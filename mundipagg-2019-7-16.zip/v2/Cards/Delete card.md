---
title: "Delete card"
excerpt: ""
---
