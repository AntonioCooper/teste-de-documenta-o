---
title: "Create card"
excerpt: ""
---
[block:callout]
{
  "type": "warning",
  "title": "",
  "body": "O cartão é único por comprador."
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "A bandeira será identificada automaticamente caso não seja enviada.",
  "title": "Identificação da bandeira"
}
[/block]