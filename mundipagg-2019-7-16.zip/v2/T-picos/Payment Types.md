---
title: "Payment Types"
excerpt: ""
---
In our [Cobranças](ref:objeto-cobranca) and [Pedidos](ref:objeto-pedido), node can have two types of payment:` credit_card` or `bankslip`.
[block:api-header]
{
  "title": "Credit card payment"
}
[/block]
To create [Cobrança](ref:criar-cobranca) or [Pedido](ref:criar-pedido), with credit card, we should include the object `credit_card` inside the node `payment`, as well as `"payment_method": "credit_card"` property.
[block:parameters]
{
  "data": {
    "h-0": "Field",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`installments`",
    "1-0": "`retries`",
    "2-0": "`capture`",
    "3-0": "`statement_descriptor`",
    "4-0": "`card`, `card_id` ou `card_token`",
    "0-1": "*integer**",
    "1-1": "**integer** ",
    "2-1": "**boolean** ",
    "3-1": "**string** ",
    "4-1": "**object** ",
    "0-2": "Quantidade de parcelas. O padrão é **1**.",
    "1-2": "Quantidade de retentativas caso o pagamento seja não autorizado ou ocorra algum erro no gateway. O padrão é **0**.",
    "2-2": "Indica se o pagamento deve ser processado imediatamente. Caso seja **false** o pagamento deverá ser confirmado posteriormente. O padrão é **true**..",
    "3-2": "Texto exibido na fatura do cartão. Max: 22 caracteres.",
    "4-2": "Cartão de crédito. \n**- card_id** é o identificador do cartão de um cliente.\n**- card_token** é o token do cartão gerado pelo checkout transparente.\n[Leia mais sobre cartão de crédito](ref:objeto-cartao)."
  },
  "cols": 3,
  "rows": 5
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 200000,\n  \"customer\": {\n    \"name\": \"Tony Stark\",\n    \"email\": \"email@email.com\",\n    \"metadata\": {\n      \"company\": \"MundiPagg\"\n    }\n  },\n  \"payment\":{\n   \"payment_method\": \"credit_card\",\n   \"credit_card\": {\n      \"installments\": 1,\n      \"statement_descriptor\": \"AVENGERS\",\n      \"card\": {\n        \"number\": \"342793631858229\",\n        \"holder_name\": \"Tony Stark\",\n        \"exp_month\": 1,\n        \"exp_year\": 18,\n        \"cvv\": \"3531\",\n        \"billing_address\": {\n          \"street\": \"Malibu Point\",\n          \"number\": \"10880\",\n          \"zip_code\": \"90265\",\n          \"neighborhood\": \"Central Malibu\",\n          \"city\": \"Malibu\",\n          \"state\": \"CA\",\n          \"country\": \"US\"\n        }\n      }\n    }\n  }\n}",
      "language": "json",
      "name": "Request de uma cobrança com cartão de crédito"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "Pagamento com boleto"
}
[/block]
Para criar uma [Cobrança](ref:criar-cobranca) ou [Pedido](ref:criar-pedido), com boleto, devemos incluir o objeto `boleto` dentro do nó `payment`, assim como a propriedade `"payment_method": "boleto"`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`bank`",
    "0-1": "**enum** ",
    "0-2": "**001** (Banco do Brasil), **033** (Santander), **237** (Bradesco), 341 (Itau) ou **399** (HSBC)",
    "1-0": "`instructions`",
    "1-1": "**string** ",
    "1-2": "Instruções do boleto. Max: 256 caracteres.",
    "2-0": "`due_at`",
    "2-1": "**datetime**",
    "2-2": "Data de vencimento. (**Obrigatório**)"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 1490,\n  \"customer\": {\n      \"name\": \"Tony Stark\",\n      \"email\": \"tstark@avengers.com\",\n      \"address\": {\n          \"street\": \"Av. General Justo\",\n          \"number\": \"375\",\n          \"complement\": \"9º andar\",\n          \"zip_code\": \"20021130\",\n          \"neighborhood\": \"Centro\",\n          \"city\": \"Rio de Janeiro\",\n          \"state\": \"RJ\",\n          \"country\": \"BR\"\n      }\n  },\n  \"payment\": {\n      \"payment_method\": \"boleto\",\n      \"boleto\": {\n        \"bank\": \"033\",\n        \"instructions\": \"Pagar até o vencimento\",\n        \"due_at\": \"2016-09-20T00:00:00Z\"\n      }\n  }\n}",
      "language": "json",
      "name": "Requisição de pagamento com boleto"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "danger",
  "title": "Atenção",
  "body": "Para **boletos com registro** os campos `name`, `address` e `document` devem ser enviados."
}
[/block]