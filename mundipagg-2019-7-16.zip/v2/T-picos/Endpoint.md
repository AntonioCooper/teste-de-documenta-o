---
title: "Endpoint"
excerpt: ""
---
Test and production calls must be made to the same endpoint. What will define whether the transaction will use our simulator or the production flow is the API key sent.
[block:callout]
{
  "type": "info",
  "body": "https://api.mundipagg.com/core/v1",
  "title": "Endpoint"
}
[/block]