---
title: "Pagination"
excerpt: ""
---
Our API supports bulk searches through "list" methods. In this way, you can list buyers, signatures, orders and various other Mundipagg objects. All of these listing methods have a common structure, which is pagination.
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"data\": [...],\n  \"paging\": {\n    \"total\": 11,\n    \"previous\": null,\n    \"next\": \"{url}?page=2&size=10\"\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]