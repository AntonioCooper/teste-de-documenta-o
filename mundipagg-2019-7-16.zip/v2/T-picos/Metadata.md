---
title: "Metadata"
excerpt: ""
---
Most of our objects - like [Customer](http://docs.mundipagg.com/v3.0/docs/o-comprador), [Credit Card](http://docs.mundipagg.com/v3.0/docs/o-cart%C3%A3o-de-cr%C3%A9dito), [Address](http://docs.mundipagg.com/v3.0/docs/o-endere%C3%A7o), [Subscription](http://docs.mundipagg.com/v3.0/docs/a-assinatura), [Plan](http://docs.mundipagg.com/v3.0/docs/o-plano), [Order ](http://docs.mundipagg.com/v3.0/docs/o-pedido) and [Charge ](http://docs.mundipagg.com/v3.0/docs/a-cobran%C3%A7a)- Have the `metadata` parameter, which you can use to store key-value data.
Metadata is interesting for the structured storage of complementary data related to some objects. An example would be to add the parent name of a **[customer ](http://docs.mundipagg.com/v3.0/docs/o-comprador)** to have this information in our customer portfolio.

[block:code]
{
  "codes": [
    {
      "code": "{\n  ...\n  \"metadata\": {\n    \"field1\": \"value1\",\n    \"field2\": \"value2\",\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]