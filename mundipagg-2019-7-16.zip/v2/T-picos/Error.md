---
title: "Error"
excerpt: ""
---
Our API validates each of the fields sent in the (*request*) before proceeding with the creation, query, or management of requests, transactions, and resources.

We use the conventional HTTP response codes to indicate the success or failure of a request.

Thus, **2xx** codes indicate success, **4xx** indicate error for some incorrectly entered data (eg: some mandatory field not sent or a card with no expiration date) and **5xx** indicating error in MundiPagg servers.

**HTTP Status Code table:** 
[block:parameters]
{
  "data": {
    "0-0": "`200`",
    "1-0": "`400`",
    "2-0": "`401`",
    "3-0": "`404`",
    "4-0": "`412`",
    "5-0": "`422`",
    "6-0": "`500`",
    "0-1": "OK",
    "1-1": "Bad Request",
    "2-1": "Unauthorized",
    "3-1": "Not Found",
    "4-1": "Precondition Failed",
    "5-1": "Unprocessable Entity",
    "6-1": "Internal Server Error",
    "0-2": "Success",
    "1-2": "Invalid request",
    "2-2": "Invalid API key",
    "3-2": "The requested resource does not exist",
    "4-2": "Valid parameters but request failed",
    "5-2": "Invalid parameters",
    "6-2": "An internal error occurred"
  },
  "cols": 3,
  "rows": 7
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"message\": \"Customer not found.\"\n}",
      "language": "json",
      "name": "Example (Geral)"
    }
  ]
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"message\": \"The request is invalid.\",\n  \"errors\": {\n    \"customer.name\": [\n      \"The name field is required.\"\n    ]\n  },\n  \"request\": {\n    \"name\": null,\n    \"email\": \"tstark@avengers.com\",\n  }\n}",
      "language": "json",
      "name": "Example (422)"
    }
  ]
}
[/block]