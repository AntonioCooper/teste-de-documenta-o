---
title: "Authentication"
excerpt: ""
---
To authenticate with us, you must send the **API Key** in the *Authorization* header, following the  [HTTP Basic Authentication](https://en.wikipedia.org/wiki/Basic_access_authentication) standard. 
It is not necessary to send any password, just the key.
[block:code]
{
  "codes": [
    {
      "code": "\n// Install-Package RestSharp\n\nvar key = \"sk_test_tra6ezsW3BtPPXQa\";\nvar api = \"https://api.mundipagg.com/core/v1.0\";\n\nvar client = new RestClient(api);\nclient.Authenticator = new HttpBasicAuthenticator(key, null);\n\nvar response = client.Execute(...);",
      "language": "csharp"
    }
  ]
}
[/block]
In addition, Content-Type and Accept headers can be added, with application/json value:
`Content-Type: application/json`
`Accept: application/json`
<br>
[block:api-header]
{
  "title": "Do you already have your API Key?"
}
[/block]
Before you begin you need to get your API key. Contact our commercial area to know our plans: *comercial@mundipagg.com*.

If you are already our customer, request the API key from our Customer Relations area! 
Email: * suporte@mundipagg.com*.

You will receive two **API secret keys**, one for Sandbox and one for Production, in the following format:

`Sandbox key: sk_test_tra6ezsW3BtPPXQa`
`Production key: sk_fbt5cahT3BbHAXZy`
[block:callout]
{
  "type": "danger",
  "body": "Your API Key is secret and should not be shared.",
  "title": "Attention"
}
[/block]
In addition, you will also receive two API public keys. These keys will be used to represent your store in the integration with **transparent checkout**.

`Public production key: pk_ghc3waxT4BaCZXAb`
`Public sandbox key: pk_test_gaa5xzfz7CfPPZAv`