---
title: "Objeto Telefones"
excerpt: ""
---
[block:api-header]
{
  "title": "Segue o exemplo do objeto PHONES."
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "\"phones\": {\n  \"home_phone\": {\n    \"country_code\": \"55\",\n    \"number\": \"000000000\",\n    \"area_code\": \"021\"\n  },\n  \"mobile_phone\": {\n    \"country_code\": \"55\",\n    \"number\": \"987654321\",\n    \"area_code\": \"021\"\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]
O objeto `phones` possui as seguintes propriedades:
[block:parameters]
{
  "data": {
    "h-0": "Nome",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`home_phone`",
    "0-1": "**object**",
    "0-2": "Telefone residencial.",
    "1-0": "`mobile_phone`",
    "1-1": "**object**",
    "1-2": "Telefone móvel."
  },
  "cols": 3,
  "rows": 2
}
[/block]
Tanto o `home_phone` quanto o `mobile_phone` possuem são compostos pelos seguintes parâmetros:
[block:parameters]
{
  "data": {
    "0-0": "`country_code`",
    "0-1": "**string**",
    "0-2": "Código do País. (Apenas numérico)",
    "1-0": "`area_code`",
    "1-1": "**string**",
    "1-2": "Código da área.(Apenas numérico)",
    "2-0": "`number`",
    "2-1": "**string**",
    "2-2": "Número do telefone.(Apenas numérico)"
  },
  "cols": 3,
  "rows": 3
}
[/block]