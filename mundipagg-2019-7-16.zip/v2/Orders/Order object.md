---
title: "Order object"
excerpt: ""
---
To create credit card or bankslip orders, you must create a 'order' object.
The oders are identified by a random key. Eg: `or_x50ZBkRQhzhxXzpj`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`currency`",
    "2-0": "`status`",
    "3-0": "`code`",
    "4-0": "`customer`",
    "5-0": "`shipping`",
    "6-0": "`charges`",
    "7-0": "`items`",
    "8-0": "`metadata`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**string**",
    "4-1": "**object**",
    "5-1": "**object**",
    "6-1": "**array of object**",
    "7-1": "**object**",
    "8-1": "**object**",
    "0-2": "Order identifier.",
    "1-2": "Currency.",
    "2-2": "Order status.",
    "3-2": "Order code at the store system.",
    "4-2": "Customer data.",
    "5-2": "Shipping data. [Learn more about billing](ref:shipping).",
    "6-2": "Charges.",
    "7-2": "Order itens.",
    "8-2": "Adition order informations. [Learn more about metadata](ref:metadata).",
    "9-0": "`closed`",
    "9-1": "**boolean**",
    "9-2": "Indicates if the order is opend or closed.",
    "10-0": "`created_at`",
    "10-1": "**datetime**",
    "10-2": "Ceation date."
  },
  "cols": 3,
  "rows": 11
}
[/block]