---
title: "Access Token"
excerpt: ""
---
It's possible to manage customer cards using its Access Token as Authentication.

[block:callout]
{
  "type": "warning",
  "body": "To use card manage methods via `access_token` you have to include `authentication` header with `Bearer {{access_token}}` value."
}
[/block]