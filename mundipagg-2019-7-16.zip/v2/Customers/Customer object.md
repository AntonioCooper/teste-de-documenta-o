---
title: "Customer object"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "0-0": "`id`",
    "1-0": "`name`",
    "2-0": "`email`",
    "3-0": "`phones`",
    "4-0": "`document`",
    "5-0": "`type`",
    "6-0": "`address`",
    "7-0": "`fb_id`",
    "8-0": "`fb_access_token`",
    "9-0": "`delinquent`",
    "10-0": "`created_at`",
    "11-0": "`updated_at`",
    "12-0": "`birthdate`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**object**",
    "4-1": "**string**",
    "5-1": "**enum**",
    "6-1": "**object**",
    "7-1": "**integer**",
    "8-1": "**string**",
    "9-1": "**boolean**",
    "10-1": "**datetime**",
    "11-1": "**datetime**",
    "12-1": "**datetime**",
    "0-2": "Customer identifier.",
    "1-2": "Name",
    "2-2": "E-mail.",
    "3-2": "Phones. [lear more about phones](ref:phones-object).",
    "4-2": "Document number.",
    "5-2": "Person type. Available values:  *individual* or *company*.",
    "6-2": "Costumer address. [Lear more about address](ref:address-object).",
    "7-2": "Customer identifier on Facebook.",
    "8-2": "[Facebook Access token](https://developers.facebook.com/docs/facebook-login/access-tokens/?locale=pt_BR) .Use to perform Graph API calls and get user information.",
    "9-2": "Indicates if the customer is delinquent.",
    "10-2": "Creation date.",
    "11-2": "Update date.",
    "12-2": "Customer birthdate.",
    "13-0": "`metadata`",
    "13-1": "**object**",
    "13-2": "Adition customer informations. [Learn more about metadata](ref:customer-object)."
  },
  "cols": 3,
  "rows": 14
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "O campo e-mail é único",
  "title": "Atenção"
}
[/block]