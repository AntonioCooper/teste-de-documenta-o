---
title: "Objeto token"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`type`",
    "2-0": "`created_at`",
    "3-0": "`expires_at`",
    "4-0": "`card`",
    "0-1": "**string**",
    "1-1": "**enum**",
    "2-1": "**datetime**",
    "3-1": "**datetime**",
    "4-1": "**objeto**",
    "0-2": "Token do cartão.",
    "1-2": "Tipo do token. O valor possível é **card**.",
    "2-2": "Data de criação do token.",
    "3-2": "Data de expiração do token.",
    "4-2": "Dados do cartão, caso o token seja de um cartão. Saiba mais sobre o objeto cartão abaixo."
  },
  "cols": 3,
  "rows": 5
}
[/block]

[block:api-header]
{
  "title": "Objeto cartão"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`last_four_digits`",
    "0-1": "**string**",
    "0-2": "Últimos 4 dígitos do cartão.",
    "1-0": "`holder_name`",
    "1-1": "**string**",
    "1-2": "Nome impresso no cartão.",
    "2-0": "`exp_month`",
    "2-1": "**datetime**",
    "2-2": "Mês de expiração do cartão.",
    "3-0": "`exp_year`",
    "3-1": "**datetime**",
    "3-2": "Ano de expiração do cartão."
  },
  "cols": 3,
  "rows": 4
}
[/block]