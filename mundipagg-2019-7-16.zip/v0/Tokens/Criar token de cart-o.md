---
title: "Criar token de cartão"
excerpt: ""
---
[block:callout]
{
  "type": "info",
  "body": "O token de cartão expira em 60 segundos."
}
[/block]