---
title: "Objeto cobrança"
excerpt: ""
---
Para realizar cobranças de cartão de crédito ou boleto, você deve criar um objeto `charge`.
As cobranças são identificados por uma chave aleatória. Ex: `ch_x50ZBkRQhzhxXzpj`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`gateway_id`",
    "2-0": "`amount`",
    "3-0": "`payment_method`",
    "4-0": "`status`",
    "5-0": "`due_at`",
    "6-0": "`created_at`",
    "7-0": "`updated_at`",
    "8-0": "`customer`",
    "9-0": "`invoice`",
    "10-0": "`last_transaction`",
    "11-0": "`metadata`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**integer**",
    "3-1": "**integer**",
    "4-1": "**string**",
    "5-1": "**datetime**",
    "6-1": "**datetime**",
    "7-1": "**datetime**",
    "8-1": "**object**",
    "9-1": "**object**",
    "10-1": "**object**",
    "11-1": "**object**",
    "0-2": "Código da cobrança.",
    "1-2": "Código do pedido no gateway de pagamento.",
    "2-2": "Valor da cobrança.",
    "3-2": "Meio de pagamento.",
    "4-2": "Status da cobrança.",
    "5-2": "Data de vencimento da cobrança.",
    "6-2": "Data de criação da cobrança.",
    "7-2": "Data de atualização da cobrança.",
    "8-2": "Dados do cliente. [Leia mais sobre cliente](ref:objeto-cliente).",
    "9-2": "Dados da fatura.",
    "10-2": "Informações sobre a última transação da cobrança.",
    "11-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pedido."
  },
  "cols": 3,
  "rows": 12
}
[/block]