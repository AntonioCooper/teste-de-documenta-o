---
title: "Precificação de planos e assinaturas"
excerpt: ""
---
As assinaturas e os planos possuem quatro tipos de precificação (`pricing_scheme`).

**UNIT**
R$5,00 - Por usuário

Se um cliente utilizar 2 usuários o valor será R$10,00 (2 x R$5,00).

**PACKAGE**
R$50,00 - Até 10 usuários
R$70,00 - Até 50 usuários
R$100,00 - Até 100 usuários
Cada usuário acima de 100 custa R$0,90

Se um cliente utilizar 25 usuários o valor será R$50,00

**VOLUME**
1~10 - Cada usuário custa R$1,00
11~20 - Cada usuário custa R$0,90
21~50 - Cada usuário custa R$0,80
Cada usuário acima de 50 custa R$0,70

Se um cliente utilizar 25 usuários o valor total será R$20,00 (25 x R$0,80)

**TIER**
1~10 - Cada usuário custa R$1,00
11~20 - Cada usuário custa R$0,90
21~50 - Cada usuário custa R$0,80
Cada usuário acima de 50 custa R$0,70

Se um cliente utilizar 25 usuários o valor total será R$23,00 (10 x R$1,00 + 10 x R$0,90 + 5 x R$0,80)