---
title: "Entregas"
excerpt: ""
---
[block:api-header]
{
  "title": "Objeto Entrega (Shipping)"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`amount`",
    "0-1": "**integer** ",
    "0-2": "Valor da entrega.",
    "1-0": "`description`",
    "1-1": "**string** ",
    "1-2": "Descrição da entrega. Ex: Express Shipping.",
    "2-0": "`recipient_Name`",
    "2-1": "**string** ",
    "2-2": "Nome de quem receberá a entrega.",
    "3-2": "Telefone de quem receberá a entrega.",
    "3-0": "`recipient_Phone`",
    "4-0": "`address`",
    "3-1": "**string** ",
    "4-1": "**objeto**",
    "4-2": "Endereço de entrega. [Leia mais sobre Endereço](ref:objeto-endereco)."
  },
  "cols": 3,
  "rows": 5
}
[/block]