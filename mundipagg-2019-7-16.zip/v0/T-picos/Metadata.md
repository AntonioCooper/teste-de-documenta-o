---
title: "Metadata"
excerpt: ""
---
A maioria dos nossos objetos - como [Customer](http://docs.mundipagg.com/v3.0/docs/o-comprador), [Credit Card](http://docs.mundipagg.com/v3.0/docs/o-cart%C3%A3o-de-cr%C3%A9dito), [Address](http://docs.mundipagg.com/v3.0/docs/o-endere%C3%A7o), [Subscription](http://docs.mundipagg.com/v3.0/docs/a-assinatura), [Plan](http://docs.mundipagg.com/v3.0/docs/o-plano), [Order ](http://docs.mundipagg.com/v3.0/docs/o-pedido) e [Charge ](http://docs.mundipagg.com/v3.0/docs/a-cobran%C3%A7a)- possuem o parâmetro `metadata`, pelo qual você consegue armazenar dados chave-valor.

Metadados são interessantes para o armazenamento estruturado de dados complementares relacionados a algum objeto. Um exemplo seria adicionarmos o nome do pai de um **[customer ](http://docs.mundipagg.com/v3.0/docs/o-comprador)** para termos essa informação em nossa carteira de clientes.
[block:code]
{
  "codes": [
    {
      "code": "{\n  ...\n  \"metadata\": {\n    \"meu_campo1\": \"valor1\",\n    \"meu_campo2\": \"valor2\",\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]