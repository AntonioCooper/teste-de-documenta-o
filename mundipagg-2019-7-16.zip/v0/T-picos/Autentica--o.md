---
title: "Autenticação"
excerpt: ""
---
Para se autenticar conosco você deve enviar a** Chave de API** no cabeçalho *Authorization*, seguindo o padrão da [HTTP Basic Authentication](https://en.wikipedia.org/wiki/Basic_access_authentication). 
Não é necessário o envio de nenhuma senha, apenas da chave.
[block:code]
{
  "codes": [
    {
      "code": "\n// Install-Package RestSharp\n\nvar key = \"sk_test_tra6ezsW3BtPPXQa\";\nvar api = \"https://api.mundipagg.com/core/v1.0\";\n\nvar client = new RestClient(api);\nclient.Authenticator = new HttpBasicAuthenticator(key, null);\n\nvar response = client.Execute(...);",
      "language": "csharp"
    }
  ]
}
[/block]
Além disso, podem ainda ser adicionados os headers Content-Type e Accept, com o valor application/json:

`Content-Type: application/json`
`Accept: application/json`
<br>
[block:api-header]
{
  "title": "Você já tem sua Chave de API?"
}
[/block]
Antes de começar você precisa obter sua chave de API. Entre em contato com a nossa área comercial para conhecer nossos planos: *comercial@mundipagg.com*.

Se você já é nosso cliente, solicite a chave de API à nossa área de Relacionamento com o Cliente, pelo email: *suporte@mundipagg.com*.

Você receberá duas **chaves secretas da API**, uma de Sandbox e outra de Produção, no seguinte formato:

`Chave de Sandbox: sk_test_tra6ezsW3BtPPXQa`
`Chave de Produção: sk_fbt5cahT3BbHAXZy`
[block:callout]
{
  "type": "danger",
  "body": "A sua Chave da API é secreta e não deve ser compartilhada.",
  "title": "Atenção"
}
[/block]
Além disso, receberá também duas chaves públicas da API. Essas chaves serão utilizadas para representar a sua loja na integração com o **checkout transparente**.

`Chave pública de produção: pk_ghc3waxT4BaCZXAb`
`Chave pública de sandbox: pk_test_gaa5xzfz7CfPPZAv`