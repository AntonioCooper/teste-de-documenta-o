---
title: "Endpoint"
excerpt: ""
---
As chamadas de testes e de produção devem ser feitas para o mesmo endpoint. O que definirá se a transação irá utilizar o nosso simulador ou se seguirá o fluxo de produção é a chave de API enviada.
[block:callout]
{
  "type": "info",
  "body": "https://api.mundipagg.com/core/v1.0",
  "title": "Endpoint"
}
[/block]