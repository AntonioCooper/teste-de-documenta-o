---
title: "Objeto cliente"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "0-0": "`id`",
    "1-0": "`name`",
    "2-0": "`email`",
    "3-0": "`phone`",
    "4-0": "`document`",
    "5-0": "`person_type`",
    "6-0": "`address`",
    "7-0": "`fb_id`",
    "8-0": "`fb_access_token`",
    "9-0": "`delinquent`",
    "10-0": "`created_at`",
    "11-0": "`updated_at`",
    "12-0": "`birthdate`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**string**",
    "4-1": "**string**",
    "5-1": "**enum**",
    "6-1": "**object**",
    "7-1": "**integer**",
    "8-1": "**string**",
    "9-1": "**boolean**",
    "10-1": "**datetime**",
    "11-1": "**datetime**",
    "12-1": "**datetime**",
    "0-2": "Código do cliente.",
    "1-2": "Nome.",
    "2-2": "E-mail.",
    "3-2": "Telefone.",
    "4-2": "CPF ou CNPJ.",
    "5-2": "Tipo de pessoa. Os valores possíveis são *person* e *company*.",
    "6-2": "Endereço do comprador. [Leis mais sobre endereço](ref:objeto-endereço).",
    "7-2": "Código do comprador no Facebook.",
    "8-2": "[Token de acesso](https://developers.facebook.com/docs/facebook-login/access-tokens/?locale=pt_BR) do Facebook. Usado para fazer chamadas da Graph API e obter informações do usuário.",
    "9-2": "Indica se o comprador está inadimplente.",
    "10-2": "Data de criação.",
    "11-2": "Data de atualização.",
    "12-2": "Data de nascimento do cliente.",
    "13-0": "`metadata`",
    "13-1": "**object**",
    "13-2": "Informações adicionais sobre o comprador. [Leia mais sobre metadata](ref:objeto-comprador)."
  },
  "cols": 3,
  "rows": 14
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "O campo e-mail é único",
  "title": "Atenção"
}
[/block]