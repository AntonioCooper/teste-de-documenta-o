---
title: "Objeto pedido"
excerpt: ""
---
Para realizar pedidos de cartão de crédito ou boleto, você deve criar um objeto `order`.
Os pedidos são identificados por uma chave aleatória. Ex: `or_x50ZBkRQhzhxXzpj`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`currency`",
    "2-0": "`status`",
    "3-0": "`created_at`",
    "4-0": "`customer`",
    "5-0": "`shipping`",
    "6-0": "`charge`",
    "7-0": "`items`",
    "8-0": "`metadata`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**datetime**",
    "4-1": "**object**",
    "5-1": "**object**",
    "6-1": "**object**",
    "7-1": "**object**",
    "8-1": "**object**",
    "0-2": "Código do pedido.",
    "1-2": "Moeda.",
    "2-2": "Status do pedido.",
    "3-2": "Data de criação do pedido.",
    "4-2": "Dados do comprador. Leia mais sobre comprador.",
    "5-2": "Dados para entrega. Leia mais sobre entrega.",
    "6-2": "Dados da cobrança. Leia mais sobre cobrança.",
    "7-2": "Itens do pedido. Leia mais sobre itens do pedido.",
    "8-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pedido.",
    "9-0": "`closed`",
    "9-1": "**boolean**",
    "9-2": "Indica se o pedido está aberto ou não."
  },
  "cols": 3,
  "rows": 10
}
[/block]