---
title: "Remover todos os itens"
excerpt: ""
---
