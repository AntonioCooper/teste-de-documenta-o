---
title: "Objeto item do pedido"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "amount [obrigatório]",
    "0-1": "integer",
    "0-2": "Valor unitário",
    "1-0": "description",
    "1-1": "string",
    "1-2": "Descrição do item",
    "2-0": "quantity",
    "2-1": "short",
    "2-2": "Quantidade de itens"
  },
  "cols": 3,
  "rows": 3
}
[/block]