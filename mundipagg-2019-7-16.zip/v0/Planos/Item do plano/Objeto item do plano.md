---
title: "Objeto item do plano"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`name`",
    "2-0": "`description`",
    "3-0": "`quantity`",
    "4-0": "`cycles`",
    "5-0": "`interval`",
    "6-0": "`created_at`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "7-0": "`updated_at`",
    "8-0": "`deleted_at`",
    "9-0": "`pricing_scheme`",
    "10-0": "`plan`",
    "3-1": "**integer**",
    "4-1": "**integer**",
    "5-1": "**string**",
    "6-1": "**datetime**",
    "7-1": "**datetime**",
    "8-1": "**datetime**",
    "9-1": "**object**",
    "10-1": "**object**",
    "0-2": "Código do item do plano.",
    "1-2": "Nome.",
    "2-2": "Descrição.",
    "3-2": "Quantidade.",
    "4-2": "Ciclos de cobrança. Ex: 1 ciclo representa um item que será cobrado apenas uma vez. Caso não seja informado, o item será cobrado até que seja desativado.",
    "5-2": "Status do item do pedido. Os valores possíveis são **active**, **inactive** ou **deleted**.",
    "6-2": "Data de criação.",
    "7-2": "Data de atualização.",
    "8-2": "Data de exclusão.",
    "9-2": "Esquema de precificação. [Saiba mais sobre precificação](ref:precificacao).",
    "10-2": "Plano. [Leia mais sobre plano](ref:plano)."
  },
  "cols": 3,
  "rows": 11
}
[/block]