---
title: "Objeto webhook"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "```id```",
    "0-1": "**string** ",
    "0-2": "Código do webhook.",
    "1-0": "```url```",
    "1-1": "**string**",
    "2-1": "**enum**",
    "3-1": "**enum**",
    "4-1": "**string**",
    "5-1": "**datetime**",
    "6-1": "**string**",
    "7-1": "**string**",
    "8-1": "**object**",
    "2-0": "```event```",
    "3-0": "```status```",
    "4-0": "```attempts```",
    "5-0": "```last_attempt```",
    "6-0": "```response_status```",
    "7-0": "```response_raw```",
    "8-0": "```data```",
    "1-2": "Endereço do alvo.",
    "2-2": "Evento.",
    "3-2": "**pending**, **sent** ou **failed**",
    "4-2": "Tentativas realizadas.",
    "5-2": "Data da última tentativa.",
    "6-2": "Código de resposta do servidor.",
    "7-2": "Resposta do servidor.",
    "8-2": "Conteúdo da requisição."
  },
  "cols": 3,
  "rows": 9
}
[/block]

[block:api-header]
{
  "title": "Exemplo de objeto webhook"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"id\": \"hook_98kmOL1sMfnZqoPL\",\n  \"url\": \"https://70cfee17.ngrok.io/notifications/payment\",\n  \"event\": \"order.paid\",\n  \"status\": \"failed\",\n  \"attempts\": \"3/3\",\n  \"last_attempt\": \"2017-03-24T21:32:07\",\n  \"created_at\": \"2017-03-24T21:21:59\",\n  \"response_status\": 404,\n  \"response_raw\": \"Tunnel 70cfee17.ngrok.io not found\",\n  \"data\": {\n    \"id\": \"or_e36l73IwgF7MlJwx\",\n    \"code\": \"ER30H4MU4N\",\n    \"amount\": 199,\n    \"currency\": \"BRL\",\n    \"closed\": true,\n    \"items\": [\n      {\n        \"id\": \"oi_NqW9Rb2LTbsqRa3n\",\n        \"description\": \"FLIP Payment\",\n        \"amount\": 199,\n        \"quantity\": 1,\n        \"status\": \"active\",\n        \"created_at\": \"2017-03-24T21:21:58\",\n        \"updated_at\": \"2017-03-24T21:21:58\"\n      }\n    ],\n    \"customer\": {\n      \"id\": \"cus_le6ZqXjiBSEOWdoA\",\n      \"name\": \"Matheus Moreira\",\n      \"phone\": \"+5521981340010\",\n      \"email\": \"mmoreira@mundipagg.com\",\n      \"delinquent\": false,\n      \"created_at\": \"2016-11-25T23:45:04\",\n      \"updated_at\": \"2016-12-26T21:34:45\"\n    },\n    \"status\": \"paid\",\n    \"created_at\": \"2017-03-24T21:21:58\",\n    \"updated_at\": \"2017-03-24T21:21:59\",\n    \"closed_at\": \"2017-03-24T21:21:59\",\n    \"charge\": {\n      \"id\": \"ch_56YNm9akt4i6mKQ8\",\n      \"code\": \"ER30H4MU4N\",\n      \"gateway_id\": \"b21c20f8-21e1-4f56-ac1c-34425c9e9dc9\",\n      \"amount\": 199,\n      \"status\": \"paid\",\n      \"currency\": \"BRL\",\n      \"payment_method\": \"credit_card\",\n      \"due_at\": \"2017-03-24T00:00:00\",\n      \"paid_at\": \"2017-03-24T21:21:59\",\n      \"created_at\": \"2017-03-24T21:21:58\",\n      \"updated_at\": \"2017-03-24T21:21:58\",\n      \"customer\": {\n        \"id\": \"cus_le6ZqXjiBSEOWdoA\",\n        \"name\": \"Matheus Moreira\",\n        \"phone\": \"+5521981340010\",\n        \"email\": \"mmoreira@mundipagg.com\",\n        \"delinquent\": false,\n        \"created_at\": \"2016-11-25T23:45:04\",\n        \"updated_at\": \"2016-12-26T21:34:45\"\n      },\n      \"last_transaction\": {\n        \"id\": \"tran_MpnYkMXhOBTb7Ze8\",\n        \"transaction_type\": \"credit_card\",\n        \"gateway_id\": \"9ac7ee2c-02a1-4b19-9f7e-168739a0427b\",\n        \"amount\": 199,\n        \"status\": \"captured\",\n        \"success\": true,\n        \"installments\": 1,\n        \"acquirer_name\": \"simulator\",\n        \"acquirer_affiliation_code\": \"MUNDI\",\n        \"acquirer_tid\": \"266699\",\n        \"acquirer_nsu\": \"848780\",\n        \"acquirer_auth_code\": \"MUNDI\",\n        \"acquirer_message\": \"Simulator|Transação de simulação autorizada com sucesso\",\n        \"acquirer_return_code\": \"0\",\n        \"operation_type\": \"auth_and_capture\",\n        \"credit_card\": {\n          \"id\": \"card_yB3ma9rS8HW7mnA9\",\n          \"last_four_digits\": \"8229\",\n          \"brand\": \"Amex\",\n          \"holder_name\": \"Tony Stark\",\n          \"exp_month\": 1,\n          \"exp_year\": 2018,\n          \"status\": \"active\",\n          \"created_at\": \"2016-11-29T21:14:07\",\n          \"updated_at\": \"2016-11-29T21:14:07\",\n          \"billing_address\": {\n            \"street\": \"Malibu Point\",\n            \"number\": \"10880\",\n            \"zip_code\": \"90265\",\n            \"neighborhood\": \"Central Malibu\",\n            \"city\": \"Malibu\",\n            \"state\": \"CA\",\n            \"country\": \"US\"\n          }\n        },\n        \"created_at\": \"2017-03-24T21:21:58\",\n        \"updated_at\": \"2017-03-24T21:21:58\"\n      }\n    },\n    \"charges\": [\n      {\n        \"id\": \"ch_56YNm9akt4i6mKQ8\",\n        \"code\": \"ER30H4MU4N\",\n        \"gateway_id\": \"b21c20f8-21e1-4f56-ac1c-34425c9e9dc9\",\n        \"amount\": 199,\n        \"status\": \"paid\",\n        \"currency\": \"BRL\",\n        \"payment_method\": \"credit_card\",\n        \"due_at\": \"2017-03-24T00:00:00\",\n        \"paid_at\": \"2017-03-24T21:21:59\",\n        \"created_at\": \"2017-03-24T21:21:58\",\n        \"updated_at\": \"2017-03-24T21:21:58\",\n        \"customer\": {\n          \"id\": \"cus_le6ZqXjiBSEOWdoA\",\n          \"name\": \"Matheus Moreira\",\n          \"phone\": \"+5521981340010\",\n          \"email\": \"mmoreira@mundipagg.com\",\n          \"delinquent\": false,\n          \"created_at\": \"2016-11-25T23:45:04\",\n          \"updated_at\": \"2016-12-26T21:34:45\"\n        },\n        \"last_transaction\": {\n          \"id\": \"tran_MpnYkMXhOBTb7Ze8\",\n          \"transaction_type\": \"credit_card\",\n          \"gateway_id\": \"9ac7ee2c-02a1-4b19-9f7e-168739a0427b\",\n          \"amount\": 199,\n          \"status\": \"captured\",\n          \"success\": true,\n          \"installments\": 1,\n          \"acquirer_name\": \"simulator\",\n          \"acquirer_affiliation_code\": \"MUNDI\",\n          \"acquirer_tid\": \"266699\",\n          \"acquirer_nsu\": \"848780\",\n          \"acquirer_auth_code\": \"MUNDI\",\n          \"acquirer_message\": \"Simulator|Transação de simulação autorizada com sucesso\",\n          \"acquirer_return_code\": \"0\",\n          \"operation_type\": \"auth_and_capture\",\n          \"credit_card\": {\n            \"id\": \"card_yB3ma9rS8HW7mnA9\",\n            \"last_four_digits\": \"8229\",\n            \"brand\": \"Amex\",\n            \"holder_name\": \"Tony Stark\",\n            \"exp_month\": 1,\n            \"exp_year\": 2018,\n            \"status\": \"active\",\n            \"created_at\": \"2016-11-29T21:14:07\",\n            \"updated_at\": \"2016-11-29T21:14:07\",\n            \"billing_address\": {\n              \"street\": \"Malibu Point\",\n              \"number\": \"10880\",\n              \"zip_code\": \"90265\",\n              \"neighborhood\": \"Central Malibu\",\n              \"city\": \"Malibu\",\n              \"state\": \"CA\",\n              \"country\": \"US\"\n            }\n          },\n          \"created_at\": \"2017-03-24T21:21:58\",\n          \"updated_at\": \"2017-03-24T21:21:58\"\n        }\n      }\n    ]\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Inspeção e debug",
  "body": "Você pode usar o [RequestBin](http://requestb.in) para facilmente inspecionar e debugar os webhooks que recebe."
}
[/block]