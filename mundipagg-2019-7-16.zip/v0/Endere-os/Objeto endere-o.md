---
title: "Objeto endereço"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**enum**",
    "4-1": "**integer**",
    "5-1": "**string**",
    "6-1": "**string**",
    "7-1": "**string**",
    "8-1": "**string**",
    "9-1": "**enum**",
    "10-1": "**datetime**",
    "11-1": "**datetime**",
    "12-1": "**datetime**",
    "13-1": "**object**",
    "0-0": "`id`",
    "1-0": "`street`",
    "3-0": "`complement`",
    "2-0": "`number`",
    "4-0": "`zip_code`",
    "5-0": "`neighorhood`",
    "6-0": "`city`",
    "7-0": "`state`",
    "8-0": "`country`",
    "9-0": "`status`",
    "10-0": "`created_at`",
    "11-0": "`updated_at`",
    "12-0": "`deleted_at`",
    "13-0": "`customer`",
    "14-0": "`metadata`",
    "14-1": "**object**",
    "0-2": "Código do endereço.",
    "1-2": "Logradouro.",
    "2-2": "Número.",
    "3-2": "Complemento.",
    "4-2": "CEP.",
    "5-2": "Bairro.",
    "6-2": "Cidade.",
    "7-2": "Estado.",
    "8-2": "País.",
    "9-2": "Os status do endereço. os valores possíveis são: **active **ou **deleted**.",
    "10-2": "Data de criação.",
    "11-2": "Data de atualização.",
    "12-2": "Data de exclusão.",
    "14-2": "Informações adicionais sobre o cartão. [Leia mais sobre metadata](ref:objeto-cartão).",
    "13-2": "Cliente. [Leia mais sobre cliente](ref:objeto-cliente) ."
  },
  "cols": 3,
  "rows": 15
}
[/block]