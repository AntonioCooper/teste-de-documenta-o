---
title: "Bem-vindo!"
excerpt: "Queremos que você conheça um novo mundo de pagamentos online!\n\nNossas soluções de pagamento permitem que você transacione de forma rápida, simples e segura. \n\nPensamos em cada passo para que você tenha uma experiência única e consiga transacionar com poucas linhas de código."
---
[block:api-header]
{
  "title": "Introdução"
}
[/block]
A API da Mundi foi desenvolvida de acordo com os melhores padrões [REST](https://en.wikipedia.org/wiki/Representational_State_Transfer). Seus *endpoints *possuem nomes intuitivos que indicam os recursos disponíveis. As operações são feitas de acordo com os verbos HTTP, com corpos de mensagem em [JSON](http://www.json.org/). As respostas podem ser interpretadas através do código de status HTTP. Isso permite que quaisquer aplicações consumam a API de forma simples e clara, independente da linguagem utilizada. Para facilitar ainda mais a integração, fornecemos SDKs em todas as principais linguagens de programação.
Também oferecemos uma chave de API de testes, para que a integração seja feita com testes a vontade, sem se preocupar com cobranças reais nos cartões de crédito utilizados.