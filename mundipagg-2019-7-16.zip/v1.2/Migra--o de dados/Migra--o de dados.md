---
title: "Migração de dados"
excerpt: "Você pode importar dados de cartões e clientes de outras plataformas!"
---
Possibilitamos que você consiga migrar dados dos seus clientes para a nossa plataforma. Para isso, é preciso que você disponibilize em arquivo no formato .CSV com os seguintes dados:





[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Obrigatório",
    "0-0": "Nome",
    "h-2": "Descrição",
    "0-1": "(/)",
    "1-0": "E-mail",
    "2-0": "Documento (CPF ou CNPJ)",
    "0-2": "Nome do cliente",
    "1-1": "x",
    "1-2": "E-mail do cliente",
    "3-0": "Code",
    "3-2": "Código do cliente no sistema da loja",
    "4-0": "Token",
    "4-1": "(/)",
    "4-2": "Identificador do cartão na plataforma de origem.",
    "2-1": "x",
    "3-1": "x"
  },
  "cols": 3,
  "rows": 5
}
[/block]


Para solicitar a migração dos dados, basta entrar em contato conosco através [suporte@mundipagg.com](mailto:suporte@mundipagg.com)!




[block:callout]
{
  "type": "danger",
  "title": "Duração da Migração",
  "body": "A duração da migração vai depender da nossa integração com plataforma de origem e da quantidade de dados a serem exportados."
}
[/block]