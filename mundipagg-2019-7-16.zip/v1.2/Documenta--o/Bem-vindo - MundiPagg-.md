---
title: "Bem-vindo à MundiPagg!"
excerpt: "Aqui, você transaciona de forma rápida, simples e segura. \n\nPensamos em cada passo para que você tenha uma experiência única e consiga transacionar com poucas linhas de código.\n\nNesta documentação você pode explorar todos os produtos e funcionalidades que a nossa API oferece e adaptá-los ao seu sistema, seja ele no browser, mobile ou sistema interno."
---
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b00ac41-Imagens_Doc.png",
        "Imagens_Doc.png",
        778,
        295,
        "#2d98bc"
      ],
      "sizing": "80"
    }
  ]
}
[/block]
## [**Documentação**](https://docs.mundipagg.com/docs/getting-started)

A API MundiPagg é uma plataforma que gera negócios através da tecnologia em pagamentos. Com quatro macro funcionalidades e sua estrutura modular, a API viabiliza formas de cobrança de sistemas inovadores em que não necessariamente o pagamento envolve só a loja e o comprador.

Nesta documentação você pode explorar todos os produtos e funcionalidades que a nossa API oferece!

  * [**Pagamentos**](https://docs.mundipagg.com/docs/cobran%C3%A7a)
Processamos suas transações com segurança e praticidade, otimizando a experiência do usuário com foco total na sua conversão. Você pode optar por cartão de crédito, boleto ou qualquer outro meio de pagamento que tivermos integrado.

  * [**Assinaturas**](https://docs.mundipagg.com/docs/assinatura)
Construa e gerencie todos os aspectos do seu negócio com cobranças recorrentes.
Estudamos o mercado de assinaturas a fundo para criar a melhor e mais flexível solução para o seu negócio.

  * [**Checkout**](https://docs.mundipagg.com/docs/transparente)
Em busca de segurança e praticidade desenvolvemos diversos modelos de checkout que se encaixam a qualquer modelo de negócio. Com nossas soluções você não trafegará dados de cartão pelo seu sistema, podendo enviá-los diretamente para nossa API *PCI Compliance* (certificação internacional que permite à Mundipagg o armazenamento dos dados de cartão de créditos dos clientes).

  * [**Gestão de Clientes**](https://docs.mundipagg.com/docs/carteira-de-clientes)
Você pode construir e gerenciar sua carteira de clientes através da nossa solução. Sua carteira será alimentada automaticamente sempre que uma cobrança for gerada, seja de forma avulsa, através de pedidos ou assinaturas.
[block:callout]
{
  "type": "info",
  "body": "Para entender melhor sobre os endpoints e requisições, acesse nossa [API Reference](https://docs.mundipagg.com/v1/reference#bem-vindo).",
  "title": "API Reference"
}
[/block]