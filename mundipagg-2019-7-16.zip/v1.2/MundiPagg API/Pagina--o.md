---
title: "Paginação"
excerpt: ""
---
A API MundiPagg tem suporte a buscas em massa através dos métodos "list". Deste modo, você pode listar compradores, assinaturas, pedidos e diversos outros objetos da Mundipagg. Todos esses métodos de listagem possuem uma estrutura em comum, que é a de paginação.
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"data\": [...],\n  \"paging\": {\n    \"total\": 11,\n    \"previous\": null,\n    \"next\": \"{url}?page=2&size=10\"\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]