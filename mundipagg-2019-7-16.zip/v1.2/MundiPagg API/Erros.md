---
title: "Erros"
excerpt: ""
---
A nossa API valida cada um dos campos enviados na requisição (**request**) antes de prosseguir com a criação, consulta ou gerenciamento dos pedidos, transações e recursos.

Utilizamos os códigos de resposta convencionais do HTTP para indicar o sucesso ou a falha de uma requisição. Sendo assim, códigos **2xx** indicam sucesso, **4xx** indicam erro por algum dado informado incorretamente (por exemplo, algum campo obrigatório não enviado ou um cartão sem data de validade) e **5xx** indicando erro nos servidores da MundiPagg.

**Tabela dos HTTP Status Code:** 
[block:parameters]
{
  "data": {
    "0-0": "`200`",
    "1-0": "`400`",
    "2-0": "`401`",
    "3-0": "`404`",
    "4-0": "`412`",
    "5-0": "`422`",
    "6-0": "`500`",
    "0-1": "OK",
    "1-1": "Bad Request",
    "2-1": "Unauthorized",
    "3-1": "Not Found",
    "4-1": "Precondition Failed",
    "5-1": "Unprocessable Entity",
    "6-1": "Internal Server Error",
    "0-2": "Sucesso",
    "1-2": "Requisição inválida",
    "2-2": "Chave de API inválida",
    "3-2": "O recurso solicitado não existe",
    "4-2": "Parâmetros válidos mas a requisição falhou",
    "5-2": "Parâmetros inválidos",
    "6-2": "Ocorreu um erro interno"
  },
  "cols": 3,
  "rows": 7
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"message\": \"Customer not found.\"\n}",
      "language": "json",
      "name": "Exemplo (404)"
    }
  ]
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"message\": \"The request is invalid.\",\n  \"errors\": {\n    \"customer.name\": [\n      \"The name field is required.\"\n    ]\n  },\n  \"request\": {\n    \"name\": null,\n    \"email\": \"tstark@avengers.com\",\n  }\n}",
      "language": "json",
      "name": "Exemplo (422)"
    }
  ]
}
[/block]