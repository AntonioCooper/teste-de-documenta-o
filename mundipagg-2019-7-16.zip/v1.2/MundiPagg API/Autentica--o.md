---
title: "Autenticação"
excerpt: ""
---
Para se autenticar conosco você deve enviar a** Chave de API** no cabeçalho **Authorization**, seguindo o padrão da [HTTP Basic Authentication](https://en.wikipedia.org/wiki/Basic_access_authentication). 

[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing System.Collections.Generic;\nusing System.Web.Mvc;\n\nnamespace MundipaggTest.Controllers {\n  \n  public class HomeController : Controller {\n\n    public void Authenticate() {\n      \n        // Secret key provided by MundiPagg\n        string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n      \n        // Password is blank\n        string basicAuthPassword = \"\"\n\n        // Realizes the authentication \n        var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n       \n      \t\n        // After authentication, the access to services is released\n      \tvar response = client.Charges.CreateCharge(...)\n    }\n  }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Além disso, podem ainda ser adicionados os headers Content-Type e Accept, com o valor application/json:

`Content-Type: application/json`
`Accept: application/json`
<br>
[block:api-header]
{
  "title": "Você já tem sua Chave de API?"
}
[/block]
Antes de começar, você precisa obter sua chave de API. Para isso, entre em contato com a nossa área comercial, através do e-mail: *contato@mundipagg.com*, para conhecer nossos planos.

Se você já é nosso cliente, solicite a chave de API à nossa área de Relacionamento com o Cliente, pelo e-mail: *suporte@mundipagg.com*.

Você receberá uma**chaves secretas da API**, de Sandbox , no seguinte formato:

Chave de sandbox: `sk_test_tra6ezsW3BtPPXQa`.

Chave de produção possui o seguinte formato : `sk_fbt5cahT3BbHAXZy` . Que sera recebida apos o fechamento do contrato.


[block:callout]
{
  "type": "danger",
  "body": "A sua Chave da API é secreta e não deve ser compartilhada.",
  "title": "Atenção"
}
[/block]
Além disso, você receberá também duas chaves públicas da API. Essas chaves serão utilizadas para representar a sua loja na integração com o [checkout transparente](ref:sobre-checkout-transparente).

Chave pública de produção: `pk_ghc3waxT4BaCZXAb` 
Chave pública de sandbox: `pk_test_gaa5xzfz7CfPPZAv` .