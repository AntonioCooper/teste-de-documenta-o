---
title: "Segurança na Integração"
excerpt: ""
---
Para manter a segurança na troca de mensagens é necessário que nossos servidores sejam liberados no seu ambiente. Recomendamos fortemente que você libere o domínio: **api.mundipagg.com**. Caso não seja possível a liberação do domínio, segue abaixo a lista de IP's que devem ser liberados:
[block:callout]
{
  "type": "warning",
  "body": "208.93.65.185\n40.143.28.57\n208.93.65.172\n 40.143.28.44",
  "title": "IPs"
}
[/block]
Além disso, por sermos uma empresa PCI precisamos manter a segurança na troca de informações com a nossa API. Seguem as configurações aceitas:
[block:callout]
{
  "type": "warning",
  "title": "Protocolos aceitos",
  "body": "TLS 1.1\nTLS 1.2 (A MundiPagg recomenda fortemente a utilização deste protocolo)"
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "SHA256\nSHA384\nSHA512",
  "title": "Hashs Codes"
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Cipher Suites",
  "body": "Com criptografia igual ou superior a 128 bits."
}
[/block]