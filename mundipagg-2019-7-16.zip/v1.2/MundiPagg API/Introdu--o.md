---
title: "Introdução"
excerpt: ""
---
A API MundiPagg foi desenvolvida de acordo com os melhores padrões [REST](https://en.wikipedia.org/wiki/Representational_State_Transfer). Seus **endpoints** possuem nomes intuitivos que indicam os recursos disponíveis. As operações são feitas de acordo com os verbos HTTP, com corpos de mensagem em [JSON](http://www.json.org/).

As respostas podem ser interpretadas através do código de status HTTP. Isso permite que quaisquer aplicações consumam a API de forma simples e clara, independente da linguagem utilizada. Para facilitar ainda mais a integração, fornecemos SDKs em todas as principais linguagens de programação. [Saiba mais sobre as nossas SDKs](https://docs.mundipagg.com/docs/sdk-c).

Também oferecemos uma chave de testes na API para que a integração seja feita com testes a vontade, sem se preocupar com cobranças reais nos cartões de crédito utilizados.