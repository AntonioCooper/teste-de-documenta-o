---
title: "Listar clientes"
excerpt: ""
---
[block:callout]
{
  "type": "info",
  "title": "Paginação",
  "body": "[Saiba mais sobre paginação](ref:paginacao)."
}
[/block]