---
title: "Criar cliente"
excerpt: ""
---
[block:callout]
{
  "type": "warning",
  "body": "É importante destacar que o campo e-mail é único, ou seja, caso seja requisitada a criação de um cliente com um e-mail já cadastrado, será mantido o mesmo `customer_id` relativo ao cadastro já realizado. Os demais dados serão atualizados."
}
[/block]