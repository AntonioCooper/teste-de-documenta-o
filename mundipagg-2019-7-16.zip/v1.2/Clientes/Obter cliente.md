---
title: "Obter cliente"
excerpt: ""
---
[block:callout]
{
  "type": "warning",
  "body": "Para a autenticação deste endpoint via `access_token`, deverá ser enviada a public_key da loja no parâmetro `appId` na query string. [Saiba mais sobre Access Tokens](ref:access-token).",
  "title": "Access Token"
}
[/block]