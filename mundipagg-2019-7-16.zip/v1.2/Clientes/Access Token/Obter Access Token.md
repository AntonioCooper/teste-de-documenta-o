---
title: "Obter Access Token"
excerpt: ""
---
