---
title: "Objeto Access Token"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`code`",
    "2-0": "`status`",
    "3-0": "`created_at`",
    "4-0": "`customer`",
    "0-1": "**string**",
    "1-1": "**string**",
    "3-1": "**datetime**",
    "2-1": "**enum**",
    "4-1": "**objeto**",
    "0-2": "Código do Access Token.",
    "1-2": "Access token.",
    "2-2": "Status do Access Token. Valores possíveis: **active** ou **deleted**",
    "3-2": "Data de criação do Access Token.",
    "4-2": "Dados do cliente. [Saiba mais sobre clientes](ref:objeto-cliente)",
    "5-0": "`expires_in`",
    "5-1": "**integer**",
    "5-2": "Em quantos minutos após a criação o token irá expirar.",
    "6-0": "`deleted_at`",
    "6-1": "**datetime**",
    "6-2": "Data de exclusão do Access Token."
  },
  "cols": 3,
  "rows": 7
}
[/block]