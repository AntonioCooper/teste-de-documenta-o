---
title: "Obter fatura"
excerpt: ""
---
