---
title: "SDK Python"
excerpt: "SDK(Software Development Kit) é um conjunto de ferramentas de desenvolvimento de software capazes de facilitar a integração de sistemas em diferentes linguagens com a API da Mundipagg."
---
Atualmente temos uma versão beta em Python para integração através de um pacote disponibilizado para instalação. Assim, qualquer nova funcionalidade pode ser incorporada em seu sistema.

Adicione o pacote **mundiapi** no seu projeto através do [PYPI](https://pypi.python.org/pypi/mundiapi)!
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0ed3bca-PYPI.PNG",
        "PYPI.PNG",
        1037,
        450,
        "#e8e8e6"
      ]
    }
  ]
}
[/block]
Ou faça o download do projeto em nosso [repositório no GitHub](https://github.com/mundipagg/MundiAPI-PYTHON)!

Quaisquer dúvidas ou feedbacks podem ser encaminhados para o e-mail **integracao@mundipagg.com**.