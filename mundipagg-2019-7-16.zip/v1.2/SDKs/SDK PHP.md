---
title: "SDK PHP"
excerpt: "SDK(Software Development Kit) é um conjunto de ferramentas de desenvolvimento de software capazes de facilitar a integração de sistemas em diferentes linguagens com a API da Mundipagg."
---
Atualmente temos uma versão beta em PHP para integração através de um pacote disponibilizado para instalação. Assim, qualquer nova funcionalidade pode ser incorporada em seu sistema.

Adicione o pacote **mundiapi** no seu projeto através do [Packagist](https://packagist.org/packages/mundipagg/mundiapi)!
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4429636-packagist.PNG",
        "packagist.PNG",
        1160,
        564,
        "#fbfbfb"
      ]
    }
  ]
}
[/block]
Ou faça o download do projeto em nosso [repositório no GitHub](https://github.com/mundipagg/MundiAPI-PHP)!

Quaisquer dúvidas ou feedbacks podem ser encaminhados para o e-mail **integracao@mundipagg.com**.