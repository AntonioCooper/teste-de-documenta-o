---
title: "SDK C#"
excerpt: "SDK(Software Development Kit) é um conjunto de ferramentas de desenvolvimento de software capazes de facilitar a integração de sistemas em diferentes linguagens com a API da Mundipagg."
---
Adicione o pacote **MundiAPI.PCL** no seu projeto através do NuGet!
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/be11f33-Nuget-csharp.PNG",
        "Nuget-csharp.PNG",
        942,
        551,
        "#ededeb"
      ]
    }
  ]
}
[/block]
Ou faça o download do projeto em nosso [repositório do GitHub](https://github.com/mundipagg/MundiAPI-CSharp)!