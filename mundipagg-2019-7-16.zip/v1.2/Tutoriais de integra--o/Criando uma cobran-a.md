---
title: "Criando uma cobrança"
excerpt: ""
---
Nesse tutorial vamos aprender a criar uma [Cobrança](doc:cobrança) utilizando a API MundiPagg.

Com a **Charge** você pode realizar a cobrança com diversos meios de pagamento diferentes. Vamos mostrar dois exemplos de cobrança, com dois meios de pagamento, cartão de crédito e boleto.

Nesse tutorial iremos utilizar a [SDK C#](doc:sdk-c) da Mundipagg disponível no gerenciador de pacotes NuGet com o nome de MundiAPI.PCL.

#**Criando uma cobrança com cartão de crédito**

Primeiro iremos importar o pacote **MundiAPI.PC**L para a nossa aplicação de teste e logo depois iremos adicionar nossas credenciais instanciando a classe **MundiAPIClient**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Para criar uma cobrança é muito simples. Basta iniciar o objeto **CreatChargeRequest** e informar o valor da cobrança em centavos.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490\n            };   \n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Depois criamos o **Customer** utilizando o **CreateCustomerRequest**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"email@email.com\",\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Em seguida, podemos atribuir o **Customer** em nossa requisição de **CreateChargeRequest**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"email@email.com\",\n            };\n            \n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                Customer = customer,\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Caso você já possua o **Customer** cadastrado , você não precisa realizar a criação do mesmo, pode informar o **CustomerId**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\", //Exemplo de um CustomerId\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Agora podemos começar a configurar as informações de pagamento, iniciando pelo **Payment**. Essa propriedade é responsável pelas informações de processamento do pagamento. Iniciamos ela por meio do **CreatePaymentRequest** e informamos na propriedade **PaymentMethod** o valor *credit_card*.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\",\n                Payment = new CreatePaymentRequest() {\n                    PaymentMethod = \"credit_card\",\n                }\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Logo depois informamos os dados do **Card** do **Customer** utilizando a propriedade **CreditCard** de **CreatePaymentRequest** informando para ela um **CreateCreditCardPaymentRequest** com a propriedade **Card** criado a partir de um **CreateCardRequest**.

Ou informando um **CardId** previamente cadastrado junto do **CVV**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n            \n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\",\n                Payment = new CreatePaymentRequest() {\n                    PaymentMethod = \"credit_card\",\n                    CreditCard = new CreateCreditCardPaymentRequest(){\n                        Card = new CreateCardRequest {\n                            Number = \"342793631858229\",\n                            HolderName = \"Tony Stark\",\n                            ExpMonth = 1,\n                            ExpYear = 18,\n                            Cvv = \"3531\",\n                        }\n                    }\n                }\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Ou com **CardId** e **CVV**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\",\n                Payment = new CreatePaymentRequest() {\n                    PaymentMethod = \"credit_card\",\n                    CreditCard = new CreateCreditCardPaymentRequest(){\n                        CardId = \"card_qBkxRKtmEfgyv1Zd\",\n                        Card = new CreateCardRequest {\n                            Cvv = \"353\",\n                        }\n                    }\n                }\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Para finalizar, utilizamos o **CreateCharge** informando o nosso **CreateChargeRequest** 
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\",\n                Payment = new CreatePaymentRequest() {\n                    PaymentMethod = \"credit_card\",\n                    CreditCard = new CreateCreditCardPaymentRequest(){\n                        CardId = \"card_qBkxRKtmEfgyv1Zd\",\n                        Card = new CreateCardRequest {\n                            Cvv = \"353\",\n                        }\n                    }\n                }\n            };\n\n            var response = client.Charges.CreateCharge(request);\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]


#**Criando uma cobrança com boleto**

Para criação da cobrança com meio de pagamento *boleto* informamos no **PaymentMethod** o valor *boleto*. Além disso, é preciso passar a propriedade Boleto com um **CreateBoletoPaymentRequest** informando o **Bank** com o código do banco desejado e o **DueAt**, a data de vencimento do boleto em **DateTime**. Para finalizar chamar o método **CreateCharge** para realizar a requisição.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            \n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\",\n                Payment = new CreatePaymentRequest() {\n                    PaymentMethod = \"boleto\",\n                    Boleto = new CreateBoletoPaymentRequest() {\n                        Bank = \"033\",\n                        DueAt = DateTime.Now.AddDays(3)  \n                    }\n \n                }\n            };\n\n            var response = client.Charges.CreateCharge(request);\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Para mais informações acesse a nossa [API Reference](https://docs.mundipagg.com/v1/reference#cobran%C3%A7as).