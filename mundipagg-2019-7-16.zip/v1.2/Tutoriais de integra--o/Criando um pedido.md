---
title: "Criando um pedido"
excerpt: ""
---
Utilizando a funcionalidade **Pedido** (**Order**), é possível gerar pagamentos de maneira muito mais completa. Desta forma, você consegue explorar diversos recursos exclusivos da nossa API.

É possível criar **Pedidos** informando os seguintes dados:

- [Item](ref:item-do-pedido)*** (Itens do carrinho de compras);
- [Customer](doc:carteira-de-clientes)*** (Dados do comprador);
- BillingAddress (Endereço de cobrança);
- Shipping (Dados para entrega);
- [Payments](ref:meios-de-pagamento-1)*** (Meios de pagamento);
- Code (Referência do pedido: Identificador do pedido no sistema da loja).
[block:callout]
{
  "type": "warning",
  "body": "*Campo obrigatórios"
}
[/block]

---



Iremos criar um [Pedido](https://docs.mundipagg.com/v1/reference#pedidos)  com os dois meios de pagamento mais utilizados:

* [Cartão de crédito](https://docs.mundipagg.com/v1/reference#meio-de-pagamento-cart%C3%A3o-de-cr%C3%A9dito)
* [Boleto](https://docs.mundipagg.com/v1/reference#meio-de-pagamento-boleto)

Nesse tutorial iremos utilizar a [SDK C#](doc:sdk-c) da Mundipagg disponível no gerenciador de pacotes NuGet com o nome de MundiAPI.PCL.

Primeiro iremos importar o pacote **MundiAPI.PCL** para a nossa aplicação de teste e logo depois iremos adicionar nossas credenciais instanciando a classe **MundiAPIClient**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            \n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Logo depois iremos criar o objeto **[Customer](https://docs.mundipagg.com/v1/reference#clientes)** que irá representar o usuário que está realizando a compra. Apenas o campo **Name** é obrigatório. Recomendamos que envie também o campo **Email**. Enviando esse campo, conseguiremos identificar se o cliente já esta na sua carteira de cliente, evitando assim qualquer duplicidade.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n            \n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Caso já possua o [Customer](https://docs.mundipagg.com/v1/reference#clientes) criado anteriormente você pode utilizar o **CustomerId** durante a requisição de criação da **Order**.

Agora podemos começar a informar os [Items](https://docs.mundipagg.com/v1/reference#item-do-pedido) que irão compor a nossa Order.

Iremos criar um item com as informações básicas:

- **Amount** : Valor em centavos do item
- **Description** : Descrição ou nome do item
- **Quantity** : Quantidade de itens que esta sendo comprada.

Para isso iremos criar uma lista de **CreateOrderItemRequest** , e iremos adicionar dois items do tipo **CreateOrderItemRequest**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Vamos iniciar a requisição de criação da **Order** pelo **CreateOrderRequest** e adicionando os **Itens** que criamos.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n\n            };\n\n            var order = new CreateOrderRequest() {\n                Items = items,\n            }; \n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Adicionamos o **Customer** logo depois.
[block:code]
{
  "codes": [
    {
      "code": "using System;\nusing MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n            };\n\n            var order = new CreateOrderRequest() {\n                Items = items,\n                Customer = customer\n            };\n             \n            var request = client.Orders.CreateOrder(order);\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Agora vamos informar qual meio de pagamento que ira compor essa **Order**.

Iremos dividir essa parte em duas de acordo com os dois meios de pagamento comentados no inicio do tutorial.

#Criando uma Order com meio de pagamento cartão de crédito

Agora podemos começar a configurar as informações de pagamento iniciando pelo **Payments** , propriedade responsável pelas informações de processamento do pagamento. Iniciamos com uma lista de **CreatePaymentRequest** e criamos um **CreatePaymentRequest** informando na propriedade **PaymentMethod** o valor *credit_card*.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n\n            };\n\n            var order = new CreateOrderRequest() {\n                Items = items,\n                Customer = customer,\n                Payments = new List<CreatePaymentRequest> {\n                    new CreatePaymentRequest{\n                        PaymentMethod = \"credit_card\"\n                    }\n                }\n            }; \n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Em seguida informamos os dados do cartão do cliente utilizando a propriedade **CreditCard** de **CreatePaymentRequest**. Para isso, é preciso informar o **CreateCreditCardPaymentRequest** com a propriedade **Card** criado a partir de um **CreateCardRequest**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n            };\n\n            var order = new CreateOrderRequest() {\n                Items = items,\n                Customer = customer,\n                Payments = new List<CreatePaymentRequest> {\n                    new CreatePaymentRequest{\n                        PaymentMethod = \"credit_card\",\n                        CreditCard = new CreateCreditCardPaymentRequest(){\n                        Card = new CreateCardRequest {\n                            Number = \"342793631858229\",\n                            HolderName = \"Tony Stark\",\n                            ExpMonth = 1,\n                            ExpYear = 18,\n                            Cvv = \"3531\",\n                        }\n                    }\n                  }\n              }\n           };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Isso pode ser feito também informando um **CardId** previamente cadastrado junto do **CVV**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\n\nnamespace TutorialCobranca {\n    class Program {\n        static void Main(string[] args) {\n\n            // Neste exemplo estamos utilizando A sdk C# MundiAPI.PCL\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            string basicAuthPassword = \"\";\n\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var request = new CreateChargeRequest() {\n                Amount = 1490,\n                CustomerId = \"cus_aGvrM1lCvxUKW9N7\",\n                Payment = new CreatePaymentRequest() {\n                    PaymentMethod = \"credit_card\",\n                    CreditCard = new CreateCreditCardPaymentRequest(){\n                        CardId = \"card_qBkxRKtmEfgyv1Zd\",\n                        Card = new CreateCardRequest {\n                            Cvv = \"353\",\n                        }\n                    }\n                }\n            };\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Por fim podemos realizar a requisição da **Order** utilizando a classe **Client**.
[block:code]
{
  "codes": [
    {
      "code": "using MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n            };\n\n            var order = new CreateOrderRequest() {\n                Items = items,\n                Customer = customer,\n                Payments = new List<CreatePaymentRequest> {\n                    new CreatePaymentRequest{\n                        PaymentMethod = \"credit_card\",\n                        CreditCard = new CreateCreditCardPaymentRequest(){\n                            CardId = \"card_qBkxRKtmEfgyv1Zd\",\n                            Card = new CreateCardRequest {\n                            Cvv = \"3531\",\n                        }\n                    }\n                  }\n              }\n           };\n\n            var request = client.Orders.CreateOrder(order);\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]
#**Criando uma Order com meio de pagamento boleto**

Para criação da cobrança com meio de pagamento boleto informamos no **PaymentMethod** o valor *boleto* e a propriedade Boleto com um **CreateBoletoPaymentRequest** informando o **Bank**, código do banco desejado, e o **DueAt**, a data de vencimento do boleto em **DateTime**. Finalizamos realizando o **CreateOrder**.
[block:code]
{
  "codes": [
    {
      "code": "using System;\nusing MundiAPI.PCL;\nusing MundiAPI.PCL.Models;\nusing System.Collections.Generic;\n\nnamespace TutorialPedido {\n    class Program {\n        static void Main(string[] args) {\n\n            // Secret key fornecida pela MundiPagg\n            string basicAuthUserName = \"sk_test_4AdjlqpseatnmgbW\";\n            // Senha em branco. Passando apenas a secret key\n            string basicAuthPassword = \"\";\n            var client = new MundiAPIClient(basicAuthUserName, basicAuthPassword);\n\n            var customer = new CreateCustomerRequest {\n                Name = \"Tony Stark\",\n                Email = \"tonystark@avengers.com\",\n            };\n\n            var items = new List<CreateOrderItemRequest> {\n                new CreateOrderItemRequest{\n                    Amount = 2990,\n                    Description = \"Chaveiro do Tesseract\",\n                    Quantity =1,\n                },\n                new CreateOrderItemRequest{\n                    Amount = 5990,\n                    Description = \"Manopla do Infinito\",\n                    Quantity =1\n                },\n            };\n\n            var order = new CreateOrderRequest() {\n                Items = items,\n                Customer = customer,\n                Payments = new List<CreatePaymentRequest> {\n                    new CreatePaymentRequest{\n                        PaymentMethod = \"boleto\",\n                        Boleto = new CreateBoletoPaymentRequest(){\n                             Bank = \"033\",\n                             DueAt = DateTime.Now.AddDays(3)\n\n                        }\n                    }\n                  }\n            };\n\n            var request = client.Orders.CreateOrder(order);\n        }\n    }\n}",
      "language": "csharp"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "O PDF para enviar para o cliente se encontra dentro do objeto **LastTransaction** que se encontra no [response](https://docs.mundipagg.com/v1/reference#meio-de-pagamento-boleto)."
}
[/block]
Para mais informações acesse a nossa [API Reference](https://docs.mundipagg.com/v1/reference#cobran%C3%A7as).