---
title: "Item do pedido"
excerpt: ""
---
Com a criação de um pedido **aberto**, é possível que itens sejam gerenciados.