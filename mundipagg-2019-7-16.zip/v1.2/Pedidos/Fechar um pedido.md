---
title: "Fechar um pedido"
excerpt: "Utilizado para fechar um pedido para que não seja mais possível adicionar cobranças."
---
