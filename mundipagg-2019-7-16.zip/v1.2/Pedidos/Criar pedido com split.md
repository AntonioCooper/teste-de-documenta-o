---
title: "Criar pedido com split"
excerpt: "Neste caso você inclui um nó `split` dento de `payment`. Dentro desse nó você pode informar quais os recebedores e quanto cada um receberá."
---
