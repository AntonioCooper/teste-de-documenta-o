---
title: "Incluir pagamento no pedido"
excerpt: "Enquanto um pedido estiver aberto , e possível adicionar novas cobranças utilizando o order_id na criação de uma cobrança."
---
