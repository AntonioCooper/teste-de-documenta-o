---
title: "Criar pedido multimeios"
excerpt: "Neste caso você inclui mais de um objeto na coleção de **payments**. Desta maneira você pode realizar pedido com diversos cartões ou combinando diferentes meios de pagamento."
---
[block:callout]
{
  "type": "warning",
  "title": "Atenção!",
  "body": "Neste caso você deve informar o valor de cada `payment`.\nPara isto basta incluir a propriedade `amount` dentro de cada um."
}
[/block]