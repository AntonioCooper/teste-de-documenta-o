---
title: "Objeto pedido"
excerpt: ""
---
Para realizar pedidos de cartão de crédito ou boleto, você deve criar um objeto `order`.
Os pedidos são identificados por uma chave aleatória. Ex: `or_x50ZBkRQhzhxXzpj`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "1-0": "`currency`",
    "2-0": "`status`",
    "3-0": "`code`",
    "4-0": "`customer`",
    "5-0": "`shipping`",
    "6-0": "`charges`",
    "7-0": "`items`",
    "8-0": "`metadata`",
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**string**",
    "4-1": "**object**",
    "5-1": "**object**",
    "6-1": "**array of object**",
    "7-1": "**object**",
    "8-1": "**object**",
    "0-2": "Código do pedido.",
    "1-2": "Moeda. Valor possível: **BRL**.",
    "2-2": "Status do pedido. Possíveis valores: **Pending**, **Paid**, **Canceled**, **Failed**",
    "3-2": "Código identificador do pedido no sistema da loja.",
    "4-2": "Dados do cliente. [Saiba mais sobre clientes](ref:objeto-cliente)",
    "5-2": "Dados para entrega. [Saiba mais sobre entregas](ref:entregas)",
    "6-2": "Lista de dados de cobrança. [Saiba mais sobre cobranças](ref:objeto-cobrança)",
    "7-2": "Itens do pedido. [Saiba mais sobre itens do pedido](ref:item-do-pedido)",
    "8-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pedido.  [Saiba mais sobre metadata](ref:metadata)",
    "9-0": "`closed`",
    "9-1": "**boolean**",
    "9-2": "Indica se o pedido está aberto ou não.",
    "10-0": "`created_at`",
    "10-1": "**datetime**",
    "10-2": "Data de criação do pedido."
  },
  "cols": 3,
  "rows": 11
}
[/block]