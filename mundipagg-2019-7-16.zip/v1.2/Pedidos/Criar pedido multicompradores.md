---
title: "Criar pedido multicompradores"
excerpt: "Neste caso você pode incluir um cliente (`customer`) dentro do nó de pagamento (`payment`).\nCaso um nó `payment` não possua um nó `customer` dentro, assumiremos que o pagador dele é o mesmo `customer` do pedido."
---
[block:callout]
{
  "type": "warning",
  "body": "Neste caso você deve informar o valor de cada `payment`.\nPara isto basta incluir a propriedade `amount` dentro de cada um.",
  "title": "Atenção!"
}
[/block]