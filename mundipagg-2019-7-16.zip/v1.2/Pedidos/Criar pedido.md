---
title: "Criar pedido"
excerpt: ""
---
[block:callout]
{
  "type": "danger",
  "title": "Atenção!",
  "body": "Para poder trafegar dados de cartão abertos em seu servidor, você deve ser [PCI Compliance](https://www.mundipagg.com/o-que-e-pci/). Por isso, recomendamos fortemente que as requisições sejam enviadas sempre usando o card_id ou card_token, de forma que você não precise trafegar os dados de cartão no seu servidor."
}
[/block]

[block:callout]
{
  "type": "danger",
  "title": "",
  "body": "Caso seja informado o `customer_id`, não é necessário incluir o objeto `customer`. Entretanto, é **obrigatório** que um desses parâmetros seja informado."
}
[/block]