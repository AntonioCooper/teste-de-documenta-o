---
title: "Obter item do pedido"
excerpt: "Obter um item especifico dentro de um pedido especifico."
---
