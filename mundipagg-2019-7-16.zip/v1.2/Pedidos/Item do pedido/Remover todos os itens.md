---
title: "Remover todos os itens"
excerpt: "Quando um pedido está **aberto**, você pode remover todos os itens dele."
---
