---
title: "Deletar item"
excerpt: "Quando um pedido está **aberto**, você pode excluir itens dele."
---
