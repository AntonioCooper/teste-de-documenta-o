---
title: "Editar item do pedido"
excerpt: "Quando um pedido está **aberto**, você pode editar os itens dele."
---
