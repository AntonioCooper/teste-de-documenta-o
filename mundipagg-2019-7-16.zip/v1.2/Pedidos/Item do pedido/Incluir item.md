---
title: "Incluir item"
excerpt: "Quando um pedido está **aberto**, você pode incluir itens nele."
---
