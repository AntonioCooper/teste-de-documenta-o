---
title: "Objeto item do pedido"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "1-0": "`amount`",
    "1-1": "**integer**",
    "1-2": "Valor unitário.",
    "2-0": "`description`",
    "2-1": "**string**",
    "2-2": "Descrição do item.",
    "3-0": "`quantity`",
    "3-1": "**short**",
    "3-2": "Quantidade de itens.",
    "4-0": "`code`",
    "4-1": "**string**",
    "4-2": "Código do item no sistema da loja.",
    "5-0": "`category`",
    "5-1": "**string**",
    "5-2": "Categoria do item.",
    "6-0": "`seller`",
    "6-1": "**object**",
    "6-2": "Dados do vendedor do item.",
    "7-0": "`seller_id`",
    "7-1": "**string**",
    "7-2": "Código do vendedor.",
    "0-0": "`id`",
    "0-1": "**string**",
    "0-2": "Código do item do pedido",
    "8-0": "`status`",
    "8-1": "**string**",
    "8-2": "Status do item do pedido. Valores possíveis: **active** ou **deleted**.",
    "9-0": "`created_at`",
    "9-1": "**datetime**",
    "9-2": "Data de criação do item do pedido.",
    "10-0": "`updated_at`",
    "10-1": "**datetime**",
    "10-2": "Data de última atualização do item do pedido.",
    "11-0": "`deleted_at`",
    "11-1": "**datetime**",
    "11-2": "Data de exclusão do item do pedido.",
    "12-0": "`order`",
    "12-1": "**object**",
    "12-2": "Dados do pedido."
  },
  "cols": 3,
  "rows": 13
}
[/block]