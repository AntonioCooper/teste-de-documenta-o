---
title: "Objeto saldo"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`currency`",
    "0-1": "**string**",
    "0-2": "Moeda",
    "1-0": "`available_amount`",
    "1-1": "**integer**",
    "1-2": "Valor disponível para transferência",
    "2-0": "`recipient`",
    "2-1": "**object**",
    "2-2": "Dados do recebedor"
  },
  "cols": 3,
  "rows": 3
}
[/block]