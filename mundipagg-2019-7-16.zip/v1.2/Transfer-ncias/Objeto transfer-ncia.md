---
title: "Objeto transferência"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "0-1": "**string**",
    "0-2": "Código da transferência",
    "1-0": "`amount`",
    "1-1": "**integer**",
    "1-2": "Valor da transferência",
    "2-0": "`status`",
    "2-1": "**string**",
    "2-2": "Status da transferência. Os valores possíveis são **created**, **pending**, **processing**, **transferred**, **failed** ou **canceled**.",
    "3-0": "`created_at`",
    "3-1": "**datetime**",
    "3-2": "Data de criação",
    "4-0": "`updated_at`",
    "4-1": "**datetime**",
    "4-2": "Data de atualização",
    "5-0": "`bank_account`",
    "5-1": "**object**",
    "5-2": "Conta bancária para onde foi feita a transferência",
    "6-0": "`metadata`",
    "6-1": "**object**",
    "6-2": "Informações adicionais sobre a transferência. [Saiba mais sobre metadata](ref:metadata)"
  },
  "cols": 3,
  "rows": 7
}
[/block]