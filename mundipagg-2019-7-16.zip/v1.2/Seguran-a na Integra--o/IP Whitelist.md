---
title: "IP Whitelist"
excerpt: ""
---
**IP Whitelist** é uma lista de endereços (IPs) capazes de criar requisições para uma determinada loja. Você pode selecioná-los de acordo com suas preferências. Assim, será possível ter maior segurança em sua integração, via API MundiPagg. É preciso apenas que os seguintes requisitos sejam respeitados: 

* Máximo de 20 IPs;
* IPs seguindo o formato:  xxx.xxx.xxx.xxx .



Para habilitar a funcionalidade, basta entrar em contato conosco através de **suporte@mundipagg.com** !