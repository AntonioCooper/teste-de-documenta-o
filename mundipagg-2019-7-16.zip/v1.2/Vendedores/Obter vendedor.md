---
title: "Obter vendedor"
excerpt: ""
---
