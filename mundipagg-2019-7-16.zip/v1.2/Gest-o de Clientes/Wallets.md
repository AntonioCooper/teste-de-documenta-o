---
title: "Wallets"
excerpt: ""
---
[block:api-header]
{
  "title": "Wallets x Carteira de Clientes"
}
[/block]
As **Wallets** trabalham junto com a **Carteira de Clientes**. Apesar do nomes "Carteira " e "Wallet" causarem uma certa confusão, são serviços completamente diferentes.

Enquanto a Carteira de Clientes é o conjunto de clientes que transacionam ou transacionaram na loja, as Wallets são o conjunto de cartões de cada `Customer`.

Na imagem abaixo, fica clara a relação entre Loja, Customer (Carteira de Clientes) e Wallet.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/17526cb-fluxo-carteira_clientes-wallet.png",
        "fluxo-carteira_clientes-wallet.png",
        1232,
        1094,
        "#3aa3c2"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "São armazenados na wallet todos os cartões utilizados por um mesmo cliente em uma mesma loja.",
  "title": "Inclusão de cartões"
}
[/block]
## [**Funcionalidades relacionadas a uma wallet de um cliente**]()
[block:parameters]
{
  "data": {
    "0-0": "**1)** [Incluir](https://docs.mundipagg.com/v1/reference#criar-cartao)",
    "1-0": "**2)** [Obter](https://docs.mundipagg.com/v1/reference#obter-um-cartao)",
    "2-0": "**3)** [Editar](https://docs.mundipagg.com/v1/reference#editar-cartao)",
    "3-0": "**4)** [Listar](https://docs.mundipagg.com/v1/reference#listar-cartoes)",
    "4-0": "**5)** [Excluir](https://docs.mundipagg.com/v1/reference#excluir-cartao)"
  },
  "cols": 1,
  "rows": 5
}
[/block]
## [Compra com um clique]()

A wallet possibilita a utilização do serviço de "Compra com um clique". 

Sua carteira de clientes será alimentada automaticamente sempre que uma nova cobrança for gerada, seja de forma avulsa, através de pedidos ou assinaturas. Possibilitando assim, que em transações futuras você disponibilize ao seu cliente a compra com apenas um clique. 

Tal funcionalidade aumenta o número de compras por impulso já que o cliente (`customer`) não precisa digitar novamente todos os dados do cartão.
[block:callout]
{
  "type": "warning",
  "body": "Cada carteira é exclusiva de um lojista (Account). Desta forma, um lojista não tem acesso à carteira de outro mesmo que estejam dentro de um mesmo cliente (Merchant) na Mundi.",
  "title": "Atenção!"
}
[/block]
Saiba mais sobre cartões através de nossa [API Reference](https://docs.mundipagg.com/reference#objeto-cartao)!