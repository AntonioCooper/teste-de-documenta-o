---
title: "Access Token"
excerpt: ""
---
Para que você não transacione dados de cartão, criamos o **Access Token**. Com ele, os dados sensíveis do cartão são enviados direto para a Mundipagg e não passam pelo seu servidor. 

Cada cliente (`customer`) terá uma coleção de Access Token. Esse token é usado como autenticação para que o seu aplicativo ou WebSite envie requisições diretamente para Mundipagg. Com ele você consegue gerenciar a wallet deste customer (tanto os cartões quanto os endereços).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7cbff6f-fluxo-access-token.png",
        "fluxo-access-token.png",
        1094,
        866,
        "#298fb8"
      ],
      "sizing": "80"
    }
  ]
}
[/block]
## [**Funcionalidades relacionadas ao AccessToken**]()

[block:parameters]
{
  "data": {
    "0-0": "**1)** [Criar Access Token](https://docs.mundipagg.com/v1/reference#criar-access-token)",
    "1-0": "**2)** [Obter Access Token](https://docs.mundipagg.com/v1/reference#obter-accesstoken)",
    "2-0": "**3)** [Listar Access Tokens](https://docs.mundipagg.com/v1/reference#listar-access-tokens)",
    "3-0": "**4)** [Excluir Access Token](https://docs.mundipagg.com/v1/reference#testinput)"
  },
  "cols": 1,
  "rows": 4
}
[/block]
Saiba mais sobre Access Token através de nossa [API Reference](https://docs.mundipagg.com/reference#access-token)!