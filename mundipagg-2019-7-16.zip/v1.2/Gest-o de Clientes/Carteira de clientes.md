---
title: "Carteira de clientes"
excerpt: ""
---
A nova API possibilita a construção e o gerenciamento de uma Carteira de Clientes, completamente customizável. 

É possível criar um cliente (`customer`) informando os seguintes dados:

`Name` (Nome do cliente);
`Email` (Email do cliente);
`Document` (Documento);
`Type` (Pessoa física ou jurídica);
`Phones` (Telefones do cliente);
`Birthdate` (Data de nascimento);
`Address` (Endereço do cliente).

Sempre que um novo cliente (`customer`) é criado, o mesmo vai diretamente para a sua carteira. Sua coleção será alimentada automaticamente sempre que uma cobrança for gerada, seja de forma avulsa, através de pedidos ou assinaturas.
[block:callout]
{
  "type": "info",
  "title": "Dados obrigatórios",
  "body": "Apenas o nome (`name`) é obrigatório na criação de um cliente, porém ele não é único."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Atenção",
  "body": "A propriedade `email` não é obrigatória, porém é única e é uma chave forte! Ou seja, caso você envie o e-mail no objeto `customer`, o nosso sistema irá vincular as informações de cartão ao comprador já existente."
}
[/block]
##[**Funcionalidades relacionadas à carteira de clientes:**]()
[block:parameters]
{
  "data": {
    "0-0": "**1)** [Incluir](https://docs.mundipagg.com/v1/reference#criar-cliente)",
    "1-0": "**2)** [Obter](https://docs.mundipagg.com/v1/reference#obter-cliente)",
    "3-0": "**4)** [Listar](https://docs.mundipagg.com/v1/reference#listar-clientes)",
    "2-0": "**3)** [Atualizar](https://docs.mundipagg.com/v1/reference#editar-cliente)"
  },
  "cols": 1,
  "rows": 4
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "Todo cliente (`customer`) possui um código como este: `cus_dbaKMJJiPtDmMlrp` \nEste `customer_Id` será sua chave de identificação na carteira. \nDessa forma, você consegue armazenar os dados pessoais e dos cartões do cliente no ambiente PCI Compliance da MundiPagg, garantindo o tráfego de informações sem se preocupar com vulnerabilidades e falhas de segurança.",
  "title": "Código identificador do seu cliente"
}
[/block]
Saiba mais sobre clientes através de nossa [API Reference](https://docs.mundipagg.com/reference#objeto-cliente)!