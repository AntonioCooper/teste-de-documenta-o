---
title: "Captura e Cancelamento em lote"
excerpt: "Fluxo para a utilização da ferramenta de captura e cancelamento em lote"
---
**1.** Gere um arquivo txt com as cobranças que serão capturadas e/ou canceladas. Cada linha deve ter o seguinte formato: 

**can,charge_id,valor da cobrança 
cap,charge_id,valor da cobrança**

Sendo: 
can:  Para que seja efetuado o cancelamento 
cap: Para que seja efetuada a captura 
charge_id: Código da cobrança 

Além disso, o valor da cobrança deve ser enviado em centavos e devem ser utilizados zeros na frente dele até que sejam completados 10 dígitos, do seguinte modo: 

**can,charge_id,0000001234 
cap,charge_id,0000001234**

** 2. **Publique esse arquivo no FTP (File Transfer Protocol) da MundiPagg dentro da pasta 'in'. A URL utilizada é **ftp://sftp.mundipagg.com:2100** com os seus dados de login. 
 
**3.** Identificaremos todas as transações e as enviaremos para captura/cancelamento na API. 
 
**4. **No final do processamento, geraremos um arquivo de resultado, muito parecido com o de origem, adicionando apenas o resultado de cada operação ao final de cada linha (S = Success / F = Failed), separado por vírgula. Exemplos podem ser vistos abaixo: 

 **cap,charge_id,0000001234,S 
 cap,charge_id,0000001234,F** 

**5.** O arquivo resultante será publicado na pasta 'processed' do FTP. 

**6.** Você poderá baixar o arquivo da pasta 'processed' do FTP e interpretar o resultado das operações. 
[block:callout]
{
  "type": "danger",
  "body": "É importante destacar que os nomes dos arquivos não devem se repetir."
}
[/block]