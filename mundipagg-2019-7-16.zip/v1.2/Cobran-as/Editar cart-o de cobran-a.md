---
title: "Editar cartão de cobrança"
excerpt: "Esse recurso só pode ser chamado quando o cartão a ser editado teve a transação não autorizada."
---
