---
title: "Retentar uma cobrança *"
excerpt: ""
---
[block:api-header]
{
  "title": "Retentativas Automáticas"
}
[/block]
* **Retentativa Automática**
A retentativa automática é uma tecnologia que reprocessa automaticamente na mesma ou em outra adquirente, as transações não autorizadas. É possível programar o número de retentativas por adquirente e em quantas adquirentes iremos tentar reprocessar as transações.

* **Retentativa Offline**
As retentativas offline tem como objetivo recuperar cobranças que não foram autorizadas. Elas podem ser estabelecidas através de uma cobrança avulsa (charge) ou de uma assinatura (subscription) e devem ser configuradas através da unidade de medida “hora”, tendo como base a última tentativa.

Saiba mais sobre os retentativas através de nossa [documentação de negócios](https://docs.mundipagg.com/v1/docs/retentativa-autom%C3%A1tica)!

Para habilitar as funcionalidades, basta entrar em contato conosco através de **suporte@mundipagg.com** !