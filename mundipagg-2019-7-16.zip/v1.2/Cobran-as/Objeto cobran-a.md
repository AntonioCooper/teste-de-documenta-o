---
title: "Objeto cobrança"
excerpt: ""
---
Para realizar cobranças de cartão de crédito ou boleto, você deve criar um objeto `charge`.
As cobranças são identificados por uma chave aleatória. Ex: `ch_x50ZBkRQhzhxXzpj`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "2-0": "`gateway_id`",
    "3-0": "`amount`",
    "4-0": "`payment_method`",
    "5-0": "`status`",
    "6-0": "`due_at`",
    "7-0": "`created_at`",
    "8-0": "`updated_at`",
    "9-0": "`customer`",
    "10-0": "`invoice`",
    "11-0": "`last_transaction`",
    "12-0": "`metadata`",
    "0-1": "**string**",
    "2-1": "**string**",
    "3-1": "**integer**",
    "4-1": "**integer**",
    "5-1": "**string**",
    "6-1": "**datetime**",
    "7-1": "**datetime**",
    "8-1": "**datetime**",
    "9-1": "**object**",
    "10-1": "**object**",
    "11-1": "**object**",
    "12-1": "**object**",
    "0-2": "Código da cobrança.",
    "2-2": "Código da cobrança no gateway de pagamento",
    "3-2": "Valor da cobrança.",
    "4-2": "Meio de pagamento.",
    "5-2": "Status da cobrança. Valores possíveis:  **pending**, **paid**, **canceled**, **processing**, **failed**, **overpaid** ou **underpaid**",
    "6-2": "Data de vencimento da cobrança.",
    "7-2": "Data de criação da cobrança.",
    "8-2": "Data de atualização da cobrança.",
    "9-2": "Dados do cliente. [Saiba mais sobre clientes](ref:objeto-cliente)",
    "10-2": "Dados da fatura. [Saiba mais sobre faturas](ref:objeto-fatura).",
    "11-2": "Informações sobre a última transação da cobrança.",
    "12-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre a cobrança. [Saiba mais sobre metadata](ref:metadata)",
    "1-0": "`code`",
    "1-1": "**string**",
    "1-2": "Código identificador da cobrança no sistema da loja."
  },
  "cols": 3,
  "rows": 13
}
[/block]