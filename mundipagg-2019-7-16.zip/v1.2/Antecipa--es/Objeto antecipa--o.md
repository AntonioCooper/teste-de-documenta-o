---
title: "Objeto antecipação"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "0-1": "**string**",
    "0-2": "Código da antecipação",
    "1-0": "`requested_amount`",
    "1-1": "**integer**",
    "1-2": "Valor solicitado para antecipação",
    "2-0": "`approved_amount`",
    "2-1": "**integer**",
    "2-2": "Valor aprovado para antecipação",
    "3-0": "`recipient`",
    "3-1": "**object**",
    "3-2": "Dados do recebedor. Saiba mais sobre o recebedor",
    "4-0": "`pgid`",
    "4-1": "**string**",
    "4-2": "Código da antecipação no gateway",
    "5-0": "`created_at`",
    "5-1": "**datetime**",
    "5-2": "Data de criação da antecipação",
    "6-0": "`updated_at`",
    "6-1": "**datetime**",
    "6-2": "Data de atualização da antecipação",
    "7-0": "`payment_date`",
    "7-1": "**datetime**",
    "7-2": "Data de pagamento da antecipação",
    "8-0": "`status`",
    "8-1": "**string**",
    "8-2": "Status da antecipação. Os valores possíveis são **created**, **pending**, **approved**, **refused**, **canceled** ou **failed**.",
    "9-0": "`timeframe`",
    "9-1": "**string**",
    "9-2": "Intervalo a partir de onde serão feitas as antecipações. Os valores possíveis são **start** ou **end**"
  },
  "cols": 3,
  "rows": 10
}
[/block]