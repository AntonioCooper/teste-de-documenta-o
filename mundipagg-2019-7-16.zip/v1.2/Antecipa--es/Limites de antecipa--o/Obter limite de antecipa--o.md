---
title: "Obter limite de antecipação"
excerpt: ""
---
