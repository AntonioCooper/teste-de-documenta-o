---
title: "Objeto limites de antecipação"
excerpt: ""
---
[block:api-header]
{
  "title": "Objeto limites de antecipação"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`max`",
    "0-1": "**objeto**",
    "0-2": "Limite máximo de antecipação. Saiba mais sobre [Limite de antecipação]()",
    "1-0": "`min`",
    "1-1": "**objeto**",
    "1-2": "Limite mínimo de antecipação. Saiba mais sobre [Limite de antecipação]()"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:api-header]
{
  "title": "Objeto limite de antecipação"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`amount`",
    "0-1": "**integer**",
    "0-2": "Valor do limite",
    "1-0": "`anticipation_fee`",
    "1-1": "**integer**",
    "1-2": "Valor da taxa de antecipação"
  },
  "cols": 3,
  "rows": 2
}
[/block]