---
title: "Multicompradores"
excerpt: ""
---
Utilizando a funcionalidade de **multicompradores** você pode criar um pedido que será pago por vários consumidores diferentes.

Esta funcionalidade parte do mesmo princípio de funcionamento de Multimeios de pagamento. A diferença é que com a função de multicompradores, além de mais de um meio de pagamento, também é possível dividir o pagamento por mais de uma pessoa.
[block:callout]
{
  "type": "warning",
  "body": "Para criar pedidos com multicompradores você deve enviar os dados do cliente (`customer`) dentro de pelo menos um `payment` presente na lista de pagamentos do pedido.",
  "title": "Atenção"
}
[/block]
Esse recurso pode ser utilizado para diversos modelos de negócio onde compradores diferentes queiram dividir uma compra. Outros exemplos seriam:

* Compartilhar uma viagem com alguém;
* Dividir um presente de aniversário com alguém.

**Exemplo:** 
Antonio e Carlos são dois amigos que resolvem assistir um pay-per-view na casa de Antonio.
Ao fazer a compra do evento pelo operadora de TV a cabo ele seleciona que quer dividir a cobrança por dois. O evento que custa R$200, aparecerá divido em dois meios de pagamento, cada um de R$100.

Assim, Antonio coloca seu cartão de crédito para pagar metade e coloca Carlos como o segundo pagador para a outra metade. São criadas duas cobranças vinculadas que, quando capturadas, liberarão o acesso ao programa na TV a cabo.


Saiba mais sobre pedidos com multicompradores através de nossa [API Reference](https://docs.mundipagg.com/reference#criar-pedido-multicompradores)!