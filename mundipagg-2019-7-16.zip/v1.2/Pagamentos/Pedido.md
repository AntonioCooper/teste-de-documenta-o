---
title: "Pedido"
excerpt: ""
---
Através de um **pedido** é possível gerar pagamentos de maneira muito mais completa. Desta forma, você consegue explorar diversos recursos exclusivos da nossa API.

É possível criar pedidos (`order`) informando os seguintes dados:

`Itens` (Itens do carrinho de compras);
`Customer` (Dados do comprador);
`BillingAddress` (Endereço de cobrança);
`Shipping` (Dados para entrega);
`Payments` (Meios de pagamento);
`Code` (Referência do pedido: Identificador do pedido no sistema da loja).
`SessionId`(Dados da sessão para integração com Antifraude)
`Ip` (Dados do endereço de IP para integração com Antifraude)
`Location` (Dados de localização para integração com Antifraude)
`Device` (Dados do dispositivo para integração com Antifraude)


##[**Funcionalidades relacionadas ao pedido**]()
[block:parameters]
{
  "data": {
    "0-0": "**1)** Antifraude",
    "1-0": "**2)** [Multimeios](https://docs.mundipagg.com/docs/multimeios)",
    "2-0": "**3)** [Multicompradores](https://docs.mundipagg.com/docs/multicompradores)",
    "4-0": "**5)** [Criação de pedidos abertos](https://docs.mundipagg.com/docs/pedidos-abertos)",
    "3-0": "**4)** [Split](https://docs.mundipagg.com/docs/pedidos-com-split)"
  },
  "cols": 1,
  "rows": 5
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "Lembrando que um pedido SEMPRE gera uma ou mais cobranças.",
  "title": "Atenção!"
}
[/block]
Saiba mais sobre pedidos através de nossa [API Reference](https://docs.mundipagg.com/reference#objeto-pedido)!