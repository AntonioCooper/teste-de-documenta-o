---
title: "Boleto"
excerpt: ""
---
Uma compra com boleto registrado segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/24feda3-fluxo-boleto2.png",
        "fluxo-boleto2.png",
        1500,
        1500,
        "#2687b5"
      ]
    }
  ]
}
[/block]
A partir de dezembro de 2017, os boletos serão emitidos apenas com registro. 

Para gerá-lo, são obrigatórios os dados abaixo:

`Customer.name` (Nome do comprador);
`Custome.document` (Documento do comprador);
`Customer.type` (Pessoa física ou jurídica);
`Customer.Address` (Endereço do comprador).
[block:callout]
{
  "type": "info",
  "body": "O pagamento por boleto pode ser feito através de uma transferência entre contas ou um depósito no caixa bancário e, por isso, não há possibilidade de chargebacks ou estornos automáticos. Caso você deseje estornar essa transação, é necessário realizar uma transferência direto no banco para a conta do consumidor.",
  "title": "Desfazimento transacional"
}
[/block]
## [**Bancos**]()

A Mundipagg está integrada com os principais bancos do mercado, são eles:

  * Itaú
  * Santander
  * Banco do Brasil
  * Bradesco
  * Citibank
 
[block:callout]
{
  "type": "info",
  "body": "Atualmente oferecemos a integração com o Boleto Stone, um produto que tem como principal função facilitar a vida do lojista minimizando ao máximo a burocracia para liberação, integração e geração de boletos.",
  "title": "Boleto Stone"
}
[/block]
Saiba mais sobre pagamentos com boleto através de nossa [API Reference](https://docs.mundipagg.com/reference#meio-de-pagamento-boleto)!