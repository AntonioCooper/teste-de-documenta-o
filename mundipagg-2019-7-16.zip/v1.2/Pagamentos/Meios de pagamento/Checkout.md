---
title: "Checkout"
excerpt: ""
---
Para pedidos, é possível utilizar o checkout como meio de pagamento. Para isso, basta que seja criado um pedido que indique o checkout como meio de pagamento e a MundiPagg retornará a você uma URL para que o pagamento seja realizado.

[block:callout]
{
  "type": "warning",
  "title": "Atenção!",
  "body": "É importante destacar que a URL redirecionará o seu cliente para uma página de checkout da MundiPagg e caberá a você a criação de uma URL de sucesso para que ele seja redirecionado após o pagamento."
}
[/block]
Saiba mais sobre pagamentos com meio de pagamento checkout através de nossa [API Reference](https://docs.mundipagg.com/reference#meio-de-pagamento-checkout)!