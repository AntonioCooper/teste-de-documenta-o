---
title: "Voucher"
excerpt: ""
---
Uma compra com voucher segue o seguinte fluxo: 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/022ea88-fluxo-voucher1.png",
        "fluxo-voucher(1).png",
        786,
        1085,
        "#3198bd"
      ]
    }
  ]
}
[/block]
A MundiPagg recebe os dados enviados pela loja e faz a comunicação com a bandeira do cartão utilizado.  A resposta recebida pela Mundipagg é repassada ao lojista. 

Possibilitamos a sua integração com as duas das principais bandeiras do mercado: VR benefícios e Sodexo.

Atualmente, em uma transação com voucher, via API MundiPagg, é possível realizar as seguintes ações: 

**Pré-autorizar:** Com a pré-autorização, o limite do cliente é reservado e a transação pode ser capturada em um momento posterior. 
**Capturar: ** É a captura efetiva do valor da cobrança no cartão do cliente.  
**Cancelar:** Ocorre quando uma transação é desfeita. Só pode ser realizada no mesmo dia da transação. 
[block:callout]
{
  "type": "danger",
  "body": "Caso o cancelamento precise ser realizado 24 horas após a transação, será necessário que o lojista entre em contato com a bandeira diretamente.",
  "title": "Estorno"
}
[/block]
Cada bandeira possui habilitação em determinadas ações expressas a seguir:
[block:parameters]
{
  "data": {
    "h-0": "Ação",
    "h-1": "VR",
    "0-1": "-",
    "0-0": "Pré-autorização",
    "4-0": "Cancelamento Parcial",
    "h-2": "Sodexo",
    "4-1": "-",
    "4-2": "-",
    "0-2": "x",
    "5-0": "Retentativa",
    "5-1": "-",
    "5-2": "-",
    "2-0": "Captura Parcial",
    "2-1": "-",
    "2-2": "-",
    "3-0": "Cancelamento",
    "3-1": "x",
    "3-2": "x",
    "1-0": "Captura",
    "1-1": "x",
    "1-2": "x"
  },
  "cols": 3,
  "rows": 6
}
[/block]
Saiba mais sobre pagamentos com voucher através de nossa [API Reference](https://docs.mundipagg.com/reference#voucher-1)!