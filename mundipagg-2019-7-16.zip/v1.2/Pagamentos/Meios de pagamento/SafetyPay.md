---
title: "SafetyPay"
excerpt: ""
---
A **SafetyPay**  possibilita transferência entre contas com diversos bancos e a realização de depósitos identificados na lotérica. 
[block:callout]
{
  "type": "info",
  "body": "Essa solução não obriga o lojista a possuir contas em diversos bancos, uma vez que a relação com estes é centralizada pela SafetyPay.",
  "title": "Praticidade"
}
[/block]
Uma compra com safetypay (transferência) segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/37c12dc-fluxo-safetypay-banco.png",
        "fluxo-safetypay-banco.png",
        1500,
        1500,
        "#2c91b9"
      ],
      "sizing": "full"
    }
  ]
}
[/block]
Quando o cliente realizar a compra, a Mundi gerará uma URL para que você possa redirecioná-lo à uma página da SafetyPay. Nesta página, ele poderá selecionar em qual banco quer realizar o pagamento. A SafetyPay informará os dados bancários para que seja realizada a transferência. O cliente deve se encaminhar ao site do banco ou à uma agencia bancária para realizar o pagamento.  

É necessário que a SafetyPay consulte o sistema do banco sobre o status final da transação e atualize a MundiPagg sobre o status. Logo, a MundiPagg notifica o sistema da sua loja, através de um webhook.


Uma compra com safetypay (lotérica) segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ef6fde2-fluxo-safetypay.png",
        "fluxo-safetypay.png",
        1500,
        1500,
        "#2c92ba"
      ],
      "sizing": "full"
    }
  ]
}
[/block]
Quando o cliente realizar a compra, a Mundi gerará uma URL para que você possa redirecioná-lo à uma página da SafetyPay. Nesta página, ele poderá selecionar a opção de pagamento em uma lotérica. A SafetyPay disponibilizará um identificador numérico (único) para que seja informado pelo cliente, à lotérica. Com o identificador em mãos, o cliente poderá efetuar o pagamento na lotérica e o valor cairá em uma conta bancária do SafetyPay.

É necessário que a SafetyPay consulte o sistema do banco relacionado a sua conta sobre o status final da transação e atualize a MundiPagg sobre o status. Logo, a MundiPagg notificará o sistema da sua loja, através de um webhook.
[block:callout]
{
  "type": "warning",
  "body": "Em ambos os casos o dinheiro cai em uma conta da SafetyPay e eles repassam o dinheiro para você.",
  "title": "Atenção!"
}
[/block]
##[**Bancos**]()

A SafetyPay está integrada com os principais bancos do mercado, são eles:

* Banco do Brasil
* Itaú
* Bradesco
* Caixa
* Santander
* Banrisul
* Lotérica

Saiba mais sobre pagamentos com SafetyPay através de nossa [API Reference](https://docs.mundipagg.com/reference#meio-de-pagamento-safetypay)!