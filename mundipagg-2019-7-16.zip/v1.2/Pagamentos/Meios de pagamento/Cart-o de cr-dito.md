---
title: "Cartão de crédito"
excerpt: ""
---
Uma compra não presencial com um **cartão de crédito** segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4e783e1-fluxo-cartao-credito.png",
        "fluxo-cartao-credito.png",
        1500,
        1500,
        "#278cb7"
      ]
    }
  ]
}
[/block]
A MundiPagg recebe os dados do cartão enviado pela loja e envia os mesmos para a adquirente, que em seguida faz a comunicação com a bandeira do cartão utilizado e com o banco emissor.

Em uma transação de cartão não presente é possível realizar as seguintes ações:
   - [Pre-autorizar](): Com a pré autorização, o limite do cliente é reservado, e a transação pode ser capturada num momento posterior. Essa funcionalidade é útil para a análise de antifraude ou para checagem de estoque antes da concretização da venda.
   - [Cancelar](https://docs.mundipagg.com/reference#cancelar-cobranca) (total/parcial): O cancelamento ocorre quando uma transação é desfeita. 
   - [Capturar](https://docs.mundipagg.com/reference#capturar-cobrança) (total/parcial): A captura efetiva a cobrança no cartão do cliente.

##[**Adquirentes**]()
A MundiPagg está integrada com as principais adquirentes do mercado. São elas:
  * Cielo
  * GetNet
  * Global Payments
  * Elavon
  * Rede
  * Bin
  * Stone

Saiba mais sobre pagamentos com cartão de crédito através de nossa [API Reference](https://docs.mundipagg.com/reference#cartão-de-crédito-1)!