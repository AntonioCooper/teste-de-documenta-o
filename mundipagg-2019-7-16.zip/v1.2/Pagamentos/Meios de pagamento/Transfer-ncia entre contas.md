---
title: "Transferência entre contas"
excerpt: ""
---
Neste meio de pagamento a transação se dá por meio de uma **Transferência entre Contas** realizada no ambiente do banco.


Uma compra com transferência segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4e56f2b-fluxo-transferencia-online.png",
        "fluxo-transferencia-online.png",
        1112,
        1036,
        "#2a90b9"
      ],
      "sizing": "80"
    }
  ]
}
[/block]
Ao realizar a compra, o consumidor é redirecionado à página do banco, onde realiza um acesso autenticado por senha/token e efetua transação. Como o cliente foi redirecionado para o ambiente do banco, é necessário que a Mundi consulte o sistema do banco sobre o status final da transação e atualize o seu sistema através de um webhook.
[block:callout]
{
  "type": "info",
  "body": "Por ser uma transferência, não existe a possibilidade de chargeback ou estorno automático, assim como acontece em transações de cartão de crédito. Caso você deseje estornar essa transação, é necessário realizar uma transferência direto no banco para a conta do consumidor.",
  "title": "Desfazimento transacional"
}
[/block]
##[**Bancos**]()

A Mundipagg está integrada com os principais bancos do mercado, são eles:

  * Itaú
  * Banco do Brasil
  * Bradesco

Saiba mais sobre pagamentos com transferência entre contas através de nossa [API Reference](https://docs.mundipagg.com/reference#meio-de-pagamento-transferência-entre-contas)!