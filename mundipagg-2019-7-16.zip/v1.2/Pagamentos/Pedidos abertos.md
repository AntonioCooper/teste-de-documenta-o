---
title: "Pedidos abertos"
excerpt: ""
---
Ao utilizar os pedidos temos a possibilidade de criá-los **fechados** ou **abertos**. 

Ao contrário do pedido fechado, que impossibilita alterações dos itens da compra, para criarmos um **pedido aberto** basta enviarmos o campo `closed = false`. Nele você tem a possibilidade de incluir pagamentos e gerenciar seus itens livremente.
[block:callout]
{
  "type": "info",
  "title": "Carrinho de compras na nuvem",
  "body": "Esse tipo de pedido possibilita a implementação de carrinhos de compra na nuvem, fazendo com que você possa armazenar o carrinho do consumidor em nosso sistema sem que ele tenha que realizar o pagamento."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Atenção",
  "body": "O pedido aberto não fecha automaticamente. É necessário que você feche-o e altere o seu **status** para `paid`."
}
[/block]
## [**Funcionalidades relacionadas ao pedido aberto**]()
São disponibilizados os seguintes recursos relativos a um pedido aberto:
[block:parameters]
{
  "data": {
    "0-0": "**1)** [Incluir itens](https://docs.mundipagg.com/v1/reference#incluir-item-1)",
    "1-0": "**2)**  [Excluir itens](https://docs.mundipagg.com/v1/reference#deletar-item)",
    "2-0": "**3)** [Editar itens](https://docs.mundipagg.com/v1/reference#editar-item-do-pedido)",
    "3-0": "**4)** [Remover todos os itens](https://docs.mundipagg.com/v1/reference#remover-todos-os-itens)",
    "4-0": "**5)** [Incluir pagamento](https://docs.mundipagg.com/v1/reference#incluir-pagamento-no-pedido)",
    "5-0": "**6)** [Fechar um pedido](https://docs.mundipagg.com/v1/reference#fechar-um-pedido)"
  },
  "cols": 1,
  "rows": 6
}
[/block]
Saiba mais sobre pedidos abertos através de nossa [API Reference](https://docs.mundipagg.com/reference#objeto-pedido)!