---
title: "Split"
excerpt: ""
---
Utilizando a funcionalidade de **Split**, você pode criar um pedido que terá mais de um recebedor. Tais recebedores terão acesso a parte do valor da compra. Podem ser informados os valores ou as porcentagens que serão destinados a cada um dos recebedores. 

Para dar prosseguimento a esse tipo de pedido, é necessário que dentro de `payments` seja indicado que está sendo feito um `Split` com os seguintes dados: 

`type`(Tipo de Split. Pode ser feita em valores (flat) ou em porcentagem (percentage)) 
`amount`(Valor destinado a cada recebedor) 
`recipient_id` (Identificação do recebedor)
 
Além disso, é necessária a criação dos recebedores e de suas contas bancárias para que os valores lhes sejam destinados corretamente. Como ações relativas a Split, temos:

**1)** [Criar recebedor ](https://docs.mundipagg.com/reference#criar-recebedor)
**2)** [Editar recebedor](https://docs.mundipagg.com/reference#editar-recebedor)
**3)** [Criar pedido com Split ](https://docs.mundipagg.com/reference#criar-pedido-com-split)


**Exemplo: **
Valter anunciou seu carro em um Markplace com o valor de R$15.000,00. Felizmente, a venda foi concluída com sucesso, mas ao final da negociação, ele só recebeu R$14.850,00. Isso porque o Markplace havia acertado, via API MundiPagg, que 1% da venda (R$150,00) deveria ser enviada para sua conta e o restante (99%) para a conta de Valter.

Saiba mais sobre pedidos com Split através de nossa [API Reference](https://docs.mundipagg.com/reference#criar-pedido-com-split)!