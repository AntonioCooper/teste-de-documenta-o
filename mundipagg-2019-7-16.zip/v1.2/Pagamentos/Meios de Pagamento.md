---
title: "Meios de Pagamento"
excerpt: ""
---
Em nossas [cobranças](ref:criar-cobranca) e [pedidos](ref:criar-pedido), o nó `payment` pode comportar os meios de pagamento: `credit_card`, `boleto`, `bank_transfer`, `safetypay` e `voucher`. Para os pedidos, além desses, também está disponível o meio de pagamento `checkout`.