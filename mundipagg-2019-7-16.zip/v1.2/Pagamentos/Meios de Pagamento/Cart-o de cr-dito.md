---
title: "Cartão de crédito"
excerpt: ""
---
Para criar uma [cobrança](ref:criar-cobranca) ou um [pedido](ref:criar-pedido) com cartão de crédito, devemos incluir o objeto `credit_card` dentro do nó `payment`, assim como a propriedade `"payment_method": "credit_card"`.
[block:parameters]
{
  "data": {
    "0-0": "`installments`",
    "0-1": "**integer**",
    "1-0": "`statement_descriptor`",
    "1-1": "**string**",
    "2-0": "`capture`",
    "2-1": "**boolean**",
    "3-0": "`card`, `card_id` ou `card_token`",
    "3-1": "**object**",
    "4-0": "`recurrence`",
    "4-1": "**boolean**",
    "5-0": "`metadata`",
    "5-1": "**object**",
    "0-2": "Quantidade de parcelas. O padrão é **1**.",
    "1-2": "Texto exibido na fatura do cartão. Max: 22 caracteres.",
    "2-2": "Indica se o pagamento deve ser processado imediatamente. Caso seja **false** o pagamento deverá ser confirmado posteriormente. O padrão é **true**.",
    "3-2": "Cartão de crédito. \n**- card_id** é o identificador do cartão de um cliente.\n**- card_token** é o token do cartão gerado pelo checkout transparente.\n[Saiba mais sobre cartões](ref:objeto-cartao)",
    "4-2": "Indica se é uma cobrança/pedido de recorrência. O padrão é **false**",
    "5-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.\n\nOBS: Chave \"mundipagg_payment_method_code\" poderá ser utilizada para  informar o código da adquirente - com o objetivo de indicar em qual adquirente será processado o pagamento.",
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "6-0": "`extended_limit_enabled`",
    "6-1": "**boolean**",
    "6-2": "Indica se o super limite (para cartões private label) está habilitado",
    "7-0": "`extended_limit_code`",
    "7-1": "**string**",
    "7-2": "Código do super limite (para cartões private label)",
    "8-0": "`merchant_category_code`",
    "8-1": "**integer**",
    "8-2": "Código de classificação do ramo de atuação do lojista."
  },
  "cols": 3,
  "rows": 9
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 200000,\n  \"customer\": {\n    \"name\": \"Tony Stark\",\n    \"email\": \"email@email.com\",\n    \"metadata\": {\n      \"company\": \"MundiPagg\"\n    }\n  },\n  \"payment\":{\n   \"metadata\":{\n     \"mundipagg_payment_method_code\": \"1\"\n   },\n   \"payment_method\": \"credit_card\",\n   \"credit_card\": {\n     \"merchant_category_code\" : 7025,\n     \"extended_limit_enabled\": false,\n     \"extended_limit_code\": null,\n      \"recurrence\": false,\n      \"installments\": 1,\n      \"statement_descriptor\": \"AVENGERS\",\n      \"card\": {\n        \"number\": \"342793631858229\",\n        \"holder_name\": \"Tony Stark\",\n        \"exp_month\": 1,\n        \"exp_year\": 20,\n        \"cvv\": \"3531\",\n        \"billing_address\": {\n          \"street\": \"Malibu Point\",\n          \"number\": \"10880\",\n          \"zip_code\": \"90265\",\n          \"neighborhood\": \"Central Malibu\",\n          \"city\": \"Malibu\",\n          \"state\": \"CA\",\n          \"country\": \"US\"\n        }\n      }\n    }\n  }\n}",
      "language": "json",
      "name": "Request cartão de crédito (Cobrança)"
    },
    {
      "code": "{\n    \"id\": \"ch_4qbkd9ULBh8aD9lg\",\n    \"code\": \"N3YKB9GTD2\",\n    \"gateway_id\": \"10770bd4-3cb9-4384-a6de-e11b43d75c4f\",\n    \"amount\": 2000,\n    \"status\": \"paid\",\n    \"currency\": \"BRL\",\n    \"payment_method\": \"credit_card\",\n    \"paid_at\": \"2017-07-05T16:57:36Z\",\n    \"created_at\": \"2017-07-05T16:57:35Z\",\n    \"updated_at\": \"2017-07-05T16:57:35Z\",\n    \"customer\": {\n        \"id\": \"cus_X46GD9GcQ4ckLWgz\",\n        \"name\": \"Tony Stark\",\n        \"email\": \"email@email.com\",\n        \"delinquent\": false,\n        \"created_at\": \"2017-07-05T16:57:09Z\",\n        \"updated_at\": \"2017-07-05T16:57:09Z\",\n        \"phones\": {},\n        \"metadata\": {\n            \"company\": \"MundiPagg\"\n        }\n    },\n    \"last_transaction\": {\n        \"id\": \"tran_evqjL0LsoQtojKdr\",\n        \"transaction_type\": \"credit_card\",\n        \"gateway_id\": \"5df60eb8-0545-4fc4-a852-3b9bae3eb656\",\n        \"amount\": 2000,\n        \"status\": \"captured\",\n        \"success\": true,\n        \"installments\": 1,\n        \"statement_descriptor\": \"AVENGERS\",\n        \"acquirer_name\": \"simulator\",\n        \"acquirer_affiliation_code\": \"000000000\",\n        \"acquirer_tid\": \"984204\",\n        \"acquirer_nsu\": \"977090\",\n        \"acquirer_auth_code\": \"445191\",\n        \"acquirer_message\": \"Simulator|Transação de simulação autorizada com sucesso\",\n        \"acquirer_return_code\": \"0\",\n        \"operation_type\": \"auth_and_capture\",\n        \"card\": {\n            \"id\": \"card_lXzrODhnySAlmdMe\",\n            \"last_four_digits\": \"8229\",\n            \"brand\": \"Amex\",\n            \"holder_name\": \"Tony Stark\",\n            \"exp_month\": 1,\n            \"exp_year\": 2020,\n            \"status\": \"active\",\n            \"created_at\": \"2017-07-05T16:57:09Z\",\n            \"updated_at\": \"2017-07-05T16:57:09Z\",\n            \"billing_address\": {\n                \"street\": \"Malibu Point\",\n                \"number\": \"10880\",\n                \"zip_code\": \"90265\",\n                \"neighborhood\": \"Central Malibu\",\n                \"city\": \"Malibu\",\n                \"state\": \"CA\",\n                \"country\": \"US\"\n            },\n            \"type\": \"credit\"\n        },\n        \"created_at\": \"2017-07-05T16:57:36Z\",\n        \"updated_at\": \"2017-07-05T16:57:36Z\",\n        \"gateway_response\": {\n            \"code\": \"201\"\n        }\n    }\n}",
      "language": "json",
      "name": "Response cartão de crédito (Cobrança)"
    }
  ]
}
[/block]