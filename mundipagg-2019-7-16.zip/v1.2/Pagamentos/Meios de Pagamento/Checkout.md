---
title: "Checkout"
excerpt: ""
---
Para criar um [pedido](ref:criar-pedido) com checkout, devemos incluir o objeto `checkout` dentro do nó `payment`, assim como a propriedade `"payment_method": "checkout"`. **É importante notar que o meio de pagamento checkout é suportado somente por pedidos, não podendo ser utilizado em cobranças.** 
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`accepted_payment_method`",
    "0-1": "**array of string**",
    "0-2": "Meios de pagamento aceitos para o checkout. Valores possíveis: **credit_card** e **boleto**.",
    "1-0": "`default_payment_method`",
    "1-1": "**string**",
    "1-2": "Meio de pagamento padrão.",
    "2-0": "`success_url`",
    "2-1": "**string**",
    "2-2": "URL para redirecionamento de sucesso.",
    "3-0": "`credit_card`",
    "3-1": "**object**",
    "3-2": "Configurações para pagamento com cartão de crédito.",
    "5-0": "`credit_card.statement_descriptor`",
    "5-1": "**string**",
    "5-2": "Texto da fatura do cartão.",
    "6-0": "`credit_card.installments`",
    "6-1": "**array of objects**",
    "6-2": "Array de configuraçãos de parcelas.",
    "7-0": "`credit_card.installments.number`",
    "7-2": "Quantidade de parcelas.",
    "7-1": "**number**",
    "8-0": "`credit_card.installments.total`",
    "8-1": "**number**",
    "8-2": "Valor total referente à quantidade de parcelas.",
    "9-0": "`boleto`",
    "9-1": "**object**",
    "9-2": "Configurações para pagamento com boleto.",
    "10-0": "`boleto.due_at`",
    "10-1": "**string**",
    "10-2": "Data de vencimento do boleto",
    "11-0": "`boleto.instructions`",
    "11-1": "**string**",
    "11-2": "Instruções do boleto.",
    "14-0": "`metadata`",
    "14-1": "**object**",
    "14-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.",
    "12-0": "`skip_checkout_success_page`",
    "12-1": "**boolean**",
    "12-2": "Permite pular a tela de redirecionamento pós pagamento.",
    "13-0": "`customer_editable`",
    "13-1": "**boolean**",
    "13-2": "Torna o objeto do cliente editável",
    "4-0": "`credit_card.capture`",
    "4-1": "**boolean**",
    "4-2": "Indica se a transação deve ser capturada ou somente autorizada. Caso seja \"true\", o valor é capturado simultaneamente à autorização.",
    "15-0": "`bank_transfer`",
    "15-1": "**object**",
    "15-2": "Configurações para pagamento via transferência bancária.",
    "16-0": "`bank_transfer.bank`",
    "16-1": "**array of objects**",
    "16-2": "Array de configurações para indicar quais bancos serão utilizados para a transferência bancária",
    "17-0": "`expires_in`",
    "17-1": "**integer**",
    "17-2": "Tempo em minutos para a expiração do checkout",
    "18-0": "`billing_address_editable`",
    "18-1": "**boolean**",
    "18-2": "Torna o objeto billing address editável",
    "19-0": "`billing_address`",
    "19-1": "**object**",
    "19-2": "Configuração para endereço de cobrança"
  },
  "cols": 3,
  "rows": 20
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n   \"items\":[\n      {\n         \"amount\":2990,\n         \"description\":\"Chaveiro do Tesseract\",\n         \"quantity\":1\n      }\n   ],\n   \"customer\":{\n      \"name\":\"Tony Stark\",\n      \"email\":\"tstark@avengers.com\"\n   },\n   \"payments\":[\n      {\n         \"payment_method\":\"checkout\",\n         \"amount\":2000,\n         \"checkout\": {\n           \"customer_editable\" : false,\n           \"skip_checkout_success_page\": true,\n           \"accepted_payment_methods\": [ \"credit_card\", \"bank_transfer\" ],\n           \"success_url\": \"https://www.mundipagg.com\",\n           \"banktransfer\": {\n              \"bank\": [\"237\", \"001\", \"341\"]\n           },\n           \"credit_card\": {\n              \"capture\": true,\n              \"statement_descriptor\": \"Desc na fatura\",\n              \"installments\": [\n                {\n                  \"number\": 1,\n                  \"total\": 2000\n                },\n                {\n                  \"number\": 2,\n                  \"total\": 2500\n                }\n             ]\n           }\n         }\n      }\n   ]\n}",
      "language": "json",
      "name": "Request checkout (Pedido)"
    },
    {
      "code": "{\n    \"id\": \"or_5ayWvnd3cbHr4w06\",\n    \"code\": \"5YG7FQF975\",\n    \"amount\": 2990,\n    \"currency\": \"BRL\",\n    \"closed\": false,\n    \"items\": [\n        {\n            \"id\": \"oi_yB6wRX8psDU7RVPb\",\n            \"description\": \"Chaveiro do Tesseract\",\n            \"amount\": 2990,\n            \"quantity\": 1,\n            \"status\": \"active\",\n            \"created_at\": \"2018-01-05T22:10:28Z\",\n            \"updated_at\": \"2018-01-05T22:10:28Z\"\n        }\n    ],\n    \"customer\": {\n        \"id\": \"cus_XenkEVAFQfZ98mo3\",\n        \"name\": \"Tony Stark\",\n        \"email\": \"tstark@avengers.com\",\n        \"delinquent\": false,\n        \"created_at\": \"2018-01-05T22:08:00Z\",\n        \"updated_at\": \"2018-01-05T22:08:00Z\",\n        \"phones\": {}\n    },\n    \"Shipping\": {\n          \"amount\": 1000,\n          \"description\": \"Express Shipping\",\n          \"recipient_name\": \"Gustavo Fonseca\",\n          \"recipient_phone\": \"707070707070\",\n          \"address\": {\n  \t\t\t\t\t\t\"line_1\": \"375, Av. General Justo, Centro\",\n              \"line_2\": \"8º andar\",\n              \"zip_code\": \"20021130\",\n              \"city\": \"Rio de Janeiro\",\n              \"state\": \"RJ\",\n              \"country\": \"BR\",\n              \"metadata\": {\n                \"id\": \"my_address_id\"\n  \t\t\t\t\t}\n\t\t\t\t\t}\n        },\n  \t\"shippable\" : true,\n    \"status\": \"pending\",\n    \"created_at\": \"2018-01-05T22:10:28Z\",\n    \"updated_at\": \"2018-01-05T22:10:28Z\",\n    \"checkouts\": [\n        {\n            \"id\": \"chk_mLoWDeXQuXcyj24O\",\n            \"amount\": 2000,\n          \t\"currency\" : \"BRL\",\n            \"success_url\": \"https://www.mundipagg.com\",\n            \"payment_url\": \"https://api.mundipagg.com/checkout/v1/orders/chk_mLoWDeXQuXcyj24O\",\n            \"accepted_payment_methods\": [\n                \"credit_card\"\n            ],\n            \"status\": \"open\",\n            \"skip_checkout_success_page\": true,\n            \"created_at\": \"2018-01-05T22:10:28Z\",\n            \"expires_at\": \"2018-02-05T22:08:00Z\",\n            \"updated_at\": \"2018-01-05T22:10:28Z\",\n            \"customer_editable\" : false,\n            \"customer\": {\n                \"id\": \"cus_XenkEVAFQfZ98mo3\",\n                \"name\": \"Tony Stark\",\n                \"email\": \"tstark@avengers.com\",\n                \"delinquent\": false,\n                \"created_at\": \"2018-01-05T22:08:00Z\",\n                \"updated_at\": \"2018-01-05T22:08:00Z\",\n                \"phones\": {}\n            },\n            \"billing_address_editable\" : false,\n            \"billing_address\": {\n                  \"street\": \"Malibu Point\",\n                  \"number\": \"10880\",\n                  \"zip_code\": \"90265\",\n                  \"neighborhood\": \"Central Malibu\",\n                  \"city\": \"Malibu\",\n                  \"state\": \"CA\",\n                  \"country\": \"US\"\n                },\n             \"shippable\" : true,\n             \"shipping\": {\n             \"amount\": 1000,\n             \"description\": \"Express Shipping\",\n             \"recipient_name\": \"Gustavo Fonseca\",\n             \"recipient_phone\": \"707070707070\",\n             \"address\": {\n                 \"line_1\": \"375, Av. General Justo, Centro\",\n                 \"line_2\": \"8º andar\",\n                 \"zip_code\": \"20021130\",\n                 \"city\": \"Rio de Janeiro\",\n                 \"state\": \"RJ\",\n                 \"country\": \"BR\",\n                 \"metadata\": {\n                   \"id\": \"my_address_id\"\n               }\n             }\n           },\n            \"bank_transfer\": {\n                \"bank\": [\n                    \"234\",\n                    \"001\",\n                    \"033\"\n                ]\n            },\n            \"credit_card\": {\n                \"statementDescriptor\": \"Desc na fatura\",\n                \"installments\": [\n                    {\n                        \"number\": 1,\n                        \"total\": 2000\n                    },\n                    {\n                        \"number\": 2,\n                        \"total\": 2500\n                    }\n                ]\n            }\n        }\n    ]\n}",
      "language": "json",
      "name": "Response checkout (Pedido)"
    }
  ]
}
[/block]