---
title: "SafetyPay"
excerpt: ""
---
Para criar uma [cobrança](ref:criar-cobranca) ou um[pedido](ref:criar-pedido) com SafetyPay, devemos incluir a propriedade `"payment_method": "safetypay"` dentro do nó `payment`.
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 1490,\n  \"customer\": {\n    \"name\": \"Tony Stark\",\n    \"email\": \"{{email}}\",\n    \"document\": \"24551132802\",\n    \"type\" : \"individual\"\n  },\n  \"payment\":{\n    \"metadata\":{\n     \"code\": \"4\"  \n   },\n    \"payment_method\": \"safetypay\"\n  },\n  \"metadata\": {\n    \"code\": \"123\"\n  }\n}",
      "language": "json",
      "name": "Request SafetyPay (Cobrança)"
    },
    {
      "code": "{\n    \"id\": \"ch_GM0yWaBkFmuZV5lo\",\n    \"code\": \"5GV2BQS6K5\",\n    \"gateway_id\": \"7a9610b3-bbc0-4ec0-831f-cfdb87744ae4\",\n    \"amount\": 1490,\n    \"status\": \"pending\",\n    \"currency\": \"BRL\",\n    \"payment_method\": \"safetypay\",\n    \"created_at\": \"2017-07-05T16:59:30Z\",\n    \"updated_at\": \"2017-07-05T16:59:30Z\",\n    \"customer\": {\n        \"id\": \"cus_Zmqy7GJHQocWER0k\",\n        \"name\": \"Tony Stark\",\n        \"email\": \"a0b401c8-7f01-4d9a-a953-c19ebbb1806f@avengers.com\",\n        \"document\": \"24551132802\",\n        \"type\": \"individual\",\n        \"delinquent\": false,\n        \"created_at\": \"2017-07-05T16:59:30Z\",\n        \"updated_at\": \"2017-07-05T16:59:30Z\",\n        \"phones\": {}\n    },\n    \"last_transaction\": {\n        \"url\": \"https://sandbox-gateway.safetypay.com/Express4/Checkout/index?TokenID=6c60d19c-64bf-4a81-96d1-ad46bdba9764\",\n        \"safetypay_tid\": \"e09f39ad33fc4c3b\",\n        \"id\": \"tran_2vrxYNnhZpSQazQ5\",\n        \"transaction_type\": \"safetypay\",\n        \"gateway_id\": \"e09f39ad-33fc-4c3b-a88a-103df99c3614\",\n        \"amount\": 1490,\n        \"status\": \"pending\",\n        \"success\": true,\n        \"created_at\": \"2017-07-05T16:59:30Z\",\n        \"updated_at\": \"2017-07-05T16:59:30Z\",\n        \"gateway_response\": {\n            \"code\": \"201\"\n        }\n    },\n    \"metadata\": {\n        \"code\": \"123\"\n    }\n}",
      "language": "json",
      "name": "Response SafetyPay (Cobrança)"
    }
  ]
}
[/block]