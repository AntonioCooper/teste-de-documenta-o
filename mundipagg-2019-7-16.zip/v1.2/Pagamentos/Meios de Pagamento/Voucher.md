---
title: "Voucher"
excerpt: ""
---
Para criar uma [cobrança](ref:criar-cobranca) ou [pedido](ref:criar-pedido)com voucher, devemos incluir o objeto `voucher` dentro do nó `payment`, assim como a propriedade `"payment_method": "voucher"`.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`capture`",
    "0-1": "**boolean**",
    "0-2": "Indica se o pagamento deve ser processado imediatamente. Caso seja **false** o pagamento deverá ser confirmado posteriormente. O padrão é **true**.",
    "1-0": "`statement_descriptor`",
    "1-1": "**string**",
    "1-2": "Texto exibido na fatura do cartão. Max: 22 caracteres.",
    "2-0": "`card`, `card_id` ou `card_token`",
    "2-1": "**object**",
    "2-2": "Dados do cartão. \n**- card_id** é o identificador do cartão de um cliente.\n**- card_token** é o token do cartão gerado pelo checkout transparente.\n[Leia mais sobre cartões](ref:objeto-cartao).",
    "3-0": "`card.holder_document`",
    "3-1": "**string**",
    "3-2": "Número do documento do portador do cartão. Este campo deverá ser enviado dentro do objeto `card`, e é obrigatório caso o meio de pagamento escolhido seja voucher.",
    "4-0": "`metadata`",
    "4-1": "**object**",
    "4-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.",
    "5-0": "`credit_card.installments`",
    "5-1": "**array of objects**",
    "5-2": "Array de configuraçãos de parcelas.",
    "6-0": "`credit_card.installments.number`",
    "6-2": "Quantidade de parcelas.",
    "6-1": "**number**",
    "7-0": "`credit_card.installments.total`",
    "7-1": "**number**",
    "7-2": "Valor total referente à quantidade de parcelas.",
    "8-0": "`boleto`",
    "8-1": "**object**",
    "8-2": "Configurações para pagamento com boleto.",
    "9-0": "`boleto.due_at`",
    "9-1": "**string**",
    "9-2": "Data de vencimento do boleto",
    "10-0": "`boleto.instructions`",
    "10-1": "**string**",
    "10-2": "Instruções do boleto.",
    "11-0": "`gateway_affiliation_id`",
    "11-1": "**string**",
    "11-2": "Código de afiliação no gateway.",
    "12-0": "`metadata`",
    "12-1": "**object**",
    "12-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento."
  },
  "cols": 3,
  "rows": 5
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 200000,\n  \"customer\": {\n    \"name\": \"Tony Stark\",\n    \"email\": \"email@email.com\",\n    \"metadata\": {\n      \"company\": \"MundiPagg\"\n    }\n  },\n  \"payment\":{\n    \"metadata\":{\n     \"code\": \"6\"  \n   },\n    \"payment_method\": \"voucher\",\n   \"voucher\": {\n      \"statement_descriptor\": \"AVENGERS\",\n      \"card\": {\n        \"number\": \"6033890101091462\",\n        \"holder_name\": \"Tony Stark\",\n        \"holder_document\": \"93095135270\",\n        \"exp_month\": 1,\n        \"exp_year\": 20,\n        \"cvv\": \"351\",\n        \"billing_address\": {\n          \"street\": \"Malibu Point\",\n          \"number\": \"10880\",\n          \"zip_code\": \"90265\",\n          \"neighborhood\": \"Central Malibu\",\n          \"city\": \"Malibu\",\n          \"state\": \"CA\",\n          \"country\": \"US\"\n        }\n      }\n    }\n  }\n}",
      "language": "json",
      "name": "Request voucher (cobrança)"
    },
    {
      "code": "{\n    \"id\": \"ch_OlD7AZwTbMs6VnBb\",\n    \"code\": \"X2ZSVNUGP7\",\n    \"gateway_id\": \"1cb59dd1-b57c-47ec-9bac-803d6ddd5eba\",\n    \"amount\": 2000,\n    \"paid_amount\": 2000,\n    \"status\": \"paid\",\n    \"currency\": \"BRL\",\n    \"payment_method\": \"voucher\",\n    \"paid_at\": \"2017-09-11T16:37:47Z\",\n    \"created_at\": \"2017-09-11T16:37:46Z\",\n    \"updated_at\": \"2017-09-11T16:37:46Z\",\n    \"customer\": {\n        \"id\": \"cus_roAvZy1HmIW7ZzG3\",\n        \"name\": \"Tony Stark\",\n        \"email\": \"email@email.com\",\n        \"type\": \"\",\n        \"delinquent\": false,\n        \"created_at\": \"2017-04-28T18:24:19Z\",\n        \"updated_at\": \"2017-09-11T16:32:53Z\",\n        \"phones\": {},\n        \"metadata\": {\n            \"company\": \"MundiPagg\"\n        }\n    },\n    \"last_transaction\": {\n        \"id\": \"tran_LBgVZRJyIgtnZ1ry\",\n        \"transaction_type\": \"voucher\",\n        \"gateway_id\": \"50ce1756-335a-433b-89d1-69afc2797f33\",\n        \"amount\": 2000,\n        \"status\": \"captured\",\n        \"success\": true,\n        \"statement_descriptor\": \"AVENGERS\",\n        \"acquirer_name\": \"simulator\",\n        \"acquirer_affiliation_code\": \"MUNDI\",\n        \"acquirer_tid\": \"652894\",\n        \"acquirer_nsu\": \"724175\",\n        \"acquirer_auth_code\": \"369074\",\n        \"acquirer_message\": \"Simulator|Transação de simulação autorizada com sucesso\",\n        \"acquirer_return_code\": \"0\",\n        \"operation_type\": \"auth_and_capture\",\n        \"card\": {\n            \"id\": \"card_4wJODqpqS0C6nMbq\",\n            \"first_six_digits\": \"600818\",\n            \"last_four_digits\": \"3014\",\n            \"brand\": \"Sodexo\",\n            \"holder_name\": \"Tony Stark\",\n            \"holder_document\": \"93095135270\",\n            \"exp_month\": 1,\n            \"exp_year\": 2018,\n            \"status\": \"active\",\n            \"created_at\": \"2017-09-11T16:37:13Z\",\n            \"updated_at\": \"2017-09-11T16:37:46Z\",\n            \"billing_address\": {\n                \"street\": \"Malibu Point\",\n                \"number\": \"10880\",\n                \"zip_code\": \"90265\",\n                \"neighborhood\": \"Central Malibu\",\n                \"city\": \"Malibu\",\n                \"state\": \"CA\",\n                \"country\": \"US\"\n            },\n            \"customer\": {\n                \"id\": \"cus_roAvZy9HmIW7ZzG3\",\n                \"name\": \"Tony Stark\",\n                \"email\": \"email@email.com\",\n                \"type\": \"\",\n                \"delinquent\": false,\n                \"created_at\": \"2017-04-28T18:24:19Z\",\n                \"updated_at\": \"2017-09-11T16:32:53Z\",\n                \"phones\": {},\n                \"metadata\": {\n                    \"company\": \"MundiPagg\"\n                }\n            },\n            \"type\": \"voucher\"\n        },\n        \"created_at\": \"2017-09-11T16:37:46Z\",\n        \"updated_at\": \"2017-09-11T16:37:46Z\",\n        \"gateway_response\": {\n            \"code\": \"201\"\n        }\n    }\n}",
      "language": "json",
      "name": "Response voucher (Cobrança)"
    }
  ]
}
[/block]