---
title: "Transferência entre contas"
excerpt: ""
---
Para criar uma [cobrança](ref:criar-cobranca) ou [pedido](ref:criar-pedido) com  transferência entre contas, devemos incluir a propriedade `"payment_method": "bank_transfer"` dentro do nó `payment`, e caso necessário o objeto `bank_transfer`.
[block:parameters]
{
  "data": {
    "0-0": "`bank`",
    "0-1": "**string**",
    "1-0": "`metadata`",
    "1-1": "**object**",
    "2-0": "`gateway_affiliation_id`",
    "2-1": "**string**",
    "3-0": "`metadata`",
    "3-1": "**object**",
    "4-0": "`recurrence`",
    "4-1": "**boolean**",
    "5-0": "`metadata`",
    "5-1": "**object**",
    "0-2": "Código do banco. **001** (Banco do Brasil), **237** (Bradesco), **341** (Itau)",
    "1-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.",
    "2-2": "Código de afiliação no gateway.",
    "3-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.",
    "4-2": "Indica se é uma cobrança/pedido de recorrência. O padrão é **false**",
    "5-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.\n\nOBS: Chave \"mundipagg_payment_method_code\" poderá ser utilizada para  informar o código da adquirente - com o objetivo de indicar em qual adquirente será processado o pagamento.",
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "Você pode configurar um código padrão para a sua loja. Desta forma, você não precisa enviá-lo em toda requisição e o nó `bank_transfer` será opcional.",
  "title": "Código do banco padrão"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 1490000,\n  \"customer\": {\n    \"name\": \"Tony Stark\",\n    \"email\": \"{{email}}\",\n  \"document\": \"57510831563\",\n  \"type\": \"individual\"\n  },\n  \"payment\":{\n    \"metadata\":{\n\t     \"code\": \"3\"  \n   },\n    \"payment_method\": \"bank_transfer\",\n    \"bank_transfer\":{\n    \t\"bank\": 001\n    }\n  },\n  \"metadata\": {\n    \"code\": \"123\"\n  }\n}",
      "language": "json",
      "name": "Request Transferência entre contas (Cobrança)"
    },
    {
      "code": "{\n    \"id\": \"ch_j2bkebpurbCgEGpq\",\n    \"code\": \"0X7JFVQSN0\",\n    \"gateway_id\": \"364b6d2e-62e9-4fed-8646-3af3320d153b\",\n    \"amount\": 1490000,\n    \"status\": \"pending\",\n    \"currency\": \"BRL\",\n    \"payment_method\": \"bank_transfer\",\n    \"created_at\": \"2017-07-05T16:52:36Z\",\n    \"updated_at\": \"2017-07-05T16:52:36Z\",\n    \"customer\": {\n        \"id\": \"cus_1rp2jAES3RCwnyz0\",\n        \"name\": \"Tony Stark\",\n        \"email\": \"974169e4-9f6c-42ef-8355-a82a4ef4c388@avengers.com\",\n        \"document\": \"57510831563\",\n        \"type\": \"individual\",\n        \"delinquent\": false,\n        \"created_at\": \"2017-07-05T16:52:36Z\",\n        \"updated_at\": \"2017-07-05T16:52:36Z\",\n        \"phones\": {}\n    },\n    \"last_transaction\": {\n        \"url\": \"https://onlinedebitsandbox.mundipaggone.com:4443/OnlineDebit/Checkout/e17a8b29-857a-4087-8d27-4c0ab4e2e08b\",\n        \"bank_tid\": \"00000427\",\n        \"bank\": \"341\",\n        \"id\": \"tran_kEnJLNRH2sBLdBpW\",\n        \"transaction_type\": \"bank_transfer\",\n        \"gateway_id\": \"e17a8b29-857a-4087-8d27-4c0ab4e2e98b\",\n        \"amount\": 1490000,\n        \"status\": \"pending\",\n        \"success\": true,\n        \"created_at\": \"2017-07-05T16:52:36Z\",\n        \"updated_at\": \"2017-07-05T16:52:36Z\",\n        \"gateway_response\": {\n            \"code\": \"201\"\n        }\n    },\n    \"metadata\": {\n        \"code\": \"123\"\n    }\n}",
      "language": "json",
      "name": "Response Transferência entre contas (Cobrança)"
    }
  ]
}
[/block]