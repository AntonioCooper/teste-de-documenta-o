---
title: "Boleto"
excerpt: ""
---
Para criar uma [Cobrança](ref:criar-cobranca) ou [Pedido](ref:criar-pedido) com boleto, devemos incluir o objeto `boleto` dentro do nó `payment`, assim como a propriedade `"payment_method": "boleto"`.
[block:parameters]
{
  "data": {
    "0-0": "`bank`",
    "0-1": "**string**",
    "1-0": "`instructions`",
    "1-1": "**string**",
    "2-0": "`due_at`",
    "2-1": "**datetime**",
    "3-0": "`metadata`",
    "3-1": "**object**",
    "4-0": "`nosso_numero`",
    "4-1": "**string**",
    "0-2": "Código do banco. **001** (Banco do Brasil), **033** (Santander), **237** (Bradesco), **341** (Itau), **745** (Citibank) e **104** (Caixa).",
    "1-2": "Instruções do boleto. Max: 256 caracteres.",
    "2-2": "Data de vencimento. (**Obrigatório**)",
    "3-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento.",
    "4-2": "Número que identifica unicamente um boleto para uma conta.",
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição"
  },
  "cols": 3,
  "rows": 5
}
[/block]

[block:callout]
{
  "type": "danger",
  "body": "Para requisições de cobrança de **boletos com registro** os campos `name`, `address` e `document` do cliente (objeto `customer`) devem ser enviados OBRIGATORIAMENTE.",
  "title": "Atenção!"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"amount\": 1490,\n  \"customer\": {\n      \"name\": \"Tony Stark\",\n      \"email\": \"tstark@avengers.com\",\n      \"address\": {\n          \"street\": \"Av. General Justo\",\n          \"number\": \"375\",\n          \"complement\": \"9º andar\",\n          \"zip_code\": \"20021130\",\n          \"neighborhood\": \"Centro\",\n          \"city\": \"Rio de Janeiro\",\n          \"state\": \"RJ\",\n          \"country\": \"BR\"\n      }\n  },\n  \"payment\": {\n    \"metadata\":{\n\t     \"code\": \"2\"  \n   },\n      \"payment_method\": \"boleto\",\n      \"boleto\": {\n        \"bank\": \"033\",\n        \"instructions\": \"Pagar até o vencimento\",\n        \"due_at\": \"2020-09-20T00:00:00Z\"\n      }\n  }\n}",
      "language": "json",
      "name": "Request boleto (Cobrança)"
    },
    {
      "code": "{\n    \"id\": \"ch_myqEBxohLaCmp8NJ\",\n    \"code\": \"XQKMIQYU7E\",\n    \"gateway_id\": \"54b4e150-fe87-4216-a72d-c84081b4f5db\",\n    \"amount\": 1490,\n    \"status\": \"pending\",\n    \"currency\": \"BRL\",\n    \"payment_method\": \"boleto\",\n    \"created_at\": \"2017-07-05T16:55:20Z\",\n    \"updated_at\": \"2017-07-05T16:55:20Z\",\n    \"customer\": {\n        \"id\": \"cus_D7LQBbRU6qF9QO42\",\n        \"name\": \"Tony Stark\",\n        \"email\": \"tstark@avengers.com\",\n        \"delinquent\": false,\n        \"address\": {\n            \"id\": \"addr_OZ9yQGdIOF9AvYMK\",\n            \"street\": \"Av. General Justo\",\n            \"number\": \"375\",\n            \"complement\": \"9º andar\",\n            \"zip_code\": \"20021130\",\n            \"neighborhood\": \"Centro\",\n            \"city\": \"Rio de Janeiro\",\n            \"state\": \"RJ\",\n            \"country\": \"BR\",\n            \"status\": \"active\",\n            \"created_at\": \"2017-07-05T16:55:20Z\",\n            \"updated_at\": \"2017-07-05T16:55:20Z\"\n        },\n        \"created_at\": \"2017-07-05T16:55:20Z\",\n        \"updated_at\": \"2017-07-05T16:55:20Z\",\n        \"phones\": {}\n    },\n    \"last_transaction\": {\n        \"id\": \"tran_kAbYK1fmNsPKwdWa\",\n        \"transaction_type\": \"boleto\",\n        \"gateway_id\": \"51c00c63-e9d4-485a-8eec-f1760e07ab9e\",\n        \"amount\": 1490,\n        \"status\": \"generated\",\n        \"success\": true,\n        \"url\": \"https://sandbox.mundipaggone.com/Boleto/ViewBoleto.aspx?51c00c63-e9d4-485a-8eec-f1762e07ab9e\",\n        \"pdf\": \"https://api.mundipagg.com/core/v1/transactions/tran_kAbYK1fmNsPKwd2a/pdf\",\n        \"line\": \"34191.75009 04191.381237 41234.510000 2 105750000001490\",\n        \"barcode\": \"https://api.mundipagg.com/core/v1/transactions/tran_kAbYK1fmNsP2wdWa/barcode\",\n        \"qr_code\": \"https://api.mundipagg.com/core/v1/transactions/tran_kAbYK1fmNs2KwdWa/qrcode\",\n        \"nosso_numero\": \"00041913\",\n        \"bank\": \"033\",\n        \"document_number\": \"045520806\",\n        \"instructions\": \"Pagar até o vencimento\",\n        \"due_at\": \"2026-09-20T00:00:00Z\",\n        \"created_at\": \"2017-07-05T16:55:20Z\",\n        \"updated_at\": \"2017-07-05T16:55:20Z\",\n        \"gateway_response\": {\n            \"code\": \"201\"\n        }\n    }\n}",
      "language": "json",
      "name": "Response boleto (Cobrança)"
    }
  ]
}
[/block]