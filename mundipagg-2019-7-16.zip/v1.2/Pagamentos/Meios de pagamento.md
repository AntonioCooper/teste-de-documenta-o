---
title: "Meios de pagamento"
excerpt: ""
---
Nossa API oferece os seguintes meios de pagamento:

  * [**Cartão de Crédito**](https://docs.mundipagg.com/docs/cartão-de-crédito)
O cartão de crédito é um meio de pagamento bastante difundido no mundo todo e é utilizado para a compra de produtos ou serviços. Os bancos emissores de cartões de crédito, disponibilizam esse meio para que seus clientes possam ter acesso a crédito instantaneamente e possam realizar o pagamento no mês seguinte mediante a cobrança de uma fatura.

  * [**Boleto Bancário**](https://docs.mundipagg.com/docs/boleto)
O boleto consiste em um documento no qual o seu banco emissor (conta emissora) pode receber de um pagador o valor acordado entre as partes. Nada mais é do que um documento no qual estão impressos a agência e conta (além de outras informações do recebedor) que será pago por uma pessoa física ou jurídica pela prestação de um serviço ou compra de um produto.

  * [**Transferência entre contas**](https://docs.mundipagg.com/docs/transferência-entre-contas)
A transferência eletrônica é um pagamento utilizado para transações virtuais. Consiste em uma transferência direta da conta do pagador para a do recebedor. 

  * [**SafetyPay**](https://docs.mundipagg.com/docs/safetypay)
A SafetyPay é uma solução de integração única, que possibilita realizar transferência entre contas com diversos bancos. Além disso, ela também possibilita que o consumidor realize um depósito identificado na lotérica.

  * [**Voucher**](https://docs.mundipagg.com/v1/docs/voucher)
Voucher são cartões de benefícios geralmente disponibilizados por empresas.

  * [**Checkout**](https://docs.mundipagg.com/v1/docs/checkout)
O meio de pagamento checkout é a possibilidade de geração de uma URL que pode ser encaminhada ao cliente para a efetivação do pagamento.