---
title: "Objeto pagamento."
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`payment_method`",
    "0-1": "**string**",
    "0-2": "Meio de pagamento. Valores possíveis: **credit_card**, **boleto**, **voucher**, **bank_transfer**, **safety_pay** ou **checkout**.",
    "1-2": "Dados sobre o pagamento com cartão de crédito (obrigatório caso o **payment_method** seja **credit_card**). [Saiba mais sobre pagamentos com cartão de crédito](ref:cartão-de-crédito-1).",
    "2-2": "Dados sobre o pagamento com voucher (obrigatório caso o **payment_method** seja **voucher**). [Saiba mais sobre pagamentos com voucher](ref:voucher-1).",
    "3-2": "Dados sobre o pagamento com boleto (obrigatório caso o **payment_method** seja **boleto**). [Saiba mais sobre pagamentos com boleto](ref:meio-de-pagamento-boleto).",
    "4-2": "Dados sobre o pagamento com transferência entre contas bancárias. (obrigatório caso o  **payment_method** seja **bank_transfer**). [Saiba mais sobre pagamentos com transferência entre contas](ref:meio-de-pagamento-transferência-entre-contas).",
    "1-1": "**object**",
    "2-1": "**object**",
    "3-1": "**object**",
    "4-1": "**object**",
    "1-0": "`credit_card`",
    "2-0": "`voucher`",
    "3-0": "`boleto`",
    "4-0": "`bank_transfer`",
    "7-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o pagamento. [Saiba mais sobre metadata](ref:metadata)",
    "7-0": "`metadata`",
    "7-1": "**object**",
    "5-0": "`checkout`",
    "5-1": "**object**",
    "5-2": "Dados sobre o pagamento com checkout. (obrigatório caso o **payment_method** seja **checkout**). [Saiba mais sobre pagamentos com meio de pagamento checkout](ref:meio-de-pagamento-checkout).",
    "6-0": "`amount`",
    "6-1": "**integer**",
    "6-2": "Valor da cobrança em centavos",
    "8-0": "`gateway_affiliation_id`",
    "8-1": "**string**",
    "8-2": "Código da afiliação no gateway"
  },
  "cols": 3,
  "rows": 9
}
[/block]