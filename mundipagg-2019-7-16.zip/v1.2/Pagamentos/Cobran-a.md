---
title: "Cobrança"
excerpt: ""
---
A **cobrança **é a forma mais básica de criar um pagamento.

Para realizar uma cobrança avulsa (`charge`) são obrigatórios os dados abaixo: 

- `Amount` (Valor da cobrança em centavos);
- `Customer` (Dados do comprador);
- `Payment` (Método de pagamento: meio de pagamento e dados de pagamento).
[block:callout]
{
  "type": "warning",
  "body": "Vale ressaltar que, ao optar por utilizar a cobrança avulsa, não será possível utilizar nenhum serviço de antifraude, pois ela não possui todos os dados necessários para análise.",
  "title": "Atenção!"
}
[/block]
A cobrança é sempre a base de um pagamento. Desta forma, além de poder ser criada da forma avulsa ela também é gerada através de pedidos e assinaturas.

## [**1. Cobranças relacionadas a um pedido**]()
Neste caso, quando um pedido é gerado, automaticamente uma ou mais cobranças são geradas a partir dele. 

**Exemplo:** 
Quando criado um pedido com um item no valor de R$500,00, será criada uma cobrança de R$500,00 referente a este [pedido](https://docs.mundipagg.com/docs/pedido).

No caso de [multimeios](https://docs.mundipagg.com/docs/multimeios), poderiam ser criadas duas cobranças de R$250,00 referentes ao pedido, uma para cada cartão.

##[**2. Cobranças relacionadas a uma assinatura**]()
Neste caso, ao final de cada ciclo de uma assinatura, é gerada uma cobrança para o assinante.

**Exemplo:**
Ao final do ciclo da [assinatura ](https://docs.mundipagg.com/docs/assinatura)de uma operadora de celular, é gerada uma fatura contendo as informações de consumo do cliente (200 minutos e 3GB da franquia de internet) no valor de R$200,00. A partir dessa fatura, é gerada uma cobrança no valor de R$200,00.

##[**Funcionalidades relacionadas à cobrança**]()
[block:parameters]
{
  "data": {
    "h-0": "",
    "1-0": "**2)** [Pré-autorizar](https://docs.mundipagg.com/v1/reference#pagamentos)",
    "3-0": "**3)** [Cancelar](https://docs.mundipagg.com/reference#cancelar-cobranca)",
    "4-0": "**4)** [Retentar automaticamente](https://docs.mundipagg.com/docs/retentativa-autom%C3%A1tica)",
    "5-0": "**5)** [Retentar offline](https://docs.mundipagg.com/docs/retentativa-offline)",
    "h-1": "",
    "0-0": "**1)** [Alterar o cartão de crédito ou meio de pagamento de uma cobrança não autorizada](https://docs.mundipagg.com/reference#editar-método-de-pagamento)",
    "2-0": "**3)** [Capturar](https://docs.mundipagg.com/reference#capturar-cobrança)"
  },
  "cols": 1,
  "rows": 6
}
[/block]
Saiba mais sobre cobranças através de nossa [API Reference](https://docs.mundipagg.com/reference#objeto-cobrança)!