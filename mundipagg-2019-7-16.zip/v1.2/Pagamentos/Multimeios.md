---
title: "Multimeios"
excerpt: ""
---
Com **multimeios **é possível que seus clientes realizem pagamentos com N cartões de crédito ou combinando mais de um meio, como cartão de crédito e boleto.

Desenvolvemos essa funcionalidade, pois muitos consumidores não conseguem concluir a compras online por possuir o limite do cartão de crédito menor que o valor do pedido.
Comprando com mais de um cartão ou com cartão e boleto o cliente consegue dividir o valor da compra de forma que o limite não seja ultrapassado.

Para realizar um pedido (`order`) com multimeios de pagamento você deve enviar pelo menos os seguintes  campos:

`Itens` (Itens do pedido);
`Customer` (Dados do comprador);
`Payments` (Meios de pagamento).


**Exemplo:**
Ana quer comprar uma nova TV no valor de R$1000,00, mas como seu cartão só possui um limite de R$900,00, ela pode solicitar a geração de um boleto para conseguir pagar os R$100,00 restantes.
[block:callout]
{
  "type": "warning",
  "body": "Vale ressaltar, que o pedido só será considerado pago se todas as transações forem aprovadas nas adquirentes, ou após a aprovação na adquirente e a identificação do pagamento do boleto. \n\nCaso uma transação não seja aprovada, você deve decidir como prefere seguir: cancelar o pedido completo ou fazer uma recuperação ativa do pedido, entrando em contato com o cliente para obter uma nova forma de pagamento, ou utilizando a funcionalidade de envio de [checkout por email](https://docs.mundipagg.com/docs/checkout-por-e-mail).",
  "title": "Atenção"
}
[/block]
Saiba mais sobre pedidos com multimeios através de nossa [API Reference](https://docs.mundipagg.com/reference#criar-pedido-multimeios)!