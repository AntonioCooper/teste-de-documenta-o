---
title: "Objeto endereço (checkout)"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`city`",
    "0-1": "**string**",
    "0-2": "Cidade",
    "1-0": "`complement`",
    "1-1": "**string**",
    "1-2": "Complemento",
    "2-0": "`country`",
    "2-1": "**string**",
    "2-2": "País",
    "3-0": "`neighborhood`",
    "3-1": "**string**",
    "3-2": "Bairro",
    "4-0": "`number`",
    "4-1": "**string**",
    "4-2": "Número",
    "5-0": "`state`",
    "5-1": "**string**",
    "5-2": "Estado",
    "6-0": "`street`",
    "6-1": "**string**",
    "6-2": "Logradouro",
    "7-0": "`zip_code`",
    "7-1": "**string**",
    "7-2": "CEP"
  },
  "cols": 3,
  "rows": 8
}
[/block]