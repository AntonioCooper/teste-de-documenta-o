---
title: "Objeto itens (checkout)"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`description`",
    "0-1": "**string**",
    "0-2": "Descrição do item",
    "1-0": "`amount`",
    "1-1": "**int**",
    "1-2": "Valor do item",
    "2-0": "`quantity`",
    "2-1": "**int**",
    "2-2": "Quantidade do item"
  },
  "cols": 3,
  "rows": 3
}
[/block]