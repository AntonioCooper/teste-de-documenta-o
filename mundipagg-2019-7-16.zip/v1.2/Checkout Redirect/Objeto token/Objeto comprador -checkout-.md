---
title: "Objeto comprador (checkout)"
excerpt: ""
---
Caso seja informado os dados do comprador no momento da criação do Token do checkout, iremos preencher automaticamente os campos referentes a ele na interface do checkout.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "0-1": "**string**",
    "0-2": "Código do comprador. Este campo só é preenchido caso o código do comprador tenha sido informado no momento da criação do token.",
    "1-0": "`document`",
    "1-1": "**string**",
    "1-2": "Número do documento do comprador.",
    "2-0": "`email`",
    "2-1": "**string**",
    "2-2": "Email do comprador",
    "3-0": "`name`",
    "3-1": "**string**",
    "3-2": "Nome do comprador",
    "4-0": "`type`",
    "4-1": "**string**",
    "4-2": "Tipo do comprador. Valores possíveis: **individual** ou **company**",
    "5-0": "`phones`",
    "5-1": "**object**",
    "5-2": "Telefones. Saiba mais sobre [Telefones](ref:objeto-telefones)"
  },
  "cols": 3,
  "rows": 7
}
[/block]