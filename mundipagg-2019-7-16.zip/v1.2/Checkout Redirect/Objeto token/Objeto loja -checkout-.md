---
title: "Objeto loja (checkout)"
excerpt: ""
---
O objeto `account` contém algumas informações que serão usadas para configurações visuais e informações da loja que serão apresentadas na interface do checkout.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`theme`",
    "0-1": "**string**",
    "0-2": "Tema do checkout",
    "1-0": "`color`",
    "1-1": "**string**",
    "1-2": "Cor do checkout",
    "2-0": "`email`",
    "2-1": "**string**",
    "2-2": "Email da loja",
    "3-0": "`logo`",
    "3-1": "**string**",
    "3-2": "Url da logotipo da loja",
    "4-0": "`website`",
    "4-1": "**string**",
    "4-2": "Url do site da loja",
    "5-0": "`name`",
    "5-1": "**string**",
    "5-2": "Nome da loja",
    "6-0": "`public_key`",
    "6-1": "**string**",
    "6-2": "Chave pública da loja"
  },
  "cols": 3,
  "rows": 7
}
[/block]