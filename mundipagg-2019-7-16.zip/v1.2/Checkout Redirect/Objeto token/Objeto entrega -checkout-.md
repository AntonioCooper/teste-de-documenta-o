---
title: "Objeto entrega (checkout)"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`address`",
    "0-1": "**object**",
    "0-2": "Endereço de entrega",
    "1-0": "`recipient_name`",
    "1-1": "**string**",
    "1-2": "Nome de quem receberá a entrega.",
    "2-0": "`recipient_phone`",
    "2-1": "**string**",
    "2-2": "Telefone de quem receberá a entrega",
    "3-0": "`description`",
    "3-1": "**string**",
    "3-2": "Descrição da entrega. Ex: Express Shipping.",
    "4-0": "`amount`",
    "4-1": "**int**",
    "4-2": "Valor da entrega"
  },
  "cols": 3,
  "rows": 5
}
[/block]