---
title: "Objeto configurações de pagamento (checkout)"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "0-0": "`accepted_payment_methods`",
    "1-0": "`default_payment_method`",
    "0-1": "**array of strings**",
    "1-1": "**string**",
    "3-0": "`boleto`",
    "3-1": "**object**",
    "1-2": "Meio de pagamento que virá selecionado por padrão na interface do checkout.",
    "0-2": "Meios de pagamentos aceitos no checkout. Valores possíveis: **credit_card** e **boleto**.",
    "4-0": "`boleto.due_at`",
    "3-2": "Configurações para pagamento com boleto.",
    "4-2": "Data de vencimento do boleto. Obrigatório se o boleto for um meio de pagamento aceito.",
    "4-1": "**datetime**",
    "5-0": "`boleto.instructions`",
    "5-1": "**string**",
    "5-2": "Instruções do boleto",
    "6-0": "`gateway_affiliation_id`",
    "6-1": "**string**",
    "6-2": "Código de afiliação no gateway.",
    "7-0": "`credit_card`",
    "7-1": "**object**",
    "7-2": "Configurações para pagamento com cartão de crédito.",
    "8-0": "`credit_card.installments`",
    "8-1": "",
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "2-0": "`accepted_multi_payment_methods`",
    "2-1": "**array of arrays**",
    "2-2": "Combinação de meios de pagamento aceitos pelo checkout para processar pagamentos multimeios.\n**(Apenas Cartão + Cartão ou Cartão + Boleto)**"
  },
  "cols": 3,
  "rows": 9
}
[/block]

[block:api-header]
{
  "title": "Objeto configurações de pagamento de boleto"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`due_at`",
    "0-1": "**datetime**",
    "0-2": "Data de vencimento do boleto",
    "1-0": "`instructions`",
    "1-1": "**string**",
    "1-2": "Instruções do boleto"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:api-header]
{
  "title": "Objeto configurações de pagamento de cartão de crédito"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`statement_descriptor`",
    "0-1": "**string**",
    "0-2": "Texto exibido na fatura do cartão.",
    "1-0": "`installments`",
    "1-1": "**array of objects**",
    "1-2": "Opções de parcelamento disponíveis",
    "2-0": "`capture`",
    "2-1": "**boolean**",
    "2-2": "\t\nIndica se o pagamento deve ser processado imediatamente. Caso seja **false **o pagamento deverá ser confirmado posteriormente. O padrão é **true**."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:api-header]
{
  "title": "Objeto parcelas"
}
[/block]
O objeto de parcelas permite que você escolha em até quantas vezes o pagamento poderá ser parcelado. Além disso, permite também que você sobrescreva o valor total que será pago caso aquele número de parcelas seja escolhido pelo comprador no checkout. Isso pode ser usado caso você queira aplicar descontos ou juros em cima do número de parcelas escolhidas.
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`number`",
    "0-1": "**int**",
    "0-2": "Número de parcelas",
    "1-0": "`total`",
    "1-1": "**int**",
    "1-2": "Valor total do token caso este número de parcelas seja escolhido pelo comprador no checkout."
  },
  "cols": 3,
  "rows": 2
}
[/block]