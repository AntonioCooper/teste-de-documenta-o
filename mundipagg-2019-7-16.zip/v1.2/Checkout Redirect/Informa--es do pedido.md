---
title: "Informações do pedido"
excerpt: ""
---
Dados do objeto `order` para a criação do checkout redirect de pedidos.
[block:parameters]
{
  "data": {
    "0-0": "itens",
    "0-1": "**array of object**",
    "0-2": "Lista de itens do pedido. [Saiba mais sobre itens do pedido](ref:objeto-item-do-pedido)",
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição"
  },
  "cols": 3,
  "rows": 1
}
[/block]