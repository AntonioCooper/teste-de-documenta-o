---
title: "Visão geral"
excerpt: ""
---
Com o **checkout redirect**, oferecemos uma página de checkout desenvolvida por nós e hospedada em nossos servidores. Desta forma, você não precisa se preocupar em desenvolver essa interface.

Existe, hoje, um tipo de checkout redirect: `order`.