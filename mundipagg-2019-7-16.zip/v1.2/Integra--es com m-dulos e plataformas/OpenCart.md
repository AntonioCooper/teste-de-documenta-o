---
title: "OpenCart"
excerpt: ""
---
[block:callout]
{
  "type": "info",
  "body": "Tipo de integração: **API Mundi**\n\nVersões compatíveis: a partir do **Opencart 3.0.**\n\nVersão atual do módulo: **8**",
  "title": "Importante"
}
[/block]

[block:api-header]
{
  "type": "basic",
  "title": "Visão Geral"
}
[/block]
O OpenCart é uma plataforma de e-commerce que atua no modelo freemium. Ou seja, um cliente consegue utilizar a solução deles com diversas extensões nativas sem custo algum.
[block:api-header]
{
  "title": "Funcionalidades"
}
[/block]
**Cartão de Crédito:**
  *  Pré-Autorização
  *  Autorizar e Capturar
  *  Captura com Dalay
  *  Parcelamento único/por bandeira
  *  Configurações de parcelamento por bandeira
  *  Retentativa Multiadquirente
  *  Retentativa Offline
  *  Instant Buy

**Webhooks**

**Boleto:**
  *  Boleto com registro
  *  Direcionar banco
  *  Instruções do boleto
  *  Vencimento do Boleto
  *  Conciliação

**Multimeios:**
  *  Cartão de Crédito + Cartão
  *  Cartão de Crédito + Boleto
  *  Wallet

**Captura pelo OpenCart:**
  *  Cancelamento  total/parcial
  *  Captura posterior total/parcial

**Antifraude:**
  *  Valor mínimo

**Checkout:**
  *  Transparente
[block:api-header]
{
  "title": "Integração"
}
[/block]
**Download do módulo [neste link](https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=31636&filter_search=mundipagg&filter_category_id=3).**

Caso você já seja nosso cliente, você deve entrar em contato por: **integração@mundipagg.com**

Se você não for nosso cliente, você deve mandar e-mail para: **suporte@mundipagg.com**

Nosso time de Ativação irá te responder e vai te passar as chaves necessárias para que você possa configurar sua loja. Abaixo listamos o passo a passo para configuração.

**Obs.:** para entrar em contato para assinar seu contrato e entrar produção o contato é: **contato@mundipagg.com**
[block:api-header]
{
  "title": "Configurações"
}
[/block]
1 - Para configurar o módulo Opencart, o lojista precisa acessar o ambiente do módulo e a área **Extensions > MundiPagg** e habilitar o módulo. Nesta página deverão ser preenchidas as chaves da API (api data).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/db9b7cf-o1.png",
        "o1.png",
        1900,
        951,
        "#e6e7e8"
      ]
    }
  ]
}
[/block]
2 - Na aba **CREDIT CARD**, o lojista deve configurar as bandeiras que serão aceitas em sua loja. No exemplo ao lado foram habilitadas Visa e Mastercard.

Nas colunas seguintes deverão se configuradas as regras de parcelamento da seguinte forma:

* 2ª coluna: **número máximo de parcelas**;
* 3ª coluna: **número máximo sem juros**;
* 4ª coluna: **juros a ser cobrado ao mês**;

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/daae95d-o2.png",
        "o2.png",
        1893,
        964,
        "#e6e7e8"
      ]
    }
  ]
}
[/block]
3 - Ainda no ambiente da MundiPagg no módulo OpenCart, na aba **BOLETO**, o lojista deverá habilitar o método de pagamento, se assim desejar. Definir o **Payment title** e o **nome da loja** e inserir as **informações do banco** e **instruções do boleto**. 

[block:callout]
{
  "type": "success",
  "title": "",
  "body": "Não esqueça de salvar as alterações no botão **AZUL** no canto superior direito da tela."
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/871b609-o3.png",
        "o3.png",
        1921,
        896,
        "#e7e8e9"
      ]
    }
  ]
}
[/block]
**O OpenCart não tem qualquer limitação de integração com meios de pagamento.**