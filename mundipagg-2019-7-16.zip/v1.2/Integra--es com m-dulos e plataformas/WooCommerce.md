---
title: "WooCommerce"
excerpt: ""
---
[block:callout]
{
  "type": "info",
  "body": "Tipo de integração: **API Mundi**\n\nVersões compatíveis: a partir do **WooCommerce 2.6** e **Wordpress 4.5**\n\nVersão atual do módulo: **1.0.9**\n\n**Requisito:**\n\nDependência do módulo https://wordpress.org/support/plugin/woocommerce-extra-checkout-fields-for-brazil/\n\nÉ necessário que o lojista também tenha este plugin instalado em seu e-commerce",
  "title": "Importante"
}
[/block]

[block:api-header]
{
  "title": "Visão Geral"
}
[/block]
WooCommerce é um plugin gratuito para e-commerce do WordPress que permite ao lojista vender qualquer coisa nessa plataforma que já possui 59% do mercado mundial de gerenciadores de conteúdo para Web.

Módulo de integração da MundiPagg com o WooCommerce: aceite pagamentos de cartão de crédito, boleto, multimeios e aumente a sua conversão. Sendo o módulo da MundiPagg responsável pela integração entre MundiPagg e WooCommerce
[block:api-header]
{
  "title": "Funcionalidades"
}
[/block]
**Cartão de Crédito:**
  *  Pré-Autorização
  *  Autorizar e Capturar
  *  Captura com Dalay
  *  Parcelamento único/por bandeira
  *  Configurações de parcelamento por bandeira
  *  Retentativa Multiadquirente
  *  Retentativa Offline
  *  Instant Buy

**Webhooks**

**Boleto:**
  *  Boleto com registro
  *  Direcionar banco
  *  Instruções do boleto
  *  Vencimento do Boleto
  *  Conciliação

**Multimeios:**
  *  Cartão de Crédito + Cartão
  *  Cartão de Crédito + Boleto
  *  Wallet

**Captura pelo WooCommerce:**
  *  Cancelamento  total/parcial
  *  Captura posterior total/parcial

**Antifraude:**
  *  Valor mínimo

**Checkout:**
  *  Transparente


[block:api-header]
{
  "title": "Integração"
}
[/block]
**O download do módulo da MundiPagg deve ser feito [neste link](https://br.wordpress.org/plugins/woo-mundipagg-payments/)**

Caso você já seja nosso cliente, você deve entrar em contato por: **integração@mundipagg.com**

Se você não for nosso cliente, você deve mandar e-mail para: **suporte@mundipagg.com**

Nosso time de Ativação irá te responder e vai te passar as chaves necessárias para que você possa configurar sua loja. Abaixo listamos o passo a passo para configuração.

**Obs.:** para entrar em contato para assinar seu contrato e entrar produção o contato é: **contato@mundipagg.com**
[block:api-header]
{
  "title": "Configurações"
}
[/block]
1 - Para configurar este módulo da MundiPagg, o lojista precisa acessar o seu **painel admin** do Wordpress e selecionar a área **WooCommerce**. A tela abaixo é a tela encontrada pelo usuário ao entrar no painel administrativo do Wordpress:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a0b67da-w1.PNG",
        "w1.PNG",
        1349,
        642,
        "#d4d7d8"
      ]
    }
  ]
}
[/block]
2 - Dentro dessa seção, deve ser selecionada a opção **WooCommerce** e após isso **Configurações**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/36d0d0f-print_woocommerce.png",
        "print woocommerce.png",
        1858,
        962,
        "#dadadb"
      ]
    }
  ]
}
[/block]
3 - Na aba **Finalizar compra > MundiPagg Pagamentos** você poderá configurar as seguintes opções:

*3.1* Habilitar, ou não, a solução de pagamento. 
*3.2* Definir o título e a descrição do meio de pagamento;
*3.3* Habilitar ou desabilitar os ambientes de Produção e Sandbox;
*3.4* Configurar as chaves da API para cada um dos ambientes;
*3.5* Habilitar ou desabilitar os meios de pagamento aceitos (cartão de crédito e/ou boleto);
*3.6* Ativar ou desativar as opções Multimeios e Multicompradores;
*3.7* Habilitar o antifraude e definir valor mínimo das transações que deverão ser analisadas;
*3.8* Definir as configurações de boleto (banco, dias até a expiração, instruções para o caixa);
*3.9* Definir as configurações de crédito (softdescriptor, tipo de operação, bandeiras aceitas, parcelamento único ou por bandeiras).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6eb9976-w8.png",
        "w8.png",
        2007,
        2139,
        "#ddddde"
      ]
    }
  ]
}
[/block]