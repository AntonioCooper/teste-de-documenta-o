---
title: "Magento 2.0"
excerpt: ""
---
[block:callout]
{
  "type": "info",
  "body": "Tipo de integração: **API Mundi**\n\nVersões compatíveis: a partir do **Magento 2.1**\n\nVersão atual do módulo: **2.14**\n\n**Requisitos:**\n\nPHP >= 5.6\nMagento >= 2.1\n\n**Dependências:**\n* MundiPagg/MundiAPI >= 1.0",
  "title": "Importante"
}
[/block]

[block:api-header]
{
  "title": "Visão Geral"
}
[/block]
O Magento é uma plataforma de e-commerce open source (de código aberto), desenvolvida na linguagem PHP e distribuída livremente no site da empresa e na comunidade de desenvolvedores que trabalha para aprimorar e acrescentar novos recursos ao sistema.

Por ser uma aplicação com código aberto, qualquer pessoa que possuir algum conhecimento de programação pode criar customizações e desenvolver novas funcionalidades para o sistema. Dessa forma, não existem limites para a personalização da plataforma, o que contribui para a sua aceitação no mercado, já que pode atender a qualquer demanda específica de cada cliente.
[block:api-header]
{
  "title": "Funcionalidades"
}
[/block]
**Cartão de Crédito:**
  *  Pré-Autorização
  *  Autorizar e Capturar
  *  Captura com Dalay
  *  Parcelamento único/por bandeira
  *  Configurações de parcelamento por bandeira
  *  Retentativa Multiadquirente
  *  Retentativa Offline
  *  Instant Buy

**Webhooks**

**Boleto:**
  *  Boleto com registro
  *  Direcionar banco
  *  Instruções do boleto
  *  Vencimento do Boleto
  *  Conciliação

**Multimeios:**
  *  Cartão de Crédito + Cartão
  *  Cartão de Crédito + Boleto
  *  Wallet

**Captura pelo WooCommerce:**
  *  Cancelamento  total/parcial
  *  Captura posterior total/parcial

**Antifraude:**
  *  Valor mínimo

**Checkout:**
  *  Transparente
[block:api-header]
{
  "title": "Integração"
}
[/block]
**O cliente deve fazer download do Módulo Magento 2.0  no Magento Marketplace [neste link](https://marketplace.magento.com/).**

Caso você já seja nosso cliente, você deve entrar em contato por: **integração@mundipagg.com**

Se você não for nosso cliente, você deve mandar e-mail para: **suporte@mundipagg.com**

Nosso time de Ativação irá te responder e vai te passar as chaves necessárias para que você possa configurar sua loja. Abaixo listamos o passo a passo para configuração.

**Obs.:** para entrar em contato para assinar seu contrato e entrar produção o contato é: **contato@mundipagg.com**
[block:api-header]
{
  "title": "Configurações"
}
[/block]
1 - Para configurar este módulo da MundiPagg, o lojista precisa acessar o seu painel admin do Magento 2 e selecionar a seção **Stores**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/36cd6a0-m1.PNG",
        "m1.PNG",
        1916,
        828,
        "#f2f1ec"
      ]
    }
  ]
}
[/block]
2 - Dentro da aba **Stores**, deve-se selecionar a **Configuration** que está na subcategoria **Settings**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7a5467c-m2.PNG",
        "m2.PNG",
        1912,
        856,
        "#c1bfbb"
      ]
    }
  ]
}
[/block]
3 - Em seguida, clicar em **Sales > Payment Methods**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/57a4f72-m3.PNG",
        "m3.PNG",
        1901,
        969,
        "#f5f5f2"
      ]
    }
  ]
}
[/block]
4 - Ao dar scroll para baixo, encontra-se **Other Payment Methods → Webjump MundiPagg**, onde é possível configurar o módulo.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9e7eba2-m5.PNG",
        "m5.PNG",
        1892,
        937,
        "#f3f3f0"
      ]
    }
  ]
}
[/block]
5 - Na área de **Configurações globais** é possível configurar as chaves Secret e Public da API para os ambientes de Produção e Sandbox. Para configurar as chaves no ambiente de produção deve-se selecionar **NÃO** no modo Sandbox e inserir as chaves.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d4703ad-m8.PNG",
        "m8.PNG",
        1901,
        955,
        "#f4f3f3"
      ]
    }
  ]
}
[/block]
6 - Nas **Configurações do Cliente** é possível personalizar os campos de endereço no checkout.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6479e78-m9.PNG",
        "m9.PNG",
        1900,
        809,
        "#f4f4f3"
      ]
    }
  ]
}
[/block]
7 - Em **Transação MundiPagg** devem ser configuradas as customizações de Crédito, Boleto, Antifraude e Multimeios.

Obs.: Se atentar aos campos que fazem parte de outra categoria de pagamento, como Bank Transfer Payment, que aparece nas configurações, mas como nosso módulo ainda não aceita transferência entre contas, não faz parte das nossas configurações.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/301d10f-m12_1.PNG",
        "m12 (1).PNG",
        1897,
        947,
        "#f6f6f5"
      ]
    }
  ]
}
[/block]
8 - Na área **Cartão de Crédito** é possível habilitar, ou não, as bandeiras aceitas na loja, opções de parcelamento simples ou regras de parcelamento por bandeiras, número máximo e mínimo de parcelas e juros.
Também é possível definir o tipo de documento exigido no checkout, o modo da operação, o estado de um novo pedido e a rejeição ou revisão do status do pedido, além da ordem de classificação.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0fa379a-m11.PNG",
        "m11.PNG",
        1902,
        953,
        "#f3f3f2"
      ]
    }
  ]
}
[/block]
9 - Caso a opção de parcelamento por bandeira seja habilitada, uma árvore de customização é aberta para cada bandeira aceita.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6b3e92e-m12_1.PNG",
        "m12 (1).PNG",
        1897,
        947,
        "#f6f6f5"
      ]
    }
  ]
}
[/block]
10 - Caso o antifraude esteja habilitado, é possível definir um critério de valor mínimo.
Para boletos, pode-se habilitar, escolher título, texto no checkout, banco, dias para expiração, estado de um pedido novo e ordem de classificação.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c5f9661-m13.PNG",
        "m13.PNG",
        1903,
        971,
        "#f6f5f5"
      ]
    }
  ]
}
[/block]
Para ambos os casos é possível habilitar ou não, e ainda definir o título, status de um novo pedido, os critérios de rejeição e revisão de um pedido e a ordem de classificação.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3f97349-m14.PNG",
        "m14.PNG",
        1899,
        736,
        "#f5f5f4"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "danger",
  "body": "* Não é recomendado o envio do arquivo zip para instalação do módulo. O modo correto de instalação é por download no marketplace."
}
[/block]