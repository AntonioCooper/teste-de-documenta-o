---
title: "Shopify"
excerpt: ""
---
[block:api-header]
{
  "type": "basic",
  "title": "Visão geral"
}
[/block]
O Shopify é uma plataforma de e-commerce na nuvem, ou seja, não demanda criação de ambientes ou qualquer infraestrutura para ele.

O principal diferencial do plugin da MundiPagg na Shopify é a facilidade de integração. O processo é o mais rápido e simples possível, além de ter sido pensado para agilizar sua operação.

Com a Mundi, é possível utilizar várias adquirentes e bandeiras, aumentando sua chance de conversão. Além disso, você ainda pode fazer configurações de parcelamento e juros. 

A solução utiliza o produto Checkout Personalizado da MundiPagg. Ele é uma página de finalização de compra customizável para a sua conversão, podendo ter a identidade da sua marca, com a logo e as cores do seu site.
[block:api-header]
{
  "title": "Funcionalidades"
}
[/block]
**Cartão de Crédito:**
  *  Pré-Autorização
  *  Autorizar e Capturar
  *  Retentativa Multiadquirente

**Webhooks**

**Boleto:**
  *  Boleto com registro
  *  Vencimento do Boleto
  *  Conciliação

**Carteira de Clientes:**
  *  Carteira de clientes

**Captura pela Shopify:**
  *  Cancelamento pela Shopify
  *  Captura posterior pela Shopify

**Antifraude**

**Checkout:**
  *  Redirect
[block:callout]
{
  "type": "danger",
  "title": "Atenção!",
  "body": "**Obs.: O lojista que optar por realizar operações auth_only e a captura posterior, somente poderá realizar esta operação pelo módulo do Shopify. Não é possível realizar a captura na MundiPagg.**"
}
[/block]

[block:api-header]
{
  "title": "Integração"
}
[/block]
Caso você já seja nosso cliente, você deve entrar em contato por: **integração@mundipagg.com**

Se você não for nosso cliente, você deve mandar e-mail para: **suporte@mundipagg.com**

Nosso time de Ativação irá te responder e te passar as chaves necessárias para que você possa configurar sua loja. Abaixo listamos o passo a passo para configuração.

**Obs.:** para entrar em contato para assinar seu contrato e entrar produção o contato é: **contato@mundipagg.com**


[block:api-header]
{
  "title": "Configurações"
}
[/block]
1 - A configuração do módulo Shopify é bem simples, o lojista deve acessar a plataforma por [este link](https://www.shopify.com/login?redirect=%2Fadmin%2Fauthorize_gateway%2F1052225).

2. O time de ativação da Mundi vai te passar as chaves, e será necessário inseri-las na Shopify. Para isso, é só acessar o seu painel admin e utilizar o menu **Settings > Payments providers**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aafb4a6-shopify_1.png",
        "shopify 1.png",
        1368,
        646,
        "#e3e5ec"
      ]
    }
  ]
}
[/block]
3. Em seguida, devem ser inseridos no **MundiPagg Payments > Edit** a *Account ID* e o *Access Token*. Além disso, deverá ainda selecionar as bandeiras aceitas na loja e, caso deseje utilizar, o método de pagamento boleto.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3eabfc2-print_shopify.png",
        "print shopify.png",
        1352,
        692,
        "#e4e6ec"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Importante",
  "body": "A plataforma não permite que seja configurado mais de um meio de pagamento tradicional, ou seja, não é possível utlizar mais de um Gateway. A exceção dessa limitação é o Paypal que como parceiro Shopify pode ser configurado em paralelo a outros meios."
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/89f2832-s3.PNG",
        "s3.PNG",
        1348,
        659,
        "#e4e6ec"
      ]
    }
  ]
}
[/block]
Para ajustar os campos da plataforma canadense à lógica brasileira, é necessário definir que o campo *Address Line 2* (complemento) é obrigatório. Em **Settings > Checkout > Form Options > Address Line 2**.

Caso o lojista opte por utilizar a pré-autorização (**authonly**), ele deverá configurar a captura manual no módulo. Para isso, deverá acessar **Settings > Payments > Payments Authorization** e selecionar a opção **Manually capture payment for orders**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3dae63b-C__Users_enetto_AppData_Local_Packages_Microsoft.SkypeApp_kzf8qxf38zg5c_LocalState_0ca4bcca-2de0-45f9-b11e-39622b14c9fa.PNG",
        "C__Users_enetto_AppData_Local_Packages_Microsoft.SkypeApp_kzf8qxf38zg5c_LocalState_0ca4bcca-2de0-45f9-b11e-39622b14c9fa.PNG",
        1899,
        968,
        "#ebecf1"
      ]
    }
  ]
}
[/block]
Na aba seção *Customer Contact* é necessário configurar o *Primary Contact Method* como *Customers can only checkout using e-mail*. Para realizar essa configuração, deve-se acessar **Settings > Checkout > Customer Contact**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aa8b914-image2017-12-14_10-24-22.png",
        "image2017-12-14_10-24-22.png",
        1347,
        648,
        "#e4e6ec"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Opcional:",
  "body": "Paro o e-commerce ter acesso ao CPF do comprador, é necessário configurar o campo *Company Name* como obrigatório e alterá-lo para \"CPF\". \n\nA localização da tela é **Settings > Checkout > Form Options > Company Name**."
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0480fd8-1.JPG",
        "1.JPG",
        1346,
        659,
        "#e5e5ec"
      ]
    }
  ]
}
[/block]