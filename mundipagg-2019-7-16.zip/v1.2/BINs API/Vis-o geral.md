---
title: "Visão geral"
excerpt: ""
---
Os seis primeiros dígitos de um número de cartão (incluindo o dígito **MII** inicial) são conhecidos como o **número de identificação do emissor** (**IIN**) ou **número de identificação do banco** (**BIN**). 

Estes números identificam a instituição que emitiu o cartão ao titular do cartão. O restante do número é alocado pelo emissor.