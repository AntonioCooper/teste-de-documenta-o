---
title: "Obter informações do BIN"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Definição",
    "0-0": "brand",
    "0-1": "string",
    "0-2": "Nome oficial da bandeira",
    "1-0": "brandName",
    "1-1": "string",
    "1-2": "Nome da bandeira para exibição",
    "2-0": "gaps",
    "2-1": "array",
    "2-2": "Posição dos espaços na máscara do cartão",
    "3-0": "lengths",
    "3-1": "array",
    "3-2": "Possíveis tamanhos do número do cartão",
    "4-0": "mask",
    "4-1": "string",
    "4-2": "RegEx para validação do número do cartão",
    "5-0": "input",
    "5-1": "string",
    "5-2": "RegEx para criação de máscara do número do cartão",
    "6-0": "cvv",
    "6-1": "integer",
    "6-2": "Tamanho do código de segurança"
  },
  "cols": 3,
  "rows": 7
}
[/block]