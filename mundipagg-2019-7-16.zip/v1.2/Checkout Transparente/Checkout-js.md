---
title: "Checkout.js"
excerpt: ""
---
Um script da MundiPagg captura os dados de cartão inseridos em seu formulário de checkout e envia diretamente para o nosso sistema, que retorna um token para a página da loja. O token poderá ser usado no lugar dos dados de cartão para fazer a venda, evitando que você precise trafegar os dados de cartão pelo seu servidor.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0277199-fluxograma-checkout-transparente.jpg",
        "fluxograma-checkout-transparente.jpg",
        1000,
        1069,
        "#fbf3fb"
      ]
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "Integração"
}
[/block]
**Passo 1:**
    Na tag <form> insira o atributo "data-mundicheckout-form" para que o script consiga identificar o formulário do qual serão extraídos os dados e esperar a submissão dele.

   Quando o formulário for submetido, o script vai gerar o token e retorná-lo de duas maneiras:

   1) Através do atributo "munditoken" no POST realizado.

   2) Inserindo um novo campo com o atributo "name=munditoken" contendo o token gerado.
[block:code]
{
  "codes": [
    {
      "code": "   <form action=\"{{url de sua action}}\" method=\"POST\" data-mundicheckout-form>\n   </form>",
      "language": "html",
      "name": null
    }
  ]
}
[/block]
**Passo 2:**
    Coloque nos campos <input> do seu formulário os atributos "data-mundicheckout-input" correspondentes a cada um conforme abaixo. Esses campos que serão capturados pelo script e transformados num token na submissão do formulário.

   Note que o campo buyer-name não está marcado com nenhum atributo customizado. Isto significa que este campo será enviado normalmente para o seu servidor, sem a intervenção do script. Quaisquer outros campos desejados podem ser adicionados neste mesmo formulário.

   Não é obrigatório enviar a bandeira do cartão. Se ela não for enviada, o nosso sistema irá detectá-la automaticamente.

   O campo informando a expiração do cartão pode ser informado de duas formas: através de um único campo, marcado como "exp_date" ou em dois campos, "exp_month" e "exp_year".
[block:code]
{
  "codes": [
    {
      "code": "<form action=\"{{url de sua action}}\" method=\"POST\" data-mundicheckout-form>\n\t<input type=\"text\" name=\"holder-name\" data-mundicheckout-input=\"holder_name\">\n\t<input type=\"text\" name=\"card-number\" data-mundicheckout-input=\"number\">\n\t<span data-mundicheckout-brand data-mundicheckout-brand-image></span>\n\t<input type=\"text\" name=\"card-exp-month\" data-mundicheckout-input=\"exp_month\">\n\t<input type=\"text\" name=\"card-exp-year\" data-mundicheckout-input=\"exp_year\">\n\t<input type=\"text\" name=\"cvv\" data-mundicheckout-input=\"cvv\">\n\t<input type=\"text\" name=\"buyer-name\">\n\t<button type=\"submit\">Enviar</button>\n</form>",
      "language": "html"
    }
  ]
}
[/block]
**Passo 3:**
    Deve ser inserido no final da sua página o script do checkout, com o atributo "data-mundicheckout-app-id" contendo sua chave púbilca.
[block:code]
{
  "codes": [
    {
      "code": "<script src=\"https://commerce.mundipagg.com/checkout.js\" data-mundicheckout-app-id=\"{{sua chave pública}}\"></script>",
      "language": "html"
    }
  ]
}
[/block]
**Passo 4:**
    Depois de inserir o script é preciso iniciar a detecção dos campos com a chamada do método "init" do objeto MundiCheckout gerado pelo script.

   Todos os elementos mapeados devem estar no DOM na quando o método "init" for chamado.

   "init" pode receber duas funções de callback, a primeira de sucesso, para execução de qualquer lógica de validação customizada e a segunda de erro. Quando a callback de sucesso é
    chamada ela recebe um JSON com o token gerado e os outros campos não mapeados com "data-mundicheckout", e no caso de falha a callback de erro é chamada recebendo os detalhes.

   (OBS: É importante que todos os campos não marcados possuam o atributo "name", pois eles serão utilizados para definir o JSON)

   Você pode impedir o envio dos dados para o servidor retornando "false" na callback de sucesso.
[block:code]
{
  "codes": [
    {
      "code": "<script>\n\tfunction success(data) {\n\t\treturn true;\n\t};\n\n\tfunction fail(error) {\n\t\tconsole.error(error);\n\t};\n\n\tMundiCheckout.init(success,fail)\n</script>",
      "language": "html"
    }
  ]
}
[/block]