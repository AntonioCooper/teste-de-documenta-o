---
title: "Criar token de cartão"
excerpt: ""
---
[block:callout]
{
  "type": "danger",
  "title": "Atenção!",
  "body": "O método de criação de token deve ser chamado diretamente a partir do seu front-end, para garantir que os dados de cartão abertos não sejam trafegados em seu servidor."
}
[/block]

[block:callout]
{
  "type": "danger",
  "title": "Atenção",
  "body": "A autenticação deste endpoint deverá ser feita **exclusivamente** enviando a `public_key` da account no parâmetro **appId** na query string. A `secret_key` de sua loja **não deverá** ser armazenada na página ou enviada na requisição."
}
[/block]