---
title: "Tokens"
excerpt: ""
---
Se você preferir, pode chamar diretamente a API de criação de Tokens para usar o **checkout transparente**. Os dados de cartão deverão ser enviados para a API da MundiPagg antes de submeter o formulário para o seu servidor. Nós retornaremos um **Token**, que deverá ser utilizado em sua requisição, no lugar dos dados de cartão.
[block:callout]
{
  "type": "danger",
  "title": "Atenção",
  "body": "É importante que você garanta que os dados abertos de cartão (número, cvv, vencimento e nome do titular) não serão enviados para seu servidor."
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "Os tokens de cartão tem tempo de expiração de 60 segundos, e só poderão ser usados uma única vez. Se quiser armazenar de forma permanente o cartão em nosso sistema, [leia mais sobre cartões](https://docs.mundipagg.com/reference#objeto-cartao)."
}
[/block]