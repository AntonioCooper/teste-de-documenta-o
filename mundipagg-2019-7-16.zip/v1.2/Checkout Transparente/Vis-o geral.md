---
title: "Visão geral"
excerpt: ""
---
O **checkout transparente** da MundiPagg é uma solução que permite que você não trafegue informações de cartão de crédito em seu servidor, sem que o cliente tenha que sair do ambiente de sua loja. A página de checkout poderá ser desenvolvida pela sua equipe, da mesma forma que o restante do site, porém os dados de cartão serão enviados diretamente de sua página para a nossa API.

Atualmente, existem duas formas de utilizar as funcionalidades do **checkout transparente**: via API chamando o endpoint **Tokens**, ou utilizando uma solução em javascript puro fornecida por nós **(checkout.js)**.