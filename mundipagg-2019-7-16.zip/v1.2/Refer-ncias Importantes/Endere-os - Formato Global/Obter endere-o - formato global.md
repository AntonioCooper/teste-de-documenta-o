---
title: "Obter endereço - formato global"
excerpt: ""
---
