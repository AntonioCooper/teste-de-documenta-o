---
title: "Listar endereços - formato global"
excerpt: ""
---
