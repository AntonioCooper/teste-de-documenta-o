---
title: "Objeto endereço - formato global"
excerpt: ""
---
[block:parameters]
{
  "data": {
    "0-1": "**string**",
    "1-1": "**string**",
    "2-1": "**string**",
    "3-1": "**integer**",
    "4-1": "**string**",
    "5-1": "**string**",
    "6-1": "**string**",
    "7-1": "**enum**",
    "8-1": "**datetime**",
    "9-1": "**datetime**",
    "10-1": "**datetime**",
    "11-1": "**object**",
    "0-0": "`id`",
    "1-0": "`line_1`",
    "2-0": "`line_2`",
    "3-0": "`zip_code`",
    "4-0": "`city`",
    "5-0": "`state`",
    "6-0": "`country`",
    "7-0": "`status`",
    "8-0": "`created_at`",
    "9-0": "`updated_at`",
    "10-0": "`deleted_at`",
    "11-0": "`customer`",
    "12-0": "`metadata`",
    "12-1": "**object**",
    "0-2": "Código do endereço",
    "1-2": "Linha 1 do endereço (**Número, Rua, Bairro - Nesta ordem e separados por vírgula**)",
    "2-2": "Linha 2 do endereço. (Complemento)",
    "3-2": "CEP",
    "4-2": "Cidade",
    "5-2": "Estado",
    "6-2": "País",
    "7-2": "Os status do endereço. Valores possíveis: **active** ou **deleted**",
    "8-2": "Data de criação do endereço",
    "9-2": "Data de atualização do endereço",
    "10-2": "Data de exclusão do endereço",
    "12-2": "Informações adicionais sobre o endereço. [Saiba mais sobre metadata](ref:metadata)",
    "11-2": "Dados do cliente. [Saiba mais sobre clientes](ref:objeto-cliente)"
  },
  "cols": 3,
  "rows": 13
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Atenção!",
  "body": "É muito importante enviar a string \"line 1\" no formato certo: **Número, Rua, Bairro - Nesta ordem e separados por vírgula**, principalmente para utilização de Antifraude ou Boleto com Registro!"
}
[/block]