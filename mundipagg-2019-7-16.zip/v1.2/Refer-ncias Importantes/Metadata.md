---
title: "Metadata"
excerpt: ""
---
A maioria dos nossos objetos - como [customer](http://docs.mundipagg.com/v3.0/docs/o-comprador), [card](ref:objeto-cartao), [address](http://docs.mundipagg.com/v3.0/docs/o-endere%C3%A7o), [subscription](http://docs.mundipagg.com/v3.0/docs/a-assinatura), [plan](http://docs.mundipagg.com/v3.0/docs/o-plano), [order](http://docs.mundipagg.com/v3.0/docs/o-pedido), [charge](https://docs.mundipagg.com/reference#objeto-cobrança) e [fatura](doc:fatura) - possuem o parâmetro `metadata`, pelo qual você consegue armazenar dados chave-valor .

Metadados são interessantes para o armazenamento estruturado de dados complementares relacionados a algum objeto. Um exemplo seria adição do nome do pai de um cliente para ter essa informação em sua carteira de clientes.
[block:code]
{
  "codes": [
    {
      "code": "{\n  ...\n  \"metadata\": {\n    \"meu_campo1\": \"valor1\",\n    \"meu_campo2\": \"valor2\",\n  }\n}",
      "language": "json"
    }
  ]
}
[/block]