---
title: "Esquemas de Precificação para planos e assinaturas"
excerpt: ""
---
A nova API foi projetada para atender diferentes modelos de recorrência, como academias, escolas, operadoras de telefonia, clubes de assinatura, entre outros. Entretanto, cada um desses mercados tem diferentes tipos de precificações para seus produtos e serviços.
[block:callout]
{
  "type": "danger",
  "title": "Atenção",
  "body": "É importante destacar que esta não é a forma como a MundiPagg cobra seus clientes e sim, os modelos de precificação que você pode aplicar em seus planos e assinaturas para cobrar seus clientes utilizando nossa API."
}
[/block]
Os **Esquemas de Precificação **possíveis para os itens da assinatura estão apresentados utilizando a unidade de medida "minuto" como exemplo:

**UNIT**
1 minuto - Custa R$1,00

Se um cliente utilizar 100 minutos o valor será R$100,00 (100 x R$1,00)

**PACKAGE**
De 0 a 10 minutos - Custa R$50,00
De 11 a 50 minutos - Custa R$70,00
De 51 a 100 minutos - Custa R$100,00
Cada minuto acima da última faixa custa R$0,90

Se um cliente utilizar 25 minutos o valor será R$70,00

**VOLUME**
Se utilizar entre 1~10 minutos - Cada minuto custa R$1,00.
Se utilizar entre 11~20 minutos - Cada minuto custa R$0,90.
Se utilizar entre 21~50 minutos - Cada minuto custa R$0,80.
Cada minuto acima da última faixa custa R$0,70

Se um cliente utilizar 25 minutos o valor total será R$20,00 (25 x R$0,80).

**TIER**
Do 1° ao 10° minuto - Cada minuto custa R$1,00.
Do 11° ao 20° minuto - Cada minuto custa R$0,90.
Do 21° ao 50° minuto - Cada minuto custa R$0,80
Cada minuto acima da última faixa custa R$0,70

Se um cliente utilizar 25 minutos o valor total será R$23,00 (10 x R$1,00 + 10 x R$0,90 + 5 x R$0,80)

[block:code]
{
  "codes": [
    {
      "code": "{\n  \"price\": 100,\n  \"minimum_price\": 20000,\n  \"scheme_type\": \"unit\"\n}",
      "language": "json",
      "name": "unit"
    },
    {
      "code": "{\n  \"scheme_type\": \"package\",\n  \"price_brackets\": [\n    {\n    \t\"start_quantity\": 0,\n      \"end_quantity\": 10,\n      \"price\": 5000\n  \t},\n    {\n    \t\"start_quantity\": 11,\n      \"end_quantity\": 50,\n      \"price\": 7000\n  \t},\n    {\n    \t\"start_quantity\": 51,\n      \"end_quantity\": 100,\n      \"price\": 10000,\n      \"overage_price\": 90\n  \t}\n  ]\n}",
      "language": "json",
      "name": "package"
    },
    {
      "code": "{\n  \"scheme_type\": \"volume\",\n  \"price_brackets\": [\n    {\n    \t\"start_quantity\": 0,\n      \"end_quantity\": 10,\n      \"price\": 100\n  \t},\n    {\n    \t\"start_quantity\": 11,\n      \"end_quantity\": 20,\n      \"price\": 90\n  \t},\n    {\n    \t\"start_quantity\": 21,\n      \"end_quantity\": 50,\n      \"price\": 80,\n      \"overage_price\": 70\n  \t}\n  ]\n}",
      "language": "json",
      "name": "volume"
    },
    {
      "code": "{\n  \"scheme_type\": \"tier\",\n  \"price_brackets\": [\n    {\n    \t\"start_quantity\": 0,\n      \"end_quantity\": 10,\n      \"price\": 100\n  \t},\n    {\n    \t\"start_quantity\": 11,\n      \"end_quantity\": 20,\n      \"price\": 90\n  \t},\n    {\n    \t\"start_quantity\": 21,\n      \"end_quantity\": 50,\n      \"price\": 80,\n      \"overage_price\": 70\n  \t}\n  ]\n}",
      "language": "json",
      "name": "tier"
    }
  ]
}
[/block]