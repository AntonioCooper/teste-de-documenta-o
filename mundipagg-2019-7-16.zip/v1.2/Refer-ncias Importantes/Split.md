---
title: "Split"
excerpt: ""
---
Os pagamentos (`payment`) das cobranças e dos pedidos contêm uma coleção de objetos `split`, permitindo que o split seja feito entre diversos recebedores. 
[block:callout]
{
  "type": "warning",
  "title": "Atenção!",
  "body": "É importante que o recebedor principal (Marketplace) também seja considerado no envio dos objetos **split**"
}
[/block]

[block:api-header]
{
  "title": "Objeto split"
}
[/block]
O objeto `split` tem as seguintes propriedades:
[block:parameters]
{
  "data": {
    "h-0": "Nome",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`type`",
    "0-1": "**string**",
    "0-2": "Tipo do valor a ser splitado. Valores possíveis: **percentage** ou **flat**.",
    "1-0": "`amount`",
    "1-1": "**int**",
    "1-2": "O valor a ser splitado, que poderá ser em forma de porcentagem ou de valor em centavos, de acordo com o campo `type`.",
    "2-0": "`recipient_id`",
    "2-1": "**string**",
    "2-2": "Código do recebedor para quem será feito o split"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "Todos os objetos split enviados para uma cobrança ou um pedido devem possuir o mesmo valor no campo `type`."
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "Para split em forma de porcentagem (**percentage**), a soma dos valores dos splits enviados deve ser igual a 100. Para splits **flat**, a soma deve ser igual ao valor da cobrança ou pedido."
}
[/block]