---
title: "Visão Geral"
excerpt: ""
---
Com o **Checkout Lightbox**, você pode customizar a página de finalização da compra com a identidade da sua loja, sem alterar a URL no navegador do cliente. Ao clicar em fechar o carrinho, aparece um lightbox na página do seu site para que o comprador preencha os dados para pagamento.
[block:api-header]
{
  "title": "Integração"
}
[/block]
Para utilizar o Checkout Lightbox, você precisa adicionar duas tags no seu HTML:

1) Uma tag  `<script>` para adicionar o código em js
[block:code]
{
  "codes": [
    {
      "code": "<script>\n        (function(d, s, id){\n                var js, fjs = d.getElementsByTagName(s)[0];\n                if (d.getElementById(id)) return;\n                js = d.createElement(s); js.id = id;\n                js.src = \"https://checkout.mundipagg.com/lightbox.js\";\n                fjs.parentNode.insertBefore(js, fjs);\n            }(document, 'script', 'mundipagg-lightbox'));\n</script>",
      "language": "html",
      "name": "HTML"
    }
  ]
}
[/block]
2) Uma tag `<a>` , que é o botão de chamada do lightbox, de acordo com a configuração. Ele também recebe as propriedades para configuração
[block:code]
{
  "codes": [
    {
      "code": "<a data-mundicheckout=\"lightbox\" data-mundicheckout-token=\"chk_kLPG7B3IaNcNOWny\"\ndata-mundicheckout-default>Pagar</a>\n",
      "language": "html",
      "name": "HTML"
    }
  ]
}
[/block]
Para criar o checkout, vc deve utilizar o recurso de **[meio de pagamento: checkout](https://docs.mundipagg.com/v1/reference#meio-de-pagamento-checkout)**. 
[block:api-header]
{
  "title": "Propriedades"
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Nome",
    "h-1": "Descrição",
    "0-0": "**data-mundicheckout**",
    "0-1": "Define o modo que será apresentado o checkout dentro da página\nrecebendo o valor \"lightbox\"",
    "1-1": "É o código de token gerado para carregamento do checkout",
    "1-0": "**data-mundicheckout-token**",
    "2-0": "**data-mundicheckout-default**",
    "2-1": "Se for colocado dá ao elemento `<a>` de configuração um estilo padrão de botão"
  },
  "cols": 2,
  "rows": 3
}
[/block]