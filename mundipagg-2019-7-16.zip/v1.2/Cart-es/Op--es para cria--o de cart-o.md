---
title: "Opções para criação de cartão"
excerpt: ""
---
[block:api-header]
{
  "title": "Objeto Options"
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "`verify_card`",
    "0-1": "**boolean**",
    "0-2": "Realiza uma autorização seguida de um cancelamento no cartão para verificar a autenticidade das informações."
  },
  "cols": 3,
  "rows": 1
}
[/block]