---
title: "Criar cartão"
excerpt: ""
---
[block:callout]
{
  "type": "danger",
  "title": "",
  "body": "Caso um cliente tente cadastrar um mesmo cartão mais de uma vez, será retornado o mesmo `card_id` do cartão previamente cadastrado."
}
[/block]

[block:callout]
{
  "type": "danger",
  "body": "Caso o cartão for private label (ou seja `private_label` = **true**), `brand` será um campo obrigatório."
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "Para a autenticação deste endpoint via `access_token`, deverá ser enviada a public_key da loja no parâmetro `appId` na query string.",
  "title": "Access Token"
}
[/block]