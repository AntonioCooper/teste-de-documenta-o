---
title: "Listar cartões"
excerpt: ""
---
[block:callout]
{
  "type": "warning",
  "title": "Access Token",
  "body": "Para a autenticação deste endpoint via `access_token`, deverá ser enviada a public_key da loja no parâmetro `appId` na query string."
}
[/block]