---
title: "Editar cartão"
excerpt: ""
---
[block:callout]
{
  "type": "warning",
  "body": "Para a autenticação deste endpoint via `access_token`, deverá ser enviada a public_key da loja no parâmetro `appId` na query string.",
  "title": "Access Token"
}
[/block]