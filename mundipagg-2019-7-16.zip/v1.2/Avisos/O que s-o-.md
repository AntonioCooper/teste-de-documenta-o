---
title: "O que são?"
excerpt: ""
---
**Avisos ** são *templates* de e-mails que você pode utilizar para se comunicar com seus clientes. Nosso sistema de avisos serve para notificar a geração de um boleto, a disponibilização de um *checkout* para o pagamento e mudanças de status de uma cobrança!

Você pode personalizar os avisos para que sejam mais atrativos aos seus clientes. Os seguintes campos podem ser customizados:
[block:parameters]
{
  "data": {
    "0-0": "content",
    "1-0": "sender",
    "1-1": "Remetente do e-mail",
    "2-0": "target",
    "2-1": "Alvo do e-mail (\"charges\", \"subscriptions\", \"checkouts\")",
    "3-0": "subject",
    "3-1": "Assunto do e-mail",
    "0-1": "Corpo do e-mail."
  },
  "cols": 2,
  "rows": 4
}
[/block]
**[Avisos disponíveis](https://dash.readme.io/project/mundipagg/v1/docs/o-que-s%C3%A3o)** 
[block:parameters]
{
  "data": {
    "h-0": "Tipo",
    "h-1": "Descrição",
    "0-0": "checkout_payment",
    "1-0": "boleto_gerado",
    "2-0": "paid",
    "3-0": "not_authorized",
    "4-0": "pending",
    "0-1": "Notifica a criação de um pedido com meio de pagamento *checkout*. Nesse caso, será enviado junto ao e-mail, uma URL para finalização do pagamento.",
    "1-1": "Notifica a geração de um boleto.",
    "2-1": "Notifica que uma cobrança foi autorizada e capturada.",
    "3-1": "Notifica que uma cobrança não foi autorizada.",
    "4-1": "Notifica que uma cobrança foi autorizada, mas ainda está pendente de captura."
  },
  "cols": 2,
  "rows": 5
}
[/block]
Para habilitar a funcionalidade, basta entrar em contato conosco através de **suporte@mundipagg.com** !