---
title: "Checkout Lightbox"
excerpt: ""
---
Com o nosso **Checkout Lightbox**, você pode customizar a página de finalização da compra com a identidade da sua loja, sem alterar a URL no navegador do cliente. Ou seja, ao clicar em fechar o carrinho, apenas esmaecemos o fundo do seu site e o comprador visualiza uma nova tela (um pop-up), para preenchimento dos dados para pagamento.

Abaixo temos um exemplo do produto aplicado em um e-commerce ilustrativo:


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0e1e87d-Checkout_caf_da_lu.png",
        "Checkout café da lu.png",
        1897,
        980,
        "#5f5750"
      ]
    }
  ]
}
[/block]
Para alguns compradores, sair do ambiente da loja para realizar o pagamento pode gerar certo desconforto. O Checkout Lightbox torna o processo mais intuitivo e confiável, e tende a aumentar a taxa de conversão do seu e-commerce.
[block:callout]
{
  "type": "info",
  "title": "Personalização",
  "body": "Você pode configurar o **lightbox** com a MundiPagg, definindo as cores e, se quiser, a logo da sua loja, de modo que seus clientes se sintam mais confortáveis para finalizar a compra.\n\nDeixe o lightbox com a sua cara e aumente ainda mais sua conversão!"
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Mobile",
  "body": "Para que a usabilidade e a experiência do comprador não sejam prejudicadas, caso a tela do aparelho seja muito pequena o checkout passa a ser redirect (abre em uma nova página), e não um lightbox."
}
[/block]
Saiba mais sobre o Checkout Lightbox por meio de nossa [API Reference](https://docs.mundipagg.com/v1/reference#checkout-lightbox)!