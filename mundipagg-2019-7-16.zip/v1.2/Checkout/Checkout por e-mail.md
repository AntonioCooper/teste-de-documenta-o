---
title: "Checkout por e-mail"
excerpt: ""
---
Com o **checkout por e-mail**, você pode configurar a sua loja para enviar automaticamente o link do checkout para o seu cliente!

Para utilizar esta funcionalidade basta que você a deixe ativa pra sua loja. Com isso, todo pedido (`order`) que você criar com meio de pagamento `checkout`, irá disparar um aviso por e-mail ao seu cliente para que ele realize o pagamento.

[block:callout]
{
  "type": "info",
  "title": "Personalização",
  "body": "Você pode configurar o template e o remetente do e-mail com a MundiPagg, de modo que seus clientes não se sintam desconfortáveis para finalizar a compra.\n\nDeixe o e-mail com a sua cara e aumente a sua conversão!"
}
[/block]