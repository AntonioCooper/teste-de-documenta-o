---
title: "Checkout Transparente"
excerpt: ""
---
Com esta opção, você inclui o nosso JavaScript na sua página de checkout, não interferindo em nada no visual da loja. Desta forma, toda vez que um comprador clicar no botão para finalizar o pedido, antes mesmo que o seu sistema pense em montar a requisição pra Mundi, o nosso JavaScript pega os dados do cartão, manda direto para a nossa API e recebe de volta o **token ** deste cartão.

O **Checkout Transparente** segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/23ef26b-fluxo-checkout-transparente.png",
        "fluxo-checkout-transparente.png",
        1031,
        1165,
        "#2f96ba"
      ],
      "sizing": "smart"
    }
  ]
}
[/block]
Assim, quando o checkout passa as informações para o seu sistema montar a requisição para a MundiPagg, não existe mais dados de cartão sendo passado por ali, apenas o seu **token**.

[block:callout]
{
  "type": "warning",
  "title": "Atenção",
  "body": "O `token` expira após a sua utilização e tem duração máxima de 60 segundos.\nDe qualquer maneira, ao ser utilizado, o cartão referente é adicionado à [wallet](https://docs.mundipagg.com/docs/wallets) do comprador."
}
[/block]
Saiba mais sobre o Checkout Transparente através de nossa [API Reference](https://docs.mundipagg.com/reference#sobre-checkout-transparente)!