---
title: "Checkout Redirect"
excerpt: ""
---
O **Checkout Redirect** segue o seguinte fluxo:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/311bd42-fluxo-checkout-redirect.png",
        "fluxo-checkout-redirect.png",
        1161,
        1451,
        "#2e95ba"
      ],
      "sizing": "smart"
    }
  ]
}
[/block]
O Checkout Redirect é uma página desenvolvida por nós e hospedada em nossos servidores.

Nesta opção de checkout você reúne as informações do pedido, como por exemplo os itens do carrinho, dados do comprador, dados do frete, entre outros. Com essas informações reunidas, você pode enviar uma requisição para Mundi para criamos uma página de Checkout para aquela compra.

Com a URL do Checkout em mãos, você pode disponibilizá-la ao consumidor para que este acesse a página e realize o pagamento.
[block:callout]
{
  "type": "info",
  "title": "Personalização",
  "body": "Para não correr o risco de comprometer as suas vendas, uma vez que um Checkout sem a cara da loja baixa a conversão, possibilitamos que você personalize toda a página com as suas cores e logotipo."
}
[/block]
Saiba mais sobre o Checkout Redirect através de nossa [API Reference](https://docs.mundipagg.com/reference#sobre-checkout-redirect)!