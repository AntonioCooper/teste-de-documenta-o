---
title: "Faturas"
excerpt: ""
---
As ** Faturas** são documentos gerados automaticamente ao final de cada ciclo de uma assinatura. Nelas, são discriminados todos os valores referentes à assinatura, como itens e descontos, gerando assim uma cobrança para o assinante.

Caso seja interessante para o cliente, é possível antecipar a sua criação.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2cc7458-fluxo-fatura.png",
        "fluxo-fatura.png",
        1112,
        920,
        "#2990b7"
      ],
      "sizing": "80"
    }
  ]
}
[/block]
Saiba mais sobre faturas através de nossa [API Reference](https://docs.mundipagg.com/reference#objeto-fatura)!