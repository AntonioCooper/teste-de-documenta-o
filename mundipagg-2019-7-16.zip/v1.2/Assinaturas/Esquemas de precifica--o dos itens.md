---
title: "Esquemas de precificação dos itens"
excerpt: ""
---
A nova API foi projetada para atender diferentes modelos de recorrência, como academias, escolas, operadoras de telefonia, clubes de assinatura, entre outros. Entretanto, cada um desses mercados tem diferentes tipos de precificações para seus produtos e serviços.

Pensando nisso, montamos lógicas de precificação (`Price_Scheme`) para itens de uma assinatura que você pode utilizar para cobrar por seus produtos. 
[block:callout]
{
  "type": "danger",
  "body": "É importante destacar que esta não é a forma como a MundiPagg cobra seus clientes e sim, os modelos de precificação que você pode aplicar em seus planos e assinaturas para cobrar seus clientes utilizando nossa API.",
  "title": "Atenção!"
}
[/block]
Os **Esquemas de Precificação** possíveis para os itens da assinatura estão apresentados utilizando a unidade de medida "minuto" como exemplo:


* [**UNIT**]()

1 minuto - Custa R$1,00 

Se um cliente utilizar 100 minutos o valor total será R$100,00 (100 x R$1,00)

* [**PACKAGE**]()

De 0 a 10 minutos -  Custa R$50,00
De 11 a 50 minutos - Custa R$70,00 
De 51 a 100 minutos - Custa R$100,00
Cada minuto acima da última faixa custa R$0,90

Se um cliente utilizar 25 minutos o valor será R$70,00

* [**VOLUME**]()

Se utilizar entre 1 ~ 10 minutos - Cada minuto custa R$1,00
Se utilizar entre 11 ~ 20 minutos - Cada minuto custa R$0,90
Se utilizar entre 21 ~ 50 minutos - Cada minuto custa R$0,80
Cada minuto acima da última faixa custa R$0,70

Se um cliente utilizar 25 minutos o valor total será R$20,00 (25 x R$0,80)


* [**TIER**]()

Do 1° ao 10° minuto - Cada minuto custa R$1,00.
Do 11° ao 20° minuto - Cada minuto custa R$0,90.
Do 21° ao 50° minuto - Cada minuto custa R$0,80
Cada minuto acima da última faixa custa R$0,70

Se um cliente utilizar 25 minutos o valor total será R$23,00 (10 x R$1,00 + 10 x R$0,90 + 5 x R$0,80)

Saiba mais sobre os esquemas de precificação de itens de planos e assinaturas através de nossa [API Reference](https://docs.mundipagg.com/reference#precificacao)!