---
title: "Listar assinaturas"
excerpt: "<br>\nPodemos listar assinaturas definindo diversos filtros, como podem ver na lista de QUERY PARAMS abaixo."
---
