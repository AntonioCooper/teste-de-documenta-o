---
title: "Retentativa automática"
excerpt: ""
---
A **retentativa automática** é uma tecnologia que reprocessa automaticamente na mesma ou em outra adquirente, as transações não autorizadas. Existe também a possibilidade de retentar uma transação manualmente.

Essa tecnologia foi desenvolvida, pois muitas transações são reprovadas devido a ineficiência e problemas técnicos das adquirentes e não pelo limite de compra do cartão de crédito do consumidor. 
[block:callout]
{
  "type": "info",
  "body": "É possível programar o número de retentativas por adquirente e em quantas adquirentes iremos tentar reprocessar as transações.",
  "title": "Configuração"
}
[/block]

[block:callout]
{
  "type": "success",
  "title": "Aumento da taxa de conversão e do faturamento",
  "body": "A recuperação média gira em torno de 5% podendo chegar até a 20% em alguns casos, principalmente para lojistas que antes trabalhavam com subadquirentes. O aumento da taxa de conversão reflete diretamente no faturamento mensal do seu negócio."
}
[/block]
Para habilitar a funcionalidade, basta entrar em contato conosco através de **suporte@mundipagg.com** !