---
title: "Retentativa offline"
excerpt: ""
---
As **retentativas offline** tem como objetivo recuperar cobranças que não foram autorizadas. Elas podem ser estabelecidas através de uma cobrança avulsa (*charge*) ou de uma assinatura (*subscription*) e devem ser configuradas através da unidade de medida “hora”, tendo como base a última tentativa. A quantidade máxima de retentativas varia de acordo com a quantidade definida pelo cliente, seja via **API** ou via **Portal**.

O fluxo das retentativas offline de um pedido realizado as 12h pode ser visualizado a seguir:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aa623be-fluxo-retentativa-offline1.png",
        "fluxo-retentativa-offline(1).png",
        1500,
        576,
        "#2689b6"
      ],
      "sizing": "full"
    }
  ]
}
[/block]
Onde as etapas 4 (nova tentativa de autorização feita na adquirente) e 5 (resposta da adquirente enviada para a MundiPagg) são repetidas até a cobrança ser autorizada ou ate que a quantidade de retentativas selecionada pelo lojista seja atingida.


**Exemplo:**
A assinatura de uma TV a cabo pode ser configurada para sofrer retentativas offline de pagamento de 1 em 1 dia por 3 dias. Caso não seja alcançada a autorização, o lojista receberá a notificação que a transação não foi autorizada e ele deverá entrar em contato com seu cliente.



Para habilitar a funcionalidade, basta entrar em contato conosco através de **suporte@mundipagg.com** !