---
title: "Objeto recebedor"
excerpt: ""
---
[block:callout]
{
  "type": "danger",
  "title": "Atenção",
  "body": "As funcionalidades do [Split](https://docs.mundipagg.com/docs/pedidos-com-split) de pagamentos só estão disponíveis para contas configuradas com um gateway específico chamado *Pagar.me* ."
}
[/block]
Para criar um pedido com Split de pagamentos, você deve antes cadastrar recebedores (`recipient`). Os recebedores são identificados por uma chave aleatória (`recipient_id`). Ex.: `rp_y26ABkRQhzhxEqpa`
[block:parameters]
{
  "data": {
    "h-0": "Campo",
    "h-1": "Tipo",
    "h-2": "Descrição",
    "0-0": "`id`",
    "0-1": "**string**",
    "0-2": "Código do recebedor.",
    "1-0": "`name`",
    "1-1": "**string**",
    "1-2": "Nome do recebedor",
    "2-0": "`email`",
    "2-1": "**string**",
    "2-2": "E-mail do recebedor",
    "3-0": "`document`",
    "3-1": "**string**",
    "3-2": "CPF ou CNPJ do recebedor",
    "4-0": "`description`",
    "4-1": "**string**",
    "4-2": "Descrição do recebedor",
    "5-0": "`type`",
    "5-1": "**enum**",
    "5-2": "Tipo de cliente. Valores possíveis: **individual** (pessoa física) ou **company** (pessoa jurídica)",
    "6-0": "`status`",
    "6-1": "**string**",
    "6-2": "Status do recebedor . Valores possíveis: **active** ou **inactive**",
    "7-0": "`created_at`",
    "7-1": "**datetime**",
    "7-2": "Data de criação do recebedor",
    "8-0": "`updated_at`",
    "8-1": "**datetime**",
    "8-2": "Data de atualização do recebedor",
    "10-0": "`default_bank_account`",
    "10-1": "**object**",
    "10-2": "Conta bancária do recebedor",
    "11-0": "`gateway_recipients`",
    "11-1": "**object**",
    "11-2": "Informações do recebedor no gateway",
    "12-0": "`metadata`",
    "12-1": "**object**",
    "12-2": "Objeto chave/valor utilizado para armazenar informações adicionais sobre o recebedor [Saiba mais sobre metadata](ref:metadata)",
    "9-0": "`deleted_at`",
    "9-1": "**datetime**",
    "9-2": "Data de exclusão do recebedor"
  },
  "cols": 3,
  "rows": 13
}
[/block]