---
title: "Editar recebedor"
excerpt: ""
---
[block:callout]
{
  "type": "danger",
  "body": "As funcionalidades de recebedores de pagamentos só estão disponíveis para contas configuradas com um gateway específico chamado Pagar.me .",
  "title": "Atenção"
}
[/block]