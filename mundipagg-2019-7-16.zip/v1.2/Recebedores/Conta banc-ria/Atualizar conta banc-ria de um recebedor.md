---
title: "Atualizar conta bancária de um recebedor"
excerpt: ""
---
