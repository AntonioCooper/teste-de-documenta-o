---
title: "Criar recebedor"
excerpt: ""
---
[block:callout]
{
  "type": "danger",
  "title": "Atenção",
  "body": "As funcionalidades de recebedores de pagamentos só estão disponíveis para contas configuradas com um gateway específico chamado Pagar.me ."
}
[/block]