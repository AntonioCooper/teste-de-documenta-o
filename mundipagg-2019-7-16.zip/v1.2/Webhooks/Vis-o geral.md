---
title: "Visão geral"
excerpt: ""
---
Sempre que ocorre um evento importante, nós disparamos uma notificação para seu servidor. Essas notificações são chamadas de **webhooks**.

É possível configurar varios endpoints e escolher quais eventos serão disparados .