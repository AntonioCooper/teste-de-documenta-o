---
title: "O que são?"
excerpt: ""
---
Os **Webhooks** são as notificações que enviamos para você sempre que um evento ocorre.

A cada atualização, o sistema envia um **HTTP POST** para a URL configurada no webhook, com todas as informações relevantes sobre cobranças, pedidos, assinaturas, entre outros. Desta maneira, o seu sistema, ao receber essa notificação, pode executar os próximos passos.

Você tem total liberdade para escolher sobre quais eventos quer ser notificado e para qual URL cada webhook será enviado. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1d8f5b9-fluxo-webhooks.png",
        "fluxo-webhooks.png",
        1500,
        1500,
        "#1e78a2"
      ],
      "sizing": "80"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Contornando falhas no recebimento dos webhooks",
  "body": "Pensando na possibilidade do seu serviço, por qualquer motivo, não conseguir receber o webhook, criamos uma configuração pela qual você pode definir quantas vezes iremos reenviá-lo em caso de falha no recebimento.\n \nDe qualquer forma, nossa API também tem um endpoint pelo qual você pode consultar quais webhooks falharam, e forçar os seus envios manualmente."
}
[/block]
##[**Funcionalidades relacionadas aos webhooks**]()
[block:parameters]
{
  "data": {
    "0-0": "**1)** [Reenviar webhook](https://docs.mundipagg.com/v1/reference#enviar-webhook)",
    "1-0": "**2)** [Obter](https://docs.mundipagg.com/v1/reference#obter-webhook)",
    "2-0": "**3)** [Listar](https://docs.mundipagg.com/v1/reference#listar-webhooks)"
  },
  "cols": 1,
  "rows": 3
}
[/block]
##[**Eventos disponíveis**]()

Temos uma lista de eventos importantes que podem ocorrer na nossa API. Veja abaixo!
[block:parameters]
{
  "data": {
    "0-0": "`customer.created`",
    "0-1": "Ocorre sempre que um comprador é criado",
    "1-0": "`customer.updated`",
    "1-1": "Ocorre sempre que um comprador é atualizado",
    "2-0": "`card.created`",
    "2-1": "Ocorre sempre que um cartão é criado",
    "3-0": "`card.updated`",
    "3-1": "Ocorre sempre que um cartão é atualizado",
    "4-0": "`card.deleted`",
    "4-1": "Ocorre sempre que um cartão é deletado",
    "5-0": "`address.created`",
    "5-1": "Ocorre sempre que um endereço é criado",
    "6-0": "`address.updated`",
    "6-1": "Ocorre sempre que um endereço é atualizado",
    "7-0": "`address.deleted`",
    "7-1": "Ocorre sempre que um endereço é deletado",
    "8-0": "`plan.created`",
    "8-1": "Ocorre sempre que um plano é criado",
    "9-0": "`plan.updated`",
    "9-1": "Ocorre sempre que um plano é atualizado",
    "10-0": "`plan.deleted`",
    "10-1": "Ocorre sempre que um plano é deletado",
    "11-0": "`planitem.created`",
    "11-1": "Ocorre sempre que um item de plano é criado",
    "12-0": "`planitem.updated`",
    "12-1": "Ocorre sempre que um item de plano é atualizado",
    "13-0": "`planitem.deleted`",
    "13-1": "Ocorre sempre que um item de plano é deletado",
    "14-0": "`subscription.created`",
    "14-1": "Ocorre sempre que uma assinatura é criada",
    "15-0": "`subscription.updated`",
    "15-1": "Ocorre sempre que uma assinatura é atualizada",
    "16-0": "`subscription.canceled`",
    "16-1": "Ocorre sempre que uma assinatura é cancelada",
    "17-0": "`subscriptionitem.created`",
    "17-1": "Ocorre sempre que um item de assinatura é criado",
    "18-0": "`subscriptionitem.updated`",
    "18-1": "Ocorre sempre que um item de assinatura é atualizado",
    "19-0": "`subscriptionitem.deleted`",
    "19-1": "Ocorre sempre que um item de assinatura é deletado",
    "20-0": "`discount.created`",
    "20-1": "Ocorre sempre que um desconto é criado",
    "21-0": "`discount.deleted`",
    "21-1": "Ocorre sempre que um desconto é deletado",
    "22-0": "`order.paid`",
    "22-1": "Ocorre sempre que um pedido é pago",
    "23-0": "`order.payment_failed`",
    "23-1": "Ocorre sempre que o pagamento de um pedido falha",
    "24-0": "`order.create`",
    "24-1": "Ocorre sempre que um pedido é criado",
    "25-0": "`order.canceled`",
    "25-1": "Ocorre sempre que um pedido é cancelado",
    "26-0": "`invoice.created`",
    "26-1": "Ocorre sempre que uma fatura é criada",
    "27-0": "`invoice.paid`",
    "27-1": "Ocorre sempre que uma fatura é paga",
    "28-0": "`invoice.payment_failed`",
    "28-1": "Ocorre sempre que o pagamento de uma fatura falha",
    "29-0": "`invoice.canceled`",
    "29-1": "Ocorre sempre que uma fatura é cancelada",
    "30-0": "`charge.paid`",
    "30-1": "Ocorre sempre que uma cobrança é paga",
    "31-0": "`charge.payment_failed`",
    "31-1": "Ocorre sempre que o pagamento de uma cobrança falha",
    "32-0": "`charge.pending`",
    "32-1": "Ocorre sempre que o pagamento de uma cobrança estiver pendente",
    "33-0": "`charge.refunded`",
    "33-1": "Ocorre sempre que uma cobrança é estornada"
  },
  "cols": 2,
  "rows": 34
}
[/block]
Saiba mais sobre os Webhooks através de nossa [API Reference](https://docs.mundipagg.com/reference#webhooks)!