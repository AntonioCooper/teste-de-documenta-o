---
title: "Visão geral"
excerpt: ""
---
Com o **checkout por e-mail**,  você pode configurar a sua loja para enviar automaticamente o link do checkout para o seu cliente!

Para utilizar esta funcionalidade basta que você a deixe ativa para sua loja. **Entre em contato conosco para habilitá-la!**

Com isso, todo pedido (`order`) que você criar com meio de pagamento `checkout`, irá disparar um aviso por e-mail ao seu cliente para que ele realize o pagamento. [Leia mais sobre o meio de pagamento checkout](ref:meio-de-pagamento-checkout).