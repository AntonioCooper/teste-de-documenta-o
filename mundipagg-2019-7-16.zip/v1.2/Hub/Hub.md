---
title: "Hub"
excerpt: ""
---
[block:api-header]
{
  "type": "basic",
  "title": "Visão Geral"
}
[/block]
O Hub é a App Stone da MundiPagg que servirá para que um cliente possa integrar nosso serviço com qualquer outra solução de forma mais simples e rápida, melhorando a vida dos nossos clientes.

Antes do Hub o cliente precisaria entender o comportamento de cada ferramenta, validar quais são as chaves de autenticação necessárias, configurar notificações, se comunicar entre as APIs, etc.

[block:api-header]
{
  "title": "Objetivo"
}
[/block]
Seremos uma plataforma de integrações que conecta outros serviços do mundo com a MundiPagg de forma simples e rápida.
[block:api-header]
{
  "title": "Quem precisa do Hub?"
}
[/block]
* Clientes que desejam integrar as informações da sua loja na MundiPagg com os diversos aplicativos, plataformas, serviços complementares, etc;
* Clientes que ainda não utilizam a MundiPagg por não ser uma opção simples de integrar em sua plataforma/serviços;
* Desenvolvedores externos ao nosso ecossistema que desejam criar integrações com a MundiPagg para seus aplicativos.
[block:api-header]
{
  "title": "Foco do Produto"
}
[/block]
* Disponibilizar integrações nativas e integrações por terceiros;
* Ser mais simples e fácil para os desenvolvedores, internos ou externos, criarem seus apps ou integrações;
* Oferecer mais simplicidade de praticidade para os clientes integrarem e nosso serviços com qualquer solução que ele quiser;
* Ter uma quantidade expressiva de integrações pertinentes ao nosso universo de pagamentos.
* Muitos sistemas com API abertas para integração;
* Aplicativos e serviços que possuem e necessidade de aceitar pagamentos;
[block:api-header]
{
  "title": "Proposta"
}
[/block]
* A MundiPagg possui 40% do e-commerce brasileiro, maior player do seu do mercado nacional;
* Varejo de moda, serviços de assinatura, streaming, academias, etc;
* Seu app vai estar na vitrine pra 7000 lojas, com a relevância relativa de cada app, deixamos seu serviço disponível para clientes que precisam de vocês;
* Informações, clientes, integrações simples e rápidas;
* Integração direta na MundiPagg.

[block:api-header]
{
  "title": "Apps"
}
[/block]
**Integrações:**
* Nfe.io
* Shopify
* Slack
* Messenger
* PipeDrive
* Muambator
* Pombo Correio
[block:api-header]
{
  "title": "Fluxo"
}
[/block]
O processo de instalação é bem simples, segue o passo a passo:

1 - O Lojista precisa entrar na página do Hub por este link:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ab447de-Pgina_Hub.JPG",
        "Página Hub.JPG",
        1346,
        653,
        "#dde9e1"
      ]
    }
  ]
}
[/block]
2 - Na lista de apps você deve escolher o que deseja instalar em sua loja e clicar em "Integrar com a MundiPagg".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e715b3a-Pgina_Hub_2.JPG",
        "Página Hub 2.JPG",
        1344,
        659,
        "#eff1f0"
      ]
    }
  ]
}
[/block]
3 - Abrirá a caixa de instalação em que você deverá marcar as permissões de ações e eventos que deverão ser utilizados, ou pelo próprio lojista ou pelo seu consumidor final, e configurar os campos personalizáveis.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fdbc0fb-pgina_Hub_3.JPG",
        "página Hub 3.JPG",
        1341,
        658,
        "#adb0b5"
      ]
    }
  ]
}
[/block]
4 - Após a instalação do app serão geradas duas chaves que deverão ser usadas, em alguns casos, para configuração do serviço da MundiPagg atrelado a MundiPagg.